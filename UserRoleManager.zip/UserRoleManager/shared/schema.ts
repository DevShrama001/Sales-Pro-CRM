import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User & Role Management

export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  permissions: jsonb("permissions").notNull().$type<string[]>(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  roleId: integer("role_id").notNull().references(() => roles.id),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Lead & Pipeline Management

export const pipelines = pgTable("pipelines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  isDefault: boolean("is_default").default(false),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const stages = pgTable("stages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  pipelineId: integer("pipeline_id").notNull().references(() => pipelines.id),
  order: integer("order").notNull(),
  color: text("color").default("#3b82f6"),
  requiredFields: jsonb("required_fields").notNull().$type<string[]>(),
});

export const leadForms = pgTable("lead_forms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  fields: jsonb("fields").notNull().$type<LeadFormField[]>(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  isDefault: boolean("is_default").default(false),
});

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  company: text("company").notNull(),
  contact: text("contact"),
  email: text("email"),
  phone: text("phone"),
  source: text("source"),
  value: integer("value"),
  probability: integer("probability").default(0),
  stageId: integer("stage_id").notNull().references(() => stages.id),
  assignedTo: integer("assigned_to").references(() => users.id),
  customFields: jsonb("custom_fields").notNull().$type<Record<string, any>>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  leadId: integer("lead_id").notNull().references(() => leads.id),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // meeting, call, email, note, stage_change
  title: text("title").notNull(),
  description: text("description"),
  scheduledAt: timestamp("scheduled_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const leadContacts = pgTable("lead_contacts", {
  id: serial("id").primaryKey(),
  leadId: integer("lead_id").notNull().references(() => leads.id),
  name: text("name").notNull(),
  position: text("position"),
  email: text("email"),
  phone: text("phone"),
  isPrimary: boolean("is_primary").default(false),
});

export const lostReasons = pgTable("lost_reasons", {
  id: serial("id").primaryKey(),
  leadId: integer("lead_id").notNull().references(() => leads.id),
  reason: text("reason").notNull(),
  competitor: text("competitor"),
  comments: text("comments"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Settings & Customization

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  theme: jsonb("theme").notNull().$type<{
    primary: string;
    variant: string;
    appearance: string;
    radius: number;
  }>(),
  notifications: jsonb("notifications").notNull().$type<{
    email: boolean;
    app: boolean;
    leadUpdates: boolean;
    meetingReminders: boolean;
  }>(),
});

// Types

export type Role = typeof roles.$inferSelect;
export type User = typeof users.$inferSelect;
export type Pipeline = typeof pipelines.$inferSelect;
export type Stage = typeof stages.$inferSelect;
export type LeadForm = typeof leadForms.$inferSelect;
export type Lead = typeof leads.$inferSelect;
export type Activity = typeof activities.$inferSelect;
export type LeadContact = typeof leadContacts.$inferSelect;
export type LostReason = typeof lostReasons.$inferSelect;
export type Setting = typeof settings.$inferSelect;

export interface LeadFormField {
  id: string;
  name: string;
  label: string;
  type: string;
  required: boolean;
  options?: string[];
  tab?: string;
  order: number;
}

// Insert schemas

export const insertRoleSchema = createInsertSchema(roles);
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  roleId: true,
  isActive: true,
});
export const insertPipelineSchema = createInsertSchema(pipelines).pick({
  name: true,
  description: true,
  isDefault: true,
  createdBy: true,
});
export const insertStageSchema = createInsertSchema(stages).pick({
  name: true,
  description: true,
  pipelineId: true,
  order: true,
  color: true,
  requiredFields: true,
});
export const insertLeadFormSchema = createInsertSchema(leadForms).pick({
  name: true,
  fields: true,
  createdBy: true,
  isDefault: true,
});
export const insertLeadSchema = createInsertSchema(leads).pick({
  company: true,
  contact: true,
  email: true,
  phone: true,
  source: true,
  value: true,
  probability: true,
  stageId: true,
  assignedTo: true,
  customFields: true,
});
export const insertActivitySchema = createInsertSchema(activities).pick({
  leadId: true,
  userId: true,
  type: true,
  title: true,
  description: true,
  scheduledAt: true,
  completedAt: true,
});
export const insertLeadContactSchema = createInsertSchema(leadContacts).pick({
  leadId: true,
  name: true,
  position: true,
  email: true,
  phone: true,
  isPrimary: true,
});
export const insertLostReasonSchema = createInsertSchema(lostReasons).pick({
  leadId: true,
  reason: true,
  competitor: true,
  comments: true,
});
export const insertSettingSchema = createInsertSchema(settings).pick({
  userId: true,
  theme: true,
  notifications: true,
});

// Export Insert types
export type InsertRole = z.infer<typeof insertRoleSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertPipeline = z.infer<typeof insertPipelineSchema>;
export type InsertStage = z.infer<typeof insertStageSchema>;
export type InsertLeadForm = z.infer<typeof insertLeadFormSchema>;
export type InsertLead = z.infer<typeof insertLeadSchema>;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type InsertLeadContact = z.infer<typeof insertLeadContactSchema>;
export type InsertLostReason = z.infer<typeof insertLostReasonSchema>;
export type InsertSetting = z.infer<typeof insertSettingSchema>;

// Relations

export const roleRelations = relations(roles, ({ many }) => ({
  users: many(users)
}));

export const userRelations = relations(users, ({ one, many }) => ({
  role: one(roles, {
    fields: [users.roleId],
    references: [roles.id]
  }),
  pipelines: many(pipelines, { relationName: "createdPipelines" }),
  assignedLeads: many(leads, { relationName: "assignedLeads" }),
  activities: many(activities),
  settings: many(settings)
}));

export const pipelineRelations = relations(pipelines, ({ one, many }) => ({
  creator: one(users, {
    fields: [pipelines.createdBy],
    references: [users.id]
  }),
  stages: many(stages)
}));

export const stageRelations = relations(stages, ({ one, many }) => ({
  pipeline: one(pipelines, {
    fields: [stages.pipelineId],
    references: [pipelines.id]
  }),
  leads: many(leads)
}));

export const leadFormRelations = relations(leadForms, ({ one }) => ({
  creator: one(users, {
    fields: [leadForms.createdBy],
    references: [users.id]
  })
}));

export const leadRelations = relations(leads, ({ one, many }) => ({
  stage: one(stages, {
    fields: [leads.stageId],
    references: [stages.id]
  }),
  assignee: one(users, {
    fields: [leads.assignedTo],
    references: [users.id]
  }),
  activities: many(activities),
  contacts: many(leadContacts),
  lostReason: one(lostReasons)
}));

export const activityRelations = relations(activities, ({ one }) => ({
  lead: one(leads, {
    fields: [activities.leadId],
    references: [leads.id]
  }),
  user: one(users, {
    fields: [activities.userId],
    references: [users.id]
  })
}));

export const leadContactRelations = relations(leadContacts, ({ one }) => ({
  lead: one(leads, {
    fields: [leadContacts.leadId],
    references: [leads.id]
  })
}));

export const lostReasonRelations = relations(lostReasons, ({ one }) => ({
  lead: one(leads, {
    fields: [lostReasons.leadId],
    references: [leads.id]
  })
}));

export const settingRelations = relations(settings, ({ one }) => ({
  user: one(users, {
    fields: [settings.userId],
    references: [users.id]
  })
}));
