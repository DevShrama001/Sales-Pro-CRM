import { 
  users, roles, pipelines, stages, leadForms, leads, 
  activities, leadContacts, lostReasons, settings,
  type User, type Role, type Pipeline, type Stage, 
  type LeadForm, type Lead, type Activity, type LeadContact, 
  type LostReason, type Setting, type InsertUser, type InsertRole,
  type InsertPipeline, type InsertStage, type InsertLeadForm,
  type InsertLead, type InsertActivity, type InsertLeadContact,
  type InsertLostReason, type InsertSetting, type LeadFormField
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { Pool } from "@neondatabase/serverless";

const PostgresSessionStore = connectPg(session);
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

export interface IStorage {
  // User & Role Management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  getRole(id: number): Promise<Role | undefined>;
  getRoleByName(name: string): Promise<Role | undefined>;
  getRoles(): Promise<Role[]>;
  createRole(role: InsertRole): Promise<Role>;
  updateRole(id: number, role: Partial<InsertRole>): Promise<Role | undefined>;
  deleteRole(id: number): Promise<boolean>;
  
  // Pipeline Management
  getPipeline(id: number): Promise<Pipeline | undefined>;
  getPipelines(): Promise<Pipeline[]>;
  createPipeline(pipeline: InsertPipeline): Promise<Pipeline>;
  updatePipeline(id: number, pipeline: Partial<InsertPipeline>): Promise<Pipeline | undefined>;
  deletePipeline(id: number): Promise<boolean>;
  
  getStage(id: number): Promise<Stage | undefined>;
  getStagesByPipeline(pipelineId: number): Promise<Stage[]>;
  createStage(stage: InsertStage): Promise<Stage>;
  updateStage(id: number, stage: Partial<InsertStage>): Promise<Stage | undefined>;
  deleteStage(id: number): Promise<boolean>;
  
  // Lead Form Management
  getLeadForm(id: number): Promise<LeadForm | undefined>;
  getLeadForms(): Promise<LeadForm[]>;
  createLeadForm(form: InsertLeadForm): Promise<LeadForm>;
  updateLeadForm(id: number, form: Partial<InsertLeadForm>): Promise<LeadForm | undefined>;
  deleteLeadForm(id: number): Promise<boolean>;
  
  // Lead Management
  getLead(id: number): Promise<Lead | undefined>;
  getLeads(): Promise<Lead[]>;
  getLeadsByStage(stageId: number): Promise<Lead[]>;
  getLeadsByAssignee(userId: number): Promise<Lead[]>;
  createLead(lead: InsertLead): Promise<Lead>;
  updateLead(id: number, lead: Partial<InsertLead>): Promise<Lead | undefined>;
  deleteLead(id: number): Promise<boolean>;
  
  // Activity Management
  getActivity(id: number): Promise<Activity | undefined>;
  getActivitiesByLead(leadId: number): Promise<Activity[]>;
  getActivitiesByUser(userId: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  updateActivity(id: number, activity: Partial<InsertActivity>): Promise<Activity | undefined>;
  deleteActivity(id: number): Promise<boolean>;
  
  // Lead Contact Management
  getLeadContact(id: number): Promise<LeadContact | undefined>;
  getLeadContactsByLead(leadId: number): Promise<LeadContact[]>;
  createLeadContact(contact: InsertLeadContact): Promise<LeadContact>;
  updateLeadContact(id: number, contact: Partial<InsertLeadContact>): Promise<LeadContact | undefined>;
  deleteLeadContact(id: number): Promise<boolean>;
  
  // Lost Reason Management
  getLostReason(id: number): Promise<LostReason | undefined>;
  getLostReasonByLead(leadId: number): Promise<LostReason | undefined>;
  createLostReason(reason: InsertLostReason): Promise<LostReason>;
  
  // Settings Management
  getSettings(userId: number): Promise<Setting | undefined>;
  createSettings(settings: InsertSetting): Promise<Setting>;
  updateSettings(userId: number, settings: Partial<InsertSetting>): Promise<Setting | undefined>;

  // Session Store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User & Role Management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(user)
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return !!result;
  }

  async getRole(id: number): Promise<Role | undefined> {
    const [role] = await db.select().from(roles).where(eq(roles.id, id));
    return role || undefined;
  }

  async getRoleByName(name: string): Promise<Role | undefined> {
    const [role] = await db.select().from(roles).where(eq(roles.name, name));
    return role || undefined;
  }

  async getRoles(): Promise<Role[]> {
    return await db.select().from(roles);
  }

  async createRole(role: InsertRole): Promise<Role> {
    // Ensure permissions is an array of strings
    let roleToInsert = { ...role };
    if (typeof role.permissions === 'object' && !Array.isArray(role.permissions)) {
      roleToInsert.permissions = Object.values(role.permissions) as string[];
    }
    const [newRole] = await db.insert(roles).values(roleToInsert).returning();
    return newRole;
  }

  async updateRole(id: number, role: Partial<InsertRole>): Promise<Role | undefined> {
    let roleToUpdate = { ...role };
    
    // Handle permissions array conversion
    if (roleToUpdate.permissions && typeof roleToUpdate.permissions === 'object' && !Array.isArray(roleToUpdate.permissions)) {
      roleToUpdate.permissions = Object.values(roleToUpdate.permissions) as string[];
    }
    
    const [updatedRole] = await db
      .update(roles)
      .set(roleToUpdate)
      .where(eq(roles.id, id))
      .returning();
    return updatedRole || undefined;
  }

  async deleteRole(id: number): Promise<boolean> {
    const result = await db.delete(roles).where(eq(roles.id, id));
    return !!result;
  }

  // Pipeline Management
  async getPipeline(id: number): Promise<Pipeline | undefined> {
    const [pipeline] = await db.select().from(pipelines).where(eq(pipelines.id, id));
    return pipeline || undefined;
  }

  async getPipelines(): Promise<Pipeline[]> {
    return await db.select().from(pipelines);
  }

  async createPipeline(pipeline: InsertPipeline): Promise<Pipeline> {
    const [newPipeline] = await db.insert(pipelines).values(pipeline).returning();
    return newPipeline;
  }

  async updatePipeline(id: number, pipeline: Partial<InsertPipeline>): Promise<Pipeline | undefined> {
    const [updatedPipeline] = await db
      .update(pipelines)
      .set(pipeline)
      .where(eq(pipelines.id, id))
      .returning();
    return updatedPipeline || undefined;
  }

  async deletePipeline(id: number): Promise<boolean> {
    const result = await db.delete(pipelines).where(eq(pipelines.id, id));
    return !!result;
  }

  async getStage(id: number): Promise<Stage | undefined> {
    const [stage] = await db.select().from(stages).where(eq(stages.id, id));
    return stage || undefined;
  }

  async getStagesByPipeline(pipelineId: number): Promise<Stage[]> {
    return await db
      .select()
      .from(stages)
      .where(eq(stages.pipelineId, pipelineId))
      .orderBy(stages.order);
  }

  async createStage(stage: InsertStage): Promise<Stage> {
    // Ensure requiredFields is an array of strings
    let stageToInsert = { ...stage };
    if (typeof stage.requiredFields === 'object' && !Array.isArray(stage.requiredFields)) {
      stageToInsert.requiredFields = Object.values(stage.requiredFields) as string[];
    }
    const [newStage] = await db.insert(stages).values(stageToInsert).returning();
    return newStage;
  }

  async updateStage(id: number, stage: Partial<InsertStage>): Promise<Stage | undefined> {
    // Handle array conversion if needed
    let stageToUpdate = { ...stage };
    if (stageToUpdate.requiredFields && typeof stageToUpdate.requiredFields === 'object' && !Array.isArray(stageToUpdate.requiredFields)) {
      stageToUpdate.requiredFields = Object.values(stageToUpdate.requiredFields) as string[];
    }
    const [updatedStage] = await db
      .update(stages)
      .set(stageToUpdate)
      .where(eq(stages.id, id))
      .returning();
    return updatedStage || undefined;
  }

  async deleteStage(id: number): Promise<boolean> {
    const result = await db.delete(stages).where(eq(stages.id, id));
    return !!result;
  }

  // Lead Form Management
  async getLeadForm(id: number): Promise<LeadForm | undefined> {
    const [form] = await db.select().from(leadForms).where(eq(leadForms.id, id));
    return form || undefined;
  }

  async getLeadForms(): Promise<LeadForm[]> {
    return await db.select().from(leadForms);
  }

  async createLeadForm(form: InsertLeadForm): Promise<LeadForm> {
    // Handle fields and ensure it's properly formatted as an array of LeadFormField objects
    if (form.fields && typeof form.fields === 'object' && !Array.isArray(form.fields)) {
      try {
        // Try to convert non-array object to array
        const fieldsArray = Object.values(form.fields).map(field => {
          if (typeof field === 'object' && field !== null) {
            return field as LeadFormField;
          }
          throw new Error('Invalid field format');
        });
        form = {
          ...form,
          fields: fieldsArray
        };
      } catch (error) {
        console.error('Error converting form fields to array:', error);
        throw new Error('Invalid form fields format');
      }
    }
    
    const [newForm] = await db.insert(leadForms).values(form).returning();
    return newForm;
  }

  async updateLeadForm(id: number, form: Partial<InsertLeadForm>): Promise<LeadForm | undefined> {
    // Handle fields and ensure it's properly formatted as an array
    if (form.fields && typeof form.fields === 'object' && !Array.isArray(form.fields)) {
      try {
        // Try to convert non-array object to array
        const fieldsArray = Object.values(form.fields).map(field => {
          if (typeof field === 'object' && field !== null) {
            return field as LeadFormField;
          }
          throw new Error('Invalid field format');
        });
        form = {
          ...form,
          fields: fieldsArray
        };
      } catch (error) {
        console.error('Error converting form fields to array:', error);
        throw new Error('Invalid form fields format');
      }
    }
    
    const [updatedForm] = await db
      .update(leadForms)
      .set(form)
      .where(eq(leadForms.id, id))
      .returning();
    return updatedForm || undefined;
  }

  async deleteLeadForm(id: number): Promise<boolean> {
    const result = await db.delete(leadForms).where(eq(leadForms.id, id));
    return !!result;
  }

  // Lead Management
  async getLead(id: number): Promise<Lead | undefined> {
    const [lead] = await db.select().from(leads).where(eq(leads.id, id));
    return lead || undefined;
  }

  async getLeads(): Promise<Lead[]> {
    return await db.select().from(leads);
  }

  async getLeadsByStage(stageId: number): Promise<Lead[]> {
    return await db.select().from(leads).where(eq(leads.stageId, stageId));
  }

  async getLeadsByAssignee(userId: number): Promise<Lead[]> {
    return await db.select().from(leads).where(eq(leads.assignedTo, userId));
  }

  async createLead(lead: InsertLead): Promise<Lead> {
    const [newLead] = await db.insert(leads).values(lead).returning();
    return newLead;
  }

  async updateLead(id: number, lead: Partial<InsertLead>): Promise<Lead | undefined> {
    const updatedData = { ...lead, updatedAt: new Date() };
    const [updatedLead] = await db
      .update(leads)
      .set(updatedData)
      .where(eq(leads.id, id))
      .returning();
    return updatedLead || undefined;
  }

  async deleteLead(id: number): Promise<boolean> {
    const result = await db.delete(leads).where(eq(leads.id, id));
    return !!result;
  }

  // Activity Management
  async getActivity(id: number): Promise<Activity | undefined> {
    const [activity] = await db.select().from(activities).where(eq(activities.id, id));
    return activity || undefined;
  }

  async getActivitiesByLead(leadId: number): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.leadId, leadId))
      .orderBy(activities.createdAt);
  }

  async getActivitiesByUser(userId: number): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.userId, userId))
      .orderBy(activities.createdAt);
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db.insert(activities).values(activity).returning();
    return newActivity;
  }

  async updateActivity(id: number, activity: Partial<InsertActivity>): Promise<Activity | undefined> {
    const [updatedActivity] = await db
      .update(activities)
      .set(activity)
      .where(eq(activities.id, id))
      .returning();
    return updatedActivity || undefined;
  }

  async deleteActivity(id: number): Promise<boolean> {
    const result = await db.delete(activities).where(eq(activities.id, id));
    return !!result;
  }

  // Lead Contact Management
  async getLeadContact(id: number): Promise<LeadContact | undefined> {
    const [contact] = await db.select().from(leadContacts).where(eq(leadContacts.id, id));
    return contact || undefined;
  }

  async getLeadContactsByLead(leadId: number): Promise<LeadContact[]> {
    return await db.select().from(leadContacts).where(eq(leadContacts.leadId, leadId));
  }

  async createLeadContact(contact: InsertLeadContact): Promise<LeadContact> {
    const [newContact] = await db.insert(leadContacts).values(contact).returning();
    return newContact;
  }

  async updateLeadContact(id: number, contact: Partial<InsertLeadContact>): Promise<LeadContact | undefined> {
    const [updatedContact] = await db
      .update(leadContacts)
      .set(contact)
      .where(eq(leadContacts.id, id))
      .returning();
    return updatedContact || undefined;
  }

  async deleteLeadContact(id: number): Promise<boolean> {
    const result = await db.delete(leadContacts).where(eq(leadContacts.id, id));
    return !!result;
  }

  // Lost Reason Management
  async getLostReason(id: number): Promise<LostReason | undefined> {
    const [reason] = await db.select().from(lostReasons).where(eq(lostReasons.id, id));
    return reason || undefined;
  }

  async getLostReasonByLead(leadId: number): Promise<LostReason | undefined> {
    const [reason] = await db.select().from(lostReasons).where(eq(lostReasons.leadId, leadId));
    return reason || undefined;
  }

  async createLostReason(reason: InsertLostReason): Promise<LostReason> {
    const [newReason] = await db.insert(lostReasons).values(reason).returning();
    return newReason;
  }

  // Settings Management
  async getSettings(userId: number): Promise<Setting | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.userId, userId));
    return setting || undefined;
  }

  async createSettings(setting: InsertSetting): Promise<Setting> {
    const [newSetting] = await db.insert(settings).values(setting).returning();
    return newSetting;
  }

  async updateSettings(userId: number, setting: Partial<InsertSetting>): Promise<Setting | undefined> {
    const [updatedSetting] = await db
      .update(settings)
      .set(setting)
      .where(eq(settings.userId, userId))
      .returning();
    return updatedSetting || undefined;
  }
}

export const storage = new DatabaseStorage();