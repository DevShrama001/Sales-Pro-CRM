import { type Express, Request, Response, NextFunction } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

const scryptAsync = promisify(scrypt);

// Hash password using scrypt
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Compare a password with a stored hash
async function comparePasswords(supplied: string, stored: string) {
  // If password doesn't contain salt (missing dot), it might be a direct comparison
  if (!stored.includes('.')) {
    // For legacy passwords or initial seeded accounts, do direct comparison
    return supplied === stored;
  }
  
  try {
    const [hashed, salt] = stored.split(".");
    if (!hashed || !salt) {
      // If either part is missing, fall back to direct comparison
      return supplied === stored;
    }
    
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    return timingSafeEqual(hashedBuf, suppliedBuf);
  } catch (error) {
    console.error("Password comparison error:", error);
    // As fallback, do a direct comparison for legacy accounts
    return supplied === stored;
  }
}

// Set up authentication
export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "salespro-crm-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    },
    store: storage.sessionStore
  };

  // Set up session
  app.use(session(sessionSettings));

  // Auth middleware
  const authenticate = (req: Request, res: Response, next: NextFunction) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password, fullName, email, roleId } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }

      // Hash the password before storing
      const hashedPassword = await hashPassword(password);
      
      // Create the user with hashed password
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        fullName: fullName || username,
        email: email || "",
        roleId: roleId || 3, // Default to sales exec role if not specified
        isActive: true
      });

      // Auto-login after registration
      req.session.userId = user.id;
      req.session.username = user.username;
      req.session.roleId = user.roleId;

      // Get role information
      const role = await storage.getRole(user.roleId);
      
      // Return user without password
      const { password: _, ...safeUser } = user;
      res.status(201).json({ 
        user: {
          ...safeUser,
          role
        } 
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Server error during registration" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);

      if (!user || !(await comparePasswords(password, user.password))) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      if (!user.isActive) {
        return res.status(403).json({ message: "Account is inactive" });
      }

      req.session.userId = user.id;
      req.session.username = user.username;
      req.session.roleId = user.roleId;

      // Get role information
      const role = await storage.getRole(user.roleId);
      
      const { password: _, ...safeUser } = user;
      res.json({ 
        user: {
          ...safeUser,
          role
        } 
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Server error during login" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        req.session.destroy(() => {});
        return res.status(401).json({ message: "User not found" });
      }

      // Get role information
      const role = await storage.getRole(user.roleId);
      
      const { password: _, ...safeUser } = user;
      res.json({
        ...safeUser,
        role
      });
    } catch (error) {
      console.error("Auth check error:", error);
      res.status(500).json({ message: "Server error during authentication check" });
    }
  });

  return { authenticate };
}