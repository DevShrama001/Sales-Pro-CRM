import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool } from "@neondatabase/serverless";
import * as schema from "@shared/schema";
import ws from "ws";

// Setup WebSocket for Neon database connection
if (!globalThis.WebSocket) {
  (globalThis as any).WebSocket = ws;
}

// Create database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

export const db = drizzle(pool, { schema });