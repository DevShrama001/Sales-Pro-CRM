import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import {
  insertUserSchema,
  insertRoleSchema,
  insertPipelineSchema,
  insertStageSchema,
  insertLeadFormSchema,
  insertLeadSchema,
  insertActivitySchema,
  insertLeadContactSchema,
  insertLostReasonSchema,
  insertSettingSchema
} from "@shared/schema";
import { setupAuth } from "./auth";

declare module "express-session" {
  interface SessionData {
    userId: number;
    username: string;
    roleId: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication and session
  const { authenticate } = setupAuth(app);

  // Auth routes are handled in auth.ts

  // User routes
  app.get("/api/users", authenticate, async (req, res) => {
    try {
      const users = await storage.getUsers();
      const safeUsers = users.map(({ password: _, ...user }) => user);
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/users", authenticate, async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/users/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const userData = insertUserSchema.partial().parse(req.body);
      const updatedUser = await storage.updateUser(id, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const { password: _, ...safeUser } = updatedUser;
      res.json(safeUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/users/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const result = await storage.deleteUser(id);
      if (!result) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ message: "User deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Role routes
  app.get("/api/roles", authenticate, async (req, res) => {
    try {
      const roles = await storage.getRoles();
      res.json(roles);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/roles", authenticate, async (req, res) => {
    try {
      const roleData = insertRoleSchema.parse(req.body);
      const role = await storage.createRole(roleData);
      res.status(201).json(role);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid role data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/roles/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid role ID" });
      }

      const roleData = insertRoleSchema.partial().parse(req.body);
      const updatedRole = await storage.updateRole(id, roleData);
      
      if (!updatedRole) {
        return res.status(404).json({ message: "Role not found" });
      }

      res.json(updatedRole);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid role data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Pipeline routes
  app.get("/api/pipelines", authenticate, async (req, res) => {
    try {
      const pipelines = await storage.getPipelines();
      res.json(pipelines);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/pipelines/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid pipeline ID" });
      }

      const pipeline = await storage.getPipeline(id);
      if (!pipeline) {
        return res.status(404).json({ message: "Pipeline not found" });
      }

      res.json(pipeline);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/pipelines", authenticate, async (req, res) => {
    try {
      const pipelineData = insertPipelineSchema
        .extend({ createdBy: z.number().default(req.session.userId!) })
        .parse(req.body);
      
      const pipeline = await storage.createPipeline(pipelineData);
      res.status(201).json(pipeline);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid pipeline data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/pipelines/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid pipeline ID" });
      }

      const pipelineData = insertPipelineSchema.partial().parse(req.body);
      const updatedPipeline = await storage.updatePipeline(id, pipelineData);
      
      if (!updatedPipeline) {
        return res.status(404).json({ message: "Pipeline not found" });
      }

      res.json(updatedPipeline);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid pipeline data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Stage routes
  app.get("/api/pipelines/:pipelineId/stages", authenticate, async (req, res) => {
    try {
      const pipelineId = parseInt(req.params.pipelineId);
      if (isNaN(pipelineId)) {
        return res.status(400).json({ message: "Invalid pipeline ID" });
      }

      const stages = await storage.getStagesByPipeline(pipelineId);
      res.json(stages);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/stages", authenticate, async (req, res) => {
    try {
      const stageData = insertStageSchema.parse(req.body);
      const stage = await storage.createStage(stageData);
      res.status(201).json(stage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid stage data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/stages/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid stage ID" });
      }

      const stageData = insertStageSchema.partial().parse(req.body);
      const updatedStage = await storage.updateStage(id, stageData);
      
      if (!updatedStage) {
        return res.status(404).json({ message: "Stage not found" });
      }

      res.json(updatedStage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid stage data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Lead Form routes
  app.get("/api/lead-forms", authenticate, async (req, res) => {
    try {
      const forms = await storage.getLeadForms();
      res.json(forms);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/lead-forms", authenticate, async (req, res) => {
    try {
      const formData = insertLeadFormSchema
        .extend({ createdBy: z.number().default(req.session.userId!) })
        .parse(req.body);
      
      const form = await storage.createLeadForm(formData);
      res.status(201).json(form);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid form data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/lead-forms/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid form ID" });
      }

      const formData = insertLeadFormSchema.partial().parse(req.body);
      const updatedForm = await storage.updateLeadForm(id, formData);
      
      if (!updatedForm) {
        return res.status(404).json({ message: "Form not found" });
      }

      res.json(updatedForm);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid form data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Lead routes
  app.get("/api/leads", authenticate, async (req, res) => {
    try {
      const leads = await storage.getLeads();
      res.json(leads);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/stages/:stageId/leads", authenticate, async (req, res) => {
    try {
      const stageId = parseInt(req.params.stageId);
      if (isNaN(stageId)) {
        return res.status(400).json({ message: "Invalid stage ID" });
      }

      const leads = await storage.getLeadsByStage(stageId);
      res.json(leads);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/leads/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lead ID" });
      }

      const lead = await storage.getLead(id);
      if (!lead) {
        return res.status(404).json({ message: "Lead not found" });
      }

      res.json(lead);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/leads", authenticate, async (req, res) => {
    try {
      const leadData = insertLeadSchema
        .extend({ assignedTo: z.number().default(req.session.userId!) })
        .parse(req.body);
      
      const lead = await storage.createLead(leadData);
      
      // Create an activity record for the lead creation
      await storage.createActivity({
        leadId: lead.id,
        userId: req.session.userId!,
        type: "lead_creation",
        title: "Lead Created",
        description: `Lead for ${lead.company} was created`
      });
      
      res.status(201).json(lead);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid lead data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/leads/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lead ID" });
      }

      const originalLead = await storage.getLead(id);
      if (!originalLead) {
        return res.status(404).json({ message: "Lead not found" });
      }

      const leadData = insertLeadSchema.partial().parse(req.body);
      const updatedLead = await storage.updateLead(id, leadData);
      
      // If stage changed, create an activity
      if (leadData.stageId && leadData.stageId !== originalLead.stageId) {
        const newStage = await storage.getStage(leadData.stageId);
        const oldStage = await storage.getStage(originalLead.stageId);
        
        if (newStage && oldStage) {
          await storage.createActivity({
            leadId: id,
            userId: req.session.userId!,
            type: "stage_change",
            title: "Stage Changed",
            description: `Lead moved from ${oldStage.name} to ${newStage.name}`
          });
        }
      }

      res.json(updatedLead);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid lead data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/leads/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lead ID" });
      }

      const result = await storage.deleteLead(id);
      if (!result) {
        return res.status(404).json({ message: "Lead not found" });
      }

      res.json({ message: "Lead deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Activity routes
  app.get("/api/activities", authenticate, async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const leadId = req.query.leadId ? parseInt(req.query.leadId as string) : undefined;
      
      let activities;
      if (leadId && !isNaN(leadId)) {
        activities = await storage.getActivitiesByLead(leadId);
      } else if (userId && !isNaN(userId)) {
        activities = await storage.getActivitiesByUser(userId);
      } else {
        // Return all activities (with some reasonable limit)
        const userActivities = await storage.getActivitiesByUser(req.session.userId!);
        activities = userActivities;
      }
      
      // Explicitly set content type to application/json
      res.setHeader('Content-Type', 'application/json');
      res.send(JSON.stringify(activities || []));
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/leads/:leadId/activities", authenticate, async (req, res) => {
    try {
      const leadId = parseInt(req.params.leadId);
      if (isNaN(leadId)) {
        return res.status(400).json({ message: "Invalid lead ID" });
      }

      const activities = await storage.getActivitiesByLead(leadId);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/activities", authenticate, async (req, res) => {
    try {
      const activityData = insertActivitySchema
        .extend({ userId: z.number().default(req.session.userId!) })
        .parse(req.body);
      
      const activity = await storage.createActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid activity data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/activities/:id", authenticate, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid activity ID" });
      }

      const activityData = insertActivitySchema.partial().parse(req.body);
      const updatedActivity = await storage.updateActivity(id, activityData);
      
      if (!updatedActivity) {
        return res.status(404).json({ message: "Activity not found" });
      }

      res.json(updatedActivity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid activity data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Lead Contact routes
  app.get("/api/leads/:leadId/contacts", authenticate, async (req, res) => {
    try {
      const leadId = parseInt(req.params.leadId);
      if (isNaN(leadId)) {
        return res.status(400).json({ message: "Invalid lead ID" });
      }

      const contacts = await storage.getLeadContactsByLead(leadId);
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/lead-contacts", authenticate, async (req, res) => {
    try {
      const contactData = insertLeadContactSchema.parse(req.body);
      const contact = await storage.createLeadContact(contactData);
      res.status(201).json(contact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid contact data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Lost Reason routes
  app.post("/api/lost-reasons", authenticate, async (req, res) => {
    try {
      const reasonData = insertLostReasonSchema.parse(req.body);
      const reason = await storage.createLostReason(reasonData);
      res.status(201).json(reason);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid reason data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/leads/:leadId/lost-reason", authenticate, async (req, res) => {
    try {
      const leadId = parseInt(req.params.leadId);
      if (isNaN(leadId)) {
        return res.status(400).json({ message: "Invalid lead ID" });
      }

      const reason = await storage.getLostReasonByLead(leadId);
      if (!reason) {
        return res.status(404).json({ message: "Lost reason not found" });
      }

      res.json(reason);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Settings routes
  app.get("/api/settings", authenticate, async (req, res) => {
    try {
      const settings = await storage.getSettings(req.session.userId!);
      if (!settings) {
        return res.status(404).json({ message: "Settings not found" });
      }

      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/settings", authenticate, async (req, res) => {
    try {
      const settingsData = insertSettingSchema
        .extend({ userId: z.number().default(req.session.userId!) })
        .parse(req.body);
      
      const settings = await storage.createSettings(settingsData);
      res.status(201).json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/settings", authenticate, async (req, res) => {
    try {
      const settingsData = insertSettingSchema.partial().parse(req.body);
      const updatedSettings = await storage.updateSettings(req.session.userId!, settingsData);
      
      if (!updatedSettings) {
        return res.status(404).json({ message: "Settings not found" });
      }

      res.json(updatedSettings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
