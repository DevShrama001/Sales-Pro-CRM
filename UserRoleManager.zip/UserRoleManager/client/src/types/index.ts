import { 
  User, Role, Pipeline, Stage, LeadForm, Lead, Activity, 
  LeadContact, LostReason, Setting, LeadFormField 
} from "@shared/schema";

// Extend types as needed for frontend use
export interface UserWithRole extends Omit<User, 'password'> {
  role?: Role;
}

export interface LeadWithDetails extends Lead {
  stage?: Stage;
  assignedUser?: UserWithRole;
  contacts?: LeadContact[];
  activities?: Activity[];
  lostReason?: LostReason;
}

export interface DraggableItem {
  id: number;
  type: string;
}

export interface DropResult {
  source: {
    droppableId: string;
    index: number;
  };
  destination: {
    droppableId: string;
    index: number;
  } | null;
}

export interface ThemeConfig {
  primary: string;
  variant: 'professional' | 'tint' | 'vibrant';
  appearance: 'light' | 'dark' | 'system';
  radius: number;
}

export interface NotificationSettings {
  email: boolean;
  app: boolean;
  leadUpdates: boolean;
  meetingReminders: boolean;
}

export interface UserSettings extends Setting {
  theme: ThemeConfig;
  notifications: NotificationSettings;
}

export type ViewMode = 'kanban' | 'table';

export interface MeetingFormData {
  id?: number;
  leadId: number;
  userId: number;
  type: string;
  title: string;
  description?: string;
  scheduledAt: string;
  completedAt?: string;
}

export interface LeadFormConfig {
  id?: number;
  name: string;
  fields: LeadFormField[];
  createdBy: number;
  isDefault?: boolean;
}

export interface PipelineWithStages extends Pipeline {
  stages: Stage[];
}

export interface StageWithLeads extends Stage {
  leads: Lead[];
}

export interface FormField {
  id: string;
  name: string;
  label: string;
  type: 'text' | 'email' | 'tel' | 'number' | 'select' | 'textarea' | 'date' | 'checkbox';
  required: boolean;
  placeholder?: string;
  options?: string[];
  tab?: string;
  order: number;
}

export interface LostReasonFormData {
  leadId: number;
  reason: string;
  competitor?: string;
  comments?: string;
}

export interface ChartData {
  name: string;
  value: number;
}

export interface PerformanceMetric {
  name: string;
  value: number;
  change: number;
  unit?: string;
}
