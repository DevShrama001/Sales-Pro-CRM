import React, { createContext, useContext, useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { UserWithRole } from "@/types";

interface AuthContextProps {
  user: UserWithRole | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserWithRole | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async ({ queryKey }) => {
      try {
        const url = queryKey[0] as string;
        console.log(`Auth query: GET ${url}`);
        
        const res = await fetch(url, {
          credentials: "include",
        });
        
        console.log(`Auth response: ${res.status} ${res.statusText}`);
        
        if (res.status === 401) {
          console.log("Auth: 401 Unauthorized, returning null");
          return null;
        }
        
        if (!res.ok) {
          const text = await res.text();
          console.error(`Auth error: ${res.status}`, text);
          throw new Error(`${res.status}: ${text}`);
        }
        
        return await res.json();
      } catch (error) {
        console.error("Auth query error:", error);
        throw error;
      }
    },
    retry: false
  });

  // Handle error and success states
  useEffect(() => {
    if (error) {
      setUser(null);
    } else if (data) {
      setUser(data as UserWithRole);
    }
  }, [data, error]);

  const loginMutation = useMutation({
    mutationFn: async ({ username, password }: { username: string; password: string }) => {
      try {
        const res = await apiRequest("POST", "/api/auth/login", { username, password });
        const contentType = res.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          return res.json();
        } else {
          // If not JSON, handle as an error
          const text = await res.text();
          console.error("Non-JSON response:", text);
          throw new Error("Server returned non-JSON response");
        }
      } catch (error) {
        console.error("Login error:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log("Login success:", data);
      setUser(data.user || data); // Handle both {user: {...}} and direct user object
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: "Login Successful",
        description: `Welcome back, ${(data.user || data).fullName || (data.user || data).username}`,
      });
    },
    onError: (error: Error) => {
      console.error("Login mutation error:", error);
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials",
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      try {
        const res = await apiRequest("POST", "/api/auth/logout", {});
        const contentType = res.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          return res.json();
        } else {
          // If successful but not JSON, return empty object
          return {};
        }
      } catch (error) {
        console.error("Logout error:", error);
        throw error;
      }
    },
    onSuccess: () => {
      setUser(null);
      queryClient.invalidateQueries();
      queryClient.clear();
      toast({
        title: "Logout Successful",
        description: "You have been logged out",
      });
    },
    onError: (error: Error) => {
      console.error("Logout mutation error:", error);
      toast({
        title: "Logout Failed",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const login = async (username: string, password: string) => {
    await loginMutation.mutateAsync({ username, password });
  };

  const logout = async () => {
    await logoutMutation.mutateAsync();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
