import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Stage, insertStageSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

// Get all stages from a pipeline
export function useStagesByPipeline(pipelineId: number | null) {
  return useQuery({
    queryKey: ["/api/stages/pipeline", pipelineId],
    enabled: !!pipelineId
  });
}

// Get a single stage
export function useStage(id: number | null) {
  return useQuery({
    queryKey: ["/api/stages", id],
    enabled: !!id
  });
}

// Create a stage
export function useCreateStage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (stage: z.infer<typeof insertStageSchema>) => {
      const res = await apiRequest("POST", "/api/stages", stage);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/stages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stages/pipeline", data.pipelineId] });
      toast({
        title: "Stage Created",
        description: "The stage has been successfully created."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Stage",
        description: error.message || "An error occurred while creating the stage.",
        variant: "destructive"
      });
    }
  });
}

// Update a stage
export function useUpdateStage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Stage> }) => {
      const res = await apiRequest("PATCH", `/api/stages/${id}`, data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/stages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stages", data.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/stages/pipeline", data.pipelineId] });
      toast({
        title: "Stage Updated",
        description: "The stage has been successfully updated."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Stage",
        description: error.message || "An error occurred while updating the stage.",
        variant: "destructive"
      });
    }
  });
}

// Delete a stage
export function useDeleteStage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/stages/${id}`);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/stages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stages/pipeline", data.pipelineId] });
      toast({
        title: "Stage Deleted",
        description: "The stage has been successfully deleted."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Delete Stage",
        description: error.message || "An error occurred while deleting the stage.",
        variant: "destructive"
      });
    }
  });
}

// Reorder stages
export function useReorderStages() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ pipelineId, stageIds }: { pipelineId: number; stageIds: number[] }) => {
      const res = await apiRequest("POST", `/api/stages/reorder`, { pipelineId, stageIds });
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/stages/pipeline", data.pipelineId] });
      toast({
        title: "Stages Reordered",
        description: "The stages have been successfully reordered."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Reorder Stages",
        description: error.message || "An error occurred while reordering stages.",
        variant: "destructive"
      });
    }
  });
}