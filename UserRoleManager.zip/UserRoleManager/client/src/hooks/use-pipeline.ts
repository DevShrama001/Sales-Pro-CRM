import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Pipeline, Stage } from "@shared/schema";

// Get all pipelines
export function usePipelines() {
  return useQuery({
    queryKey: ["/api/pipelines"],
  });
}

// Get a specific pipeline
export function usePipeline(id: number | null) {
  return useQuery({
    queryKey: [`/api/pipelines/${id}`],
    enabled: !!id,
  });
}

// Get stages for a pipeline
export function usePipelineStages(pipelineId: number | null) {
  return useQuery({
    queryKey: [`/api/pipelines/${pipelineId}/stages`],
    enabled: !!pipelineId,
  });
}

// Create a new pipeline
export function useCreatePipeline() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (pipeline: Partial<Pipeline>) => {
      const res = await apiRequest("POST", "/api/pipelines", pipeline);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/pipelines"] });
      toast({
        title: "Pipeline Created",
        description: `Pipeline ${data.name} has been created`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Pipeline",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Update a pipeline
export function useUpdatePipeline() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Pipeline> }) => {
      const res = await apiRequest("PATCH", `/api/pipelines/${id}`, data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/pipelines"] });
      queryClient.invalidateQueries({ queryKey: [`/api/pipelines/${data.id}`] });
      toast({
        title: "Pipeline Updated",
        description: `Pipeline ${data.name} has been updated`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Pipeline",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Create a new stage
export function useCreateStage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (stage: Partial<Stage>) => {
      const res = await apiRequest("POST", "/api/stages", stage);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/pipelines/${data.pipelineId}/stages`] });
      toast({
        title: "Stage Created",
        description: `Stage ${data.name} has been created`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Stage",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Update a stage
export function useUpdateStage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Stage> }) => {
      const res = await apiRequest("PATCH", `/api/stages/${id}`, data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/pipelines/${data.pipelineId}/stages`] });
      toast({
        title: "Stage Updated",
        description: `Stage ${data.name} has been updated`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Stage",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Reorder stages
export function useReorderStages() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      pipelineId, 
      stageOrder 
    }: { 
      pipelineId: number; 
      stageOrder: { id: number; order: number }[] 
    }) => {
      // Update each stage with its new order
      const promises = stageOrder.map(stage => 
        apiRequest("PATCH", `/api/stages/${stage.id}`, { order: stage.order })
      );
      
      await Promise.all(promises);
      return { success: true };
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [`/api/pipelines/${variables.pipelineId}/stages`] });
      toast({
        title: "Stages Reordered",
        description: "The pipeline stages have been reordered",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Reorder Stages",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
