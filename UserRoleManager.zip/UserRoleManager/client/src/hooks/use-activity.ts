/**
 * Activity Hooks Module
 * 
 * This module provides custom React hooks for managing activities in the CRM.
 * Activities include meetings, calls, notes, follow-ups, etc. related to leads.
 * The hooks use React Query for data fetching and state management.
 */

// Import necessary libraries and utilities
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"; // React Query hooks
import { Activity, insertActivitySchema } from "@shared/schema"; // Activity types and validation schema
import { apiRequest } from "@/lib/queryClient"; // API request utility
import { useToast } from "@/hooks/use-toast"; // Toast notification hook
import { z } from "zod"; // Validation library

/**
 * Hook to fetch all activities across the CRM
 * 
 * @returns Query result containing activities data, loading state, and error state
 */
export function useActivities() {
  return useQuery({
    queryKey: ["/api/activities"], // Unique identifier for this query in the cache
  });
}

/**
 * Hook to fetch activities related to a specific lead
 * 
 * @param leadId - ID of the lead to fetch activities for (can be null)
 * @returns Query result containing lead-specific activities
 */
export function useActivitiesByLead(leadId: number | null) {
  return useQuery({
    queryKey: ["/api/activities/lead", leadId], // Cache key includes leadId for uniqueness
    enabled: !!leadId, // Only run query if leadId is provided (not null)
  });
}

/**
 * Hook to fetch activities created by or assigned to a specific user
 * 
 * @param userId - ID of the user to fetch activities for (can be null)
 * @returns Query result containing user-specific activities
 */
export function useActivitiesByUser(userId: number | null) {
  return useQuery({
    queryKey: ["/api/activities/user", userId], // Cache key includes userId for uniqueness
    enabled: !!userId, // Only run query if userId is provided (not null)
  });
}

/**
 * Hook to fetch a single activity by its ID
 * 
 * @param id - ID of the activity to fetch (can be null)
 * @returns Query result containing single activity data
 */
export function useActivity(id: number | null) {
  return useQuery({
    queryKey: ["/api/activities", id], // Cache key includes activity ID for uniqueness
    enabled: !!id, // Only run query if ID is provided (not null)
  });
}

/**
 * Hook to create a new activity
 * 
 * Used for creating meetings, notes, follow-ups, etc.
 * 
 * @returns Mutation object with mutate function and status flags
 */
export function useCreateActivity() {
  // Get query client for cache invalidation
  const queryClient = useQueryClient();
  // Get toast notification function
  const { toast } = useToast();

  return useMutation({
    // Define the mutation function that makes the API request
    mutationFn: async (activity: z.infer<typeof insertActivitySchema>) => {
      // Make POST request to create activity
      const res = await apiRequest("POST", "/api/activities", activity);
      // Parse JSON response
      return await res.json();
    },
    // Handle successful creation
    onSuccess: () => {
      // Invalidate activities cache to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      // Show success notification
      toast({
        title: "Activity Created",
        description: "The activity has been successfully created.",
      });
    },
    // Handle creation errors
    onError: (error: Error) => {
      // Show error notification
      toast({
        title: "Failed to Create Activity",
        description: error.message || "An error occurred while creating the activity.",
        variant: "destructive", // Red styling for error
      });
    },
  });
}

/**
 * Hook to update an existing activity
 * 
 * Used for updating meeting details, marking as complete, etc.
 * 
 * @returns Mutation object with mutate function and status flags
 */
export function useUpdateActivity() {
  // Get query client for cache invalidation
  const queryClient = useQueryClient();
  // Get toast notification function
  const { toast } = useToast();

  return useMutation({
    // Define the mutation function that makes the API request
    mutationFn: async ({ id, data }: { id: number; data: Partial<Activity> }) => {
      // Make PATCH request to update specific activity
      const res = await apiRequest("PATCH", `/api/activities/${id}`, data);
      // Parse JSON response
      return await res.json();
    },
    // Handle successful update
    onSuccess: (data) => {
      // Invalidate multiple related caches to ensure data consistency
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] }); // All activities
      queryClient.invalidateQueries({ queryKey: ["/api/activities", data.id] }); // Specific activity
      queryClient.invalidateQueries({ queryKey: ["/api/activities/lead", data.leadId] }); // Lead activities
      queryClient.invalidateQueries({ queryKey: ["/api/activities/user", data.userId] }); // User activities
      // Show success notification
      toast({
        title: "Activity Updated",
        description: "The activity has been successfully updated.",
      });
    },
    // Handle update errors
    onError: (error: Error) => {
      // Show error notification
      toast({
        title: "Failed to Update Activity",
        description: error.message || "An error occurred while updating the activity.",
        variant: "destructive", // Red styling for error
      });
    },
  });
}

/**
 * Hook to delete an existing activity
 * 
 * @returns Mutation object with mutate function and status flags
 */
export function useDeleteActivity() {
  // Get query client for cache invalidation
  const queryClient = useQueryClient();
  // Get toast notification function
  const { toast } = useToast();

  return useMutation({
    // Define the mutation function that makes the API request
    mutationFn: async (id: number) => {
      // Make DELETE request to remove activity
      const res = await apiRequest("DELETE", `/api/activities/${id}`);
      // Parse JSON response
      return await res.json();
    },
    // Handle successful deletion
    onSuccess: (_, id) => {
      // Invalidate related caches
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] }); // All activities 
      queryClient.invalidateQueries({ queryKey: ["/api/activities", id] }); // Specific activity
      // Show success notification
      toast({
        title: "Activity Deleted",
        description: "The activity has been successfully deleted.",
      });
    },
    // Handle deletion errors
    onError: (error: Error) => {
      // Show error notification
      toast({
        title: "Failed to Delete Activity",
        description: error.message || "An error occurred while deleting the activity.",
        variant: "destructive", // Red styling for error
      });
    },
  });
}