import { useAuth } from '@/hooks/use-auth';

// Custom hook that provides only the data needed from the auth context
export function useUser() {
  const { user, isLoading } = useAuth();
  
  return {
    user,
    isLoading,
    error: null
  };
}