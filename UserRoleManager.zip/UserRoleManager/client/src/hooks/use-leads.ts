import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Lead, Stage } from "@shared/schema";
import { LostReasonFormData } from "@/types";

// Get all leads
export function useLeads() {
  return useQuery({
    queryKey: ["/api/leads"],
  });
}

// Get leads by stage
export function useLeadsByStage(stageId: number) {
  return useQuery({
    queryKey: [`/api/stages/${stageId}/leads`],
    enabled: !!stageId,
  });
}

// Get a specific lead
export function useLead(id: number | null) {
  return useQuery({
    queryKey: [`/api/leads/${id}`],
    enabled: !!id,
  });
}

// Create a new lead
export function useCreateLead() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (lead: Partial<Lead>) => {
      const res = await apiRequest("POST", "/api/leads", lead);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      queryClient.invalidateQueries({ queryKey: [`/api/stages/${data.stageId}/leads`] });
      toast({
        title: "Lead Created",
        description: `Lead for ${data.company} has been created`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Update a lead
export function useUpdateLead() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Lead> }) => {
      const res = await apiRequest("PATCH", `/api/leads/${id}`, data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      queryClient.invalidateQueries({ queryKey: [`/api/leads/${data.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/stages/${data.stageId}/leads`] });
      toast({
        title: "Lead Updated",
        description: `Lead for ${data.company} has been updated`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Delete a lead
export function useDeleteLead() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/leads/${id}`, undefined);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      queryClient.invalidateQueries({ queryKey: [`/api/leads/${variables}`] });
      toast({
        title: "Lead Deleted",
        description: "The lead has been deleted",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Delete Lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Move a lead to a different stage
export function useMoveLeadToStage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ leadId, stageId, formData }: { leadId: number; stageId: number; formData?: Record<string, any> }) => {
      const res = await apiRequest("PATCH", `/api/leads/${leadId}`, { 
        stageId,
        ...formData
      });
      return res.json();
    },
    onSuccess: (data, variables) => {
      // Invalidate general lead queries
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      queryClient.invalidateQueries({ queryKey: [`/api/leads/${variables.leadId}`] });
      
      // Invalidate previous stage leads and new stage leads
      if (data && data.stageId) {
        // Current stage (after move)
        queryClient.invalidateQueries({ queryKey: [`/api/stages/${data.stageId}/leads`] });
      }
      
      // If moving from one stage to another, also invalidate the source stage
      if (data && data.stageId !== variables.stageId) {
        // Previous stage
        queryClient.invalidateQueries({ queryKey: [`/api/stages/${variables.stageId}/leads`] });
      }
      
      toast({
        title: "Lead Moved",
        description: "The lead has been moved to a new stage",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Move Lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Submit lost reason
export function useSubmitLostReason() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: LostReasonFormData) => {
      const res = await apiRequest("POST", "/api/lost-reasons", data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [`/api/leads/${variables.leadId}/lost-reason`] });
      toast({
        title: "Lost Reason Submitted",
        description: "Thank you for the feedback",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Submit",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Get lead activities
export function useLeadActivities(leadId: number | null) {
  return useQuery({
    queryKey: [`/api/leads/${leadId}/activities`],
    enabled: !!leadId,
  });
}

// Get lead contacts
export function useLeadContacts(leadId: number | null) {
  return useQuery({
    queryKey: [`/api/leads/${leadId}/contacts`],
    enabled: !!leadId,
  });
}

// Get lost reason for a lead
export function useLostReason(leadId: number | null) {
  return useQuery({
    queryKey: [`/api/leads/${leadId}/lost-reason`],
    enabled: !!leadId,
  });
}
