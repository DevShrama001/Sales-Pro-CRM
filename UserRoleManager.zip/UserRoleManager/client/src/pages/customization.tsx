import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PipelineForm from "@/components/pipeline/pipeline-form";
import StageForm from "@/components/pipeline/stage-form";
import CustomizableForm from "@/components/forms/customizable-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";

export default function Customization() {
  const [activeTab, setActiveTab] = useState("pipelines");
  const { user } = useAuth();
  
  // Check if user is admin
  const isAdmin = user?.roleId === 1;
  
  // Fetch pipelines
  const { data: pipelines } = useQuery({
    queryKey: ["/api/pipelines"],
  });
  
  // Fetch lead forms
  const { data: leadForms } = useQuery({
    queryKey: ["/api/lead-forms"],
  });
  
  if (!isAdmin) {
    return (
      <div className="flex min-h-screen bg-background">
        <Sidebar />
        
        <div className="flex-1 flex flex-col">
          <Header title="Customization" />
          
          <main className="flex-1 overflow-auto p-4 md:p-6">
            <Card>
              <CardContent className="p-10 text-center">
                <h2 className="text-xl font-bold mb-2">Access Restricted</h2>
                <p className="text-muted-foreground">
                  You don't have permission to access customization features.
                  Please contact your administrator for assistance.
                </p>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="Customization" />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <Card>
            <CardHeader>
              <CardTitle>System Customization</CardTitle>
              <CardDescription>
                Customize your CRM to match your business processes
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <Tabs defaultValue="pipelines" value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-6">
                  <TabsTrigger value="pipelines">Sales Pipelines</TabsTrigger>
                  <TabsTrigger value="stages">Pipeline Stages</TabsTrigger>
                  <TabsTrigger value="forms">Lead Forms</TabsTrigger>
                </TabsList>
                
                <TabsContent value="pipelines">
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-medium">Manage Pipelines</h3>
                      
                      <Button variant="outline" size="sm">
                        Add New Pipeline
                      </Button>
                    </div>
                    
                    <div className="grid gap-4">
                      {pipelines && pipelines.map((pipeline: any) => (
                        <Card key={pipeline.id} className="overflow-hidden">
                          <CardHeader className="p-4 pb-2">
                            <div className="flex justify-between items-center">
                              <div>
                                <CardTitle className="text-base">{pipeline.name}</CardTitle>
                                <CardDescription className="text-sm">
                                  {pipeline.description || "No description provided"}
                                </CardDescription>
                              </div>
                              <div className="flex gap-2">
                                <Button variant="ghost" size="sm">Edit</Button>
                                {!pipeline.isDefault && (
                                  <Button variant="ghost" size="sm" className="text-destructive">Delete</Button>
                                )}
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="p-4 pt-0">
                            <div className="text-xs mt-2">
                              {pipeline.isDefault && (
                                <span className="bg-primary/10 text-primary px-2 py-1 rounded text-xs">
                                  Default Pipeline
                                </span>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                    
                    <PipelineForm />
                  </div>
                </TabsContent>
                
                <TabsContent value="stages">
                  <div className="space-y-6">
                    <StageForm pipelines={pipelines || []} />
                  </div>
                </TabsContent>
                
                <TabsContent value="forms">
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-medium">Manage Lead Forms</h3>
                      
                      <Button variant="outline" size="sm">
                        Create New Form
                      </Button>
                    </div>
                    
                    <div className="grid gap-4">
                      {leadForms && leadForms.map((form: any) => (
                        <Card key={form.id} className="overflow-hidden">
                          <CardHeader className="p-4 pb-2">
                            <div className="flex justify-between items-center">
                              <div>
                                <CardTitle className="text-base">{form.name}</CardTitle>
                                <CardDescription className="text-sm">
                                  {form.fields.length} fields
                                </CardDescription>
                              </div>
                              <div className="flex gap-2">
                                <Button variant="ghost" size="sm">Edit</Button>
                                {!form.isDefault && (
                                  <Button variant="ghost" size="sm" className="text-destructive">Delete</Button>
                                )}
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="p-4 pt-0">
                            <div className="text-xs mt-2">
                              {form.isDefault && (
                                <span className="bg-primary/10 text-primary px-2 py-1 rounded text-xs">
                                  Default Form
                                </span>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                    
                    <CustomizableForm />
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
