import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ThemeSettings from "@/components/settings/theme-settings";
import NotificationSettings from "@/components/settings/notification-settings";
import RoleManagement from "@/components/settings/role-management";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("general");
  const { user } = useAuth();
  
  // Fetch user settings
  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
  });
  
  // Check if user is admin
  const isAdmin = user?.roleId === 1;

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="Settings" />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <Card>
            <CardHeader>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>
                Configure your CRM system settings and preferences
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-6">
                  <TabsTrigger value="general">General</TabsTrigger>
                  <TabsTrigger value="appearance">Appearance</TabsTrigger>
                  <TabsTrigger value="notifications">Notifications</TabsTrigger>
                  {isAdmin && <TabsTrigger value="roles">Role Management</TabsTrigger>}
                </TabsList>
                
                <TabsContent value="general">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium">Personal Information</h3>
                      <p className="text-sm text-muted-foreground">
                        Update your account details and personal information
                      </p>
                      
                      <div className="mt-4 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-1">Full Name</label>
                            <input 
                              type="text" 
                              className="w-full border border-border rounded px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="Your full name"
                              value={user?.fullName || ""}
                              disabled
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-1">Email</label>
                            <input 
                              type="email" 
                              className="w-full border border-border rounded px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="Your email address"
                              value={user?.email || ""}
                              disabled
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium mb-1">Username</label>
                          <input 
                            type="text" 
                            className="w-full border border-border rounded px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary"
                            placeholder="Your username"
                            value={user?.username || ""}
                            disabled
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium">Password</h3>
                      <p className="text-sm text-muted-foreground">
                        Update your password to secure your account
                      </p>
                      
                      <div className="mt-4 space-y-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Current Password</label>
                          <input 
                            type="password" 
                            className="w-full border border-border rounded px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary"
                            placeholder="Enter current password"
                          />
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-1">New Password</label>
                            <input 
                              type="password" 
                              className="w-full border border-border rounded px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="Enter new password"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-1">Confirm New Password</label>
                            <input 
                              type="password" 
                              className="w-full border border-border rounded px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="Confirm new password"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <button className="px-4 py-2 bg-primary text-primary-foreground rounded hover:bg-primary/90">
                            Update Password
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="appearance">
                  <ThemeSettings settings={settings} />
                </TabsContent>
                
                <TabsContent value="notifications">
                  <NotificationSettings settings={settings} />
                </TabsContent>
                
                {isAdmin && (
                  <TabsContent value="roles">
                    <RoleManagement />
                  </TabsContent>
                )}
              </Tabs>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
