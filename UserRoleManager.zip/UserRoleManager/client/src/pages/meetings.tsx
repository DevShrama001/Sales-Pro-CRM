// Import necessary libraries and components
import { useState } from "react"; // For state management
import { 
  Tabs, // Tab container component
  TabsContent, // Content container for each tab 
  TabsList, // List container for tab triggers
  TabsTrigger // Clickable tab element
} from "@/components/ui/tabs"; // Tab components from UI library
import CalendarView from "@/components/meetings/calendar-view"; // Calendar view component
import { useAuth } from "@/hooks/use-auth"; // Authentication hook
import { useActivities } from "@/hooks/use-activity"; // Activities data hook
import { Card, CardContent } from "@/components/ui/card"; // Card components
import { Button } from "@/components/ui/button"; // Button component
import { format } from "date-fns"; // Date formatting utility
import { 
  Check, // Checkmark icon
  Clock, // Clock icon
  Calendar, // Calendar icon
  Loader2 // Loading spinner icon
} from "lucide-react"; // Icon library

// Main Meetings page component
export default function MeetingsPage() {
  // Get the current authenticated user
  const { user } = useAuth();
  
  // Fetch all activities data
  // data: activities - The list of activities from the API
  // isLoading - Loading state indicator
  const { data: activities, isLoading } = useActivities();
  
  // State to track the active tab ("calendar" or "list")
  const [activeTab, setActiveTab] = useState("calendar");
  
  // Filter activities to get upcoming meetings
  // - Must be of type "meeting"
  // - Must have a scheduled date
  // - Must not be marked as completed
  // - Scheduled date must be in the future
  const upcomingMeetings = activities?.filter((activity: any) => 
    activity.type === "meeting" && 
    activity.scheduledAt && 
    !activity.completedAt && 
    new Date(activity.scheduledAt) > new Date()
  ) || []; // Default to empty array if activities is undefined
  
  // Filter activities to get past meetings
  // - Must be of type "meeting"
  // - Either completed OR scheduled date is in the past
  const pastMeetings = activities?.filter((activity: any) => 
    activity.type === "meeting" && 
    (activity.completedAt || 
      (activity.scheduledAt && new Date(activity.scheduledAt) < new Date())
    )
  ) || []; // Default to empty array if activities is undefined
  
  // Handler to mark a meeting as completed
  // This is a placeholder function that would be connected to an API call
  const handleMarkComplete = (activityId: number) => {
    // TODO: Implement the API call to update the meeting status
    // This would call the updateActivity mutation to set completedAt to current date
    console.log("Marking activity as complete:", activityId);
  };
  
  // Render the meetings page
  return (
    // Main container with padding
    <div className="container py-6">
      {/* Page header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Meetings</h1>
      </div>
      
      {/* Tabs component for switching between calendar and list views */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        {/* Tab navigation buttons */}
        <TabsList className="mb-6">
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
          <TabsTrigger value="list">Meeting List</TabsTrigger>
        </TabsList>
        
        {/* Calendar tab content */}
        <TabsContent value="calendar">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            {/* Render the calendar view component */}
            <CalendarView />
          </div>
        </TabsContent>
        
        {/* List tab content */}
        <TabsContent value="list">
          <div className="space-y-6">
            {/* Upcoming meetings section */}
            <div>
              <h2 className="text-xl font-semibold mb-4">Upcoming Meetings</h2>
              
              {/* Show loading spinner, empty state, or meetings list */}
              {isLoading ? (
                // Show loading spinner when data is being fetched
                <div className="flex justify-center py-10">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : upcomingMeetings.length === 0 ? (
                // Show empty state when no upcoming meetings exist
                <Card>
                  <CardContent className="p-6 text-center text-muted-foreground">
                    <Calendar className="h-10 w-10 mx-auto mb-2 opacity-40" />
                    <p>No upcoming meetings scheduled</p>
                  </CardContent>
                </Card>
              ) : (
                // Show list of upcoming meetings
                <div className="space-y-4">
                  {/* Map over each meeting to create cards */}
                  {upcomingMeetings.map((meeting: any) => (
                    <Card key={meeting.id}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          {/* Meeting details */}
                          <div>
                            {/* Meeting title */}
                            <h3 className="font-medium">{meeting.title}</h3>
                            {/* Meeting date and time */}
                            <div className="flex items-center text-sm text-muted-foreground mt-1">
                              <Clock className="h-4 w-4 mr-1" />
                              <span>{format(new Date(meeting.scheduledAt), "PPp")}</span>
                            </div>
                            {/* Meeting location (if exists) */}
                            {meeting.customFields?.location && (
                              <p className="text-sm text-muted-foreground mt-1">
                                Location: {meeting.customFields.location}
                              </p>
                            )}
                            {/* Meeting description (if exists) */}
                            {meeting.description && (
                              <p className="text-sm mt-2">{meeting.description}</p>
                            )}
                          </div>
                          {/* Mark complete button */}
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="ml-4"
                            onClick={() => handleMarkComplete(meeting.id)}
                          >
                            <Check className="h-4 w-4 mr-2" />
                            Mark Complete
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
            
            {/* Past meetings section */}
            <div>
              <h2 className="text-xl font-semibold mb-4">Past Meetings</h2>
              
              {/* Show loading spinner, empty state, or meetings list */}
              {isLoading ? (
                // Show loading spinner when data is being fetched
                <div className="flex justify-center py-10">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : pastMeetings.length === 0 ? (
                // Show empty state when no past meetings exist
                <Card>
                  <CardContent className="p-6 text-center text-muted-foreground">
                    <Calendar className="h-10 w-10 mx-auto mb-2 opacity-40" />
                    <p>No past meetings found</p>
                  </CardContent>
                </Card>
              ) : (
                // Show list of past meetings
                <div className="space-y-4">
                  {/* Map over each meeting to create cards */}
                  {pastMeetings.map((meeting: any) => (
                    // Apply opacity to past meetings for visual differentiation
                    <Card key={meeting.id} className="opacity-75">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          {/* Meeting details */}
                          <div>
                            {/* Meeting title */}
                            <h3 className="font-medium">{meeting.title}</h3>
                            {/* Meeting date and time */}
                            <div className="flex items-center text-sm text-muted-foreground mt-1">
                              <Clock className="h-4 w-4 mr-1" />
                              <span>{format(new Date(meeting.scheduledAt), "PPp")}</span>
                            </div>
                            {/* Meeting location (if exists) */}
                            {meeting.customFields?.location && (
                              <p className="text-sm text-muted-foreground mt-1">
                                Location: {meeting.customFields.location}
                              </p>
                            )}
                            {/* Meeting description (if exists) */}
                            {meeting.description && (
                              <p className="text-sm mt-2">{meeting.description}</p>
                            )}
                          </div>
                          {/* Completion status indicator */}
                          {meeting.completedAt ? (
                            // Show completed indicator if marked as completed
                            <div className="text-xs text-emerald-600 flex items-center">
                              <Check className="h-3 w-3 mr-1" />
                              Completed
                            </div>
                          ) : (
                            // Show not completed indicator if not marked as completed
                            <div className="text-xs text-muted-foreground">
                              Not completed
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}