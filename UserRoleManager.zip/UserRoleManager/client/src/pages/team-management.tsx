import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import UserList from "@/components/team/user-list";
import UserForm from "@/components/team/user-form";
import RoleList from "@/components/team/role-list";
import RoleForm from "@/components/team/role-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Users, Shield } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Role } from "@shared/schema";

type FormType = "user" | "role";

export default function TeamManagement() {
  const [activeTab, setActiveTab] = useState("users");
  const [showForm, setShowForm] = useState(false);
  const [formType, setFormType] = useState<FormType>("user");
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [selectedRoleId, setSelectedRoleId] = useState<number | null>(null);
  const { user } = useAuth();
  
  // Check if user is admin
  const isAdmin = user?.roleId === 1;
  
  // Fetch roles for user form
  const { data: roles } = useQuery<Role[]>({
    queryKey: ["/api/roles"],
  });
  
  // Toggle user form
  const toggleUserForm = () => {
    setShowForm(!showForm);
    setFormType("user");
    setSelectedUserId(null);
  };
  
  // Toggle role form
  const toggleRoleForm = () => {
    setShowForm(!showForm);
    setFormType("role");
    setSelectedRoleId(null);
  };
  
  // Handle user selection for editing
  const handleEditUser = (userId: number) => {
    setSelectedUserId(userId);
    setFormType("user");
    setShowForm(true);
  };
  
  // Handle role selection for editing
  const handleEditRole = (roleId: number) => {
    setSelectedRoleId(roleId);
    setFormType("role");
    setShowForm(true);
  };
  
  // Handle form submission completion
  const handleFormComplete = () => {
    setShowForm(false);
    setSelectedUserId(null);
    setSelectedRoleId(null);
  };

  if (!isAdmin) {
    return (
      <div className="flex min-h-screen bg-background">
        <Sidebar />
        
        <div className="flex-1 flex flex-col">
          <Header title="Team Management" />
          
          <main className="flex-1 overflow-auto p-4 md:p-6">
            <Card>
              <CardContent className="p-10 text-center">
                <h2 className="text-xl font-bold mb-2">Access Restricted</h2>
                <p className="text-muted-foreground">
                  You don't have permission to access team management features.
                  Please contact your administrator for assistance.
                </p>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    );
  }
  
  // Form title and description based on form type and edit mode
  const getFormDetails = () => {
    if (formType === "user") {
      return {
        title: selectedUserId ? "Edit User" : "Add New User",
        description: selectedUserId ? "Update existing user details" : "Create a new user account",
        backText: "Back to Users"
      };
    } else {
      return {
        title: selectedRoleId ? "Edit Role" : "Add New Role",
        description: selectedRoleId ? "Update existing role details" : "Create a new role with permissions",
        backText: "Back to Roles"
      };
    }
  };
  
  const formDetails = getFormDetails();

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="Team Management" />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          {showForm ? (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>{formDetails.title}</CardTitle>
                  <CardDescription>
                    {formDetails.description}
                  </CardDescription>
                </div>
                <Button variant="outline" onClick={() => setShowForm(false)}>
                  {formDetails.backText}
                </Button>
              </CardHeader>
              <CardContent>
                {formType === "user" ? (
                  <UserForm 
                    userId={selectedUserId} 
                    roles={roles || []} 
                    onComplete={handleFormComplete} 
                  />
                ) : (
                  <RoleForm
                    roleId={selectedRoleId}
                    onComplete={handleFormComplete}
                  />
                )}
              </CardContent>
            </Card>
          ) : (
            <Tabs defaultValue="users" value={activeTab} onValueChange={setActiveTab}>
              <div className="flex justify-between items-center mb-6">
                <TabsList>
                  <TabsTrigger value="users" className="flex items-center">
                    <Users className="mr-2 h-4 w-4" />
                    Users
                  </TabsTrigger>
                  <TabsTrigger value="roles" className="flex items-center">
                    <Shield className="mr-2 h-4 w-4" />
                    Roles
                  </TabsTrigger>
                </TabsList>
                
                {activeTab === "users" ? (
                  <Button onClick={toggleUserForm}>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Add User
                  </Button>
                ) : (
                  <Button onClick={toggleRoleForm}>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Add Role
                  </Button>
                )}
              </div>
              
              <TabsContent value="users" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Team Members</CardTitle>
                    <CardDescription>
                      Manage user accounts and access permissions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <UserList onEditUser={handleEditUser} />
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="roles" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Roles</CardTitle>
                    <CardDescription>
                      Manage roles and their permissions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <RoleList onEditRole={handleEditRole} />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </main>
      </div>
    </div>
  );
}
