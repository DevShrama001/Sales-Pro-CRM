import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Zap, Loader2, UserPlus, LogIn } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  fullName: z.string().min(1, "Full name is required"),
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormData = z.infer<typeof loginSchema>;
type RegisterFormData = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, isAuthenticated, isLoading, login } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<string>("login");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Redirect if already authenticated
    if (isAuthenticated && user) {
      navigate("/");
    }
  }, [isAuthenticated, user, navigate]);

  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      fullName: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const onLoginSubmit = async (data: LoginFormData) => {
    setIsSubmitting(true);
    setError(null);
    
    try {
      console.log("Login attempt with:", data.username, "password length:", data.password.length);
      
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: data.username,
          password: data.password
        }),
        credentials: "include",
      });
      
      console.log("Login response status:", response.status, response.statusText);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("Login error response:", errorText);
        throw new Error(errorText || `Login failed with status ${response.status}`);
      }
      
      // Successfully logged in, parse the response
      const userData = await response.json();
      console.log("Login successful with user data:", userData);
      
      // Force a page reload to ensure all authentication state is refreshed
      window.location.href = "/";
    } catch (err) {
      console.error("Login error in auth-page:", err);
      
      let errorMessage = "Login failed. Please try again.";
      if (err instanceof Error) {
        // Try to parse error message if it's JSON
        try {
          const jsonError = JSON.parse(err.message);
          errorMessage = jsonError.message || err.message;
        } catch {
          errorMessage = err.message;
        }
      }
      
      setError(errorMessage);
      
      // Check for unauthorized and provide a clear message
      if (errorMessage.includes("Invalid credentials") || errorMessage.includes("401")) {
        setError("Please check your username and password. Try username 'testadmin' with password 'password123'");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const onRegisterSubmit = async (data: RegisterFormData) => {
    setIsSubmitting(true);
    setError(null);
    
    try {
      // First register the user
      const { confirmPassword, ...registerData } = data;
      console.log("Registration attempt with:", registerData.username);
      
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...registerData,
          roleId: 3, // Default to sales executive role (adjust as needed)
          isActive: true,
        }),
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("Registration error:", response.status, errorText);
        throw new Error(errorText || `Registration failed with status ${response.status}`);
      }
      
      console.log("Registration successful");
      
      // Then log them in (not needed since registration auto-logs in)
      // await login(data.username, data.password);
      
      // Navigate to dashboard since we're already logged in after registration
      navigate("/");
    } catch (err) {
      console.error("Registration error in auth-page:", err);
      let errorMessage = err instanceof Error ? err.message : "Registration failed. Please try again.";
      
      // Handle specific errors
      if (errorMessage.includes("Username already exists")) {
        errorMessage = "This username is already taken. Please choose another one.";
      }
      
      setError(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  // If still checking auth status, show loading
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen grid md:grid-cols-2">
      {/* Auth Form */}
      <div className="flex items-center justify-center p-4 md:p-8">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1 text-center">
            <div className="flex justify-center mb-2">
              <div className="p-2 rounded-full bg-primary text-primary-foreground">
                <Zap size={24} />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold">SalesPro CRM</CardTitle>
            <CardDescription>Sales management simplified</CardDescription>
          </CardHeader>
          
          <CardContent>
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                <FormField
                  control={loginForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your username" 
                          {...field} 
                          disabled={isSubmitting}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Enter your password" 
                          {...field} 
                          disabled={isSubmitting}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {error && (
                  <div className="text-sm text-destructive">{error}</div>
                )}
                
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  <LogIn className="mr-2 h-4 w-4" />
                  Log In
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="text-center text-sm text-muted-foreground">
            <p className="w-full">
              Login with: testadmin / password123
            </p>
          </CardFooter>
        </Card>
      </div>
      
      {/* Hero Section */}
      <div className="hidden md:flex flex-col items-center justify-center p-8 bg-muted/40">
        <div className="max-w-lg space-y-4">
          <h1 className="text-4xl font-extrabold tracking-tight">
            Transform Your Sales Process
          </h1>
          <p className="text-muted-foreground text-lg">
            SalesPro CRM helps you manage leads, track deals, and close more sales with powerful pipelines and insightful analytics.
          </p>
          
          <div className="grid grid-cols-2 gap-4 py-8">
            <div className="flex flex-col space-y-2">
              <h3 className="font-semibold">Lead Management</h3>
              <p className="text-sm text-muted-foreground">Track and nurture leads through every stage of the sales process</p>
            </div>
            <div className="flex flex-col space-y-2">
              <h3 className="font-semibold">Team Collaboration</h3>
              <p className="text-sm text-muted-foreground">Assign roles and responsibilities to your entire sales team</p>
            </div>
            <div className="flex flex-col space-y-2">
              <h3 className="font-semibold">Custom Pipelines</h3>
              <p className="text-sm text-muted-foreground">Create and customize sales pipelines that fit your business</p>
            </div>
            <div className="flex flex-col space-y-2">
              <h3 className="font-semibold">Performance Analytics</h3>
              <p className="text-sm text-muted-foreground">Gain insights with detailed reports and dashboards</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}