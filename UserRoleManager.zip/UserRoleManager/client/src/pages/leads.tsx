import { useState, useEffect } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import KanbanView from "@/components/leads/kanban-view";
import TableView from "@/components/leads/table-view";
import LeadDetails from "@/components/leads/lead-details";
import StageFormModal from "@/components/leads/stage-form-modal";
import WinCelebrationModal from "@/components/leads/win-celebration-modal";
import LossFeedbackModal from "@/components/leads/loss-feedback-modal";
import { usePipelines, usePipelineStages } from "@/hooks/use-pipeline";
import { useLeadsByStage, useLead, useMoveLeadToStage } from "@/hooks/use-leads";
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import { ViewMode } from "@/types";
import { Stage, Lead } from "@shared/schema";

export default function Leads() {
  const [viewMode, setViewMode] = useState<ViewMode>("kanban");
  const [selectedLeadId, setSelectedLeadId] = useState<number | null>(null);
  const [selectedPipelineId, setSelectedPipelineId] = useState<number | null>(null);
  const [stageFormData, setStageFormData] = useState<{
    leadId: number;
    currentStageId: number;
    targetStageId: number;
    isOpen: boolean;
  }>({
    leadId: 0,
    currentStageId: 0,
    targetStageId: 0,
    isOpen: false,
  });
  const [showWinModal, setShowWinModal] = useState(false);
  const [showLossModal, setShowLossModal] = useState(false);

  // Fetch pipelines
  const { data: pipelines, isLoading: isPipelinesLoading } = usePipelines();
  
  // Set default pipeline when data is loaded
  useEffect(() => {
    if (pipelines && pipelines.length > 0 && !selectedPipelineId) {
      // Find the default pipeline or use the first one
      const defaultPipeline = pipelines.find(p => p.isDefault) || pipelines[0];
      setSelectedPipelineId(defaultPipeline.id);
    }
  }, [pipelines, selectedPipelineId]);

  // Fetch stages for the selected pipeline
  const { data: stages, isLoading: isStagesLoading } = usePipelineStages(selectedPipelineId);
  
  // Fetch the selected lead details
  const { data: selectedLead } = useLead(selectedLeadId);
  
  // Mutation for moving a lead to a new stage
  const moveLeadMutation = useMoveLeadToStage();

  // Handle lead selection
  const handleSelectLead = (leadId: number) => {
    setSelectedLeadId(leadId);
  };

  // Handle lead stage change
  const handleMoveLeadToStage = (leadId: number, currentStageId: number, targetStageId: number) => {
    // If target stage is a "closed" stage, show appropriate modal
    const targetStage = stages?.find(s => s.id === targetStageId);
    if (targetStage) {
      if (targetStage.name.toLowerCase().includes('won')) {
        // Show win celebration modal
        setSelectedLeadId(leadId);
        setShowWinModal(true);
        return;
      }
      if (targetStage.name.toLowerCase().includes('lost')) {
        // Show loss feedback modal
        setSelectedLeadId(leadId);
        setShowLossModal(true);
        return;
      }
    }
    
    // Check if the target stage has required fields
    // If it does, show the stage form modal
    if (targetStage && targetStage.requiredFields && targetStage.requiredFields.length > 0) {
      setStageFormData({
        leadId,
        currentStageId,
        targetStageId,
        isOpen: true
      });
    } else {
      // If no required fields, move the lead directly
      moveLeadMutation.mutate({ leadId, stageId: targetStageId });
    }
  };

  // Handle stage form submission
  const handleStageFormSubmit = (formData: Record<string, any>) => {
    moveLeadMutation.mutate({ 
      leadId: stageFormData.leadId, 
      stageId: stageFormData.targetStageId,
      formData 
    });
    setStageFormData(prev => ({ ...prev, isOpen: false }));
  };

  // Handle win celebration completion
  const handleWinComplete = () => {
    // Move the lead to the won stage
    if (selectedLeadId && stages) {
      const wonStage = stages.find(s => s.name.toLowerCase().includes('won'));
      if (wonStage) {
        moveLeadMutation.mutate({ leadId: selectedLeadId, stageId: wonStage.id });
      }
    }
    setShowWinModal(false);
  };

  // Handle loss feedback submission
  const handleLossSubmit = (lostReason: { reason: string; competitor?: string; comments?: string }) => {
    // Move the lead to the lost stage and save the reason
    if (selectedLeadId && stages) {
      const lostStage = stages.find(s => s.name.toLowerCase().includes('lost'));
      if (lostStage) {
        moveLeadMutation.mutate({ 
          leadId: selectedLeadId, 
          stageId: lostStage.id,
        });
        
        // Save the lost reason
        const apiRequest = async () => {
          try {
            await fetch('/api/lost-reasons', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                leadId: selectedLeadId,
                ...lostReason
              }),
              credentials: 'include'
            });
          } catch (error) {
            console.error('Failed to save lost reason:', error);
          }
        };
        
        apiRequest();
      }
    }
    setShowLossModal(false);
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header 
          title="Sales Pipeline" 
          subtitle="Active"
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          showViewToggle={true}
        />
        
        <main className="flex-1 overflow-auto p-4">
          {/* Pipeline selector */}
          {pipelines && pipelines.length > 0 && (
            <div className="mb-4 flex items-center gap-2">
              <div className="text-sm font-medium">Pipeline:</div>
              <select 
                className="text-sm border rounded px-2 py-1"
                value={selectedPipelineId || ''}
                onChange={(e) => setSelectedPipelineId(Number(e.target.value))}
                disabled={isPipelinesLoading}
              >
                {pipelines.map(pipeline => (
                  <option key={pipeline.id} value={pipeline.id}>{pipeline.name}</option>
                ))}
              </select>
              
              {/* Add Lead Button */}
              <div className="ml-auto">
                <Button size="sm" onClick={() => console.log('Add lead clicked')}>
                  <PlusCircle className="h-4 w-4 mr-1" />
                  Add Lead
                </Button>
              </div>
            </div>
          )}
          
          {/* Render view based on selected mode */}
          {viewMode === "kanban" ? (
            <KanbanView 
              pipelineId={selectedPipelineId}
              stages={stages || []}
              onSelectLead={handleSelectLead}
              onMoveLead={handleMoveLeadToStage}
              isLoading={isStagesLoading}
            />
          ) : (
            <TableView 
              pipelineId={selectedPipelineId}
              onSelectLead={handleSelectLead}
            />
          )}
        </main>
      </div>
      
      {/* Lead details panel */}
      {selectedLeadId && (
        <LeadDetails 
          leadId={selectedLeadId} 
          onClose={() => setSelectedLeadId(null)} 
        />
      )}
      
      {/* Stage Form Modal */}
      {stageFormData.isOpen && (
        <StageFormModal 
          leadId={stageFormData.leadId}
          stageId={stageFormData.targetStageId}
          isOpen={stageFormData.isOpen}
          onClose={() => setStageFormData(prev => ({ ...prev, isOpen: false }))}
          onSubmit={handleStageFormSubmit}
        />
      )}
      
      {/* Win Celebration Modal */}
      <WinCelebrationModal 
        isOpen={showWinModal}
        lead={selectedLead as Lead}
        onClose={() => setShowWinModal(false)}
        onComplete={handleWinComplete}
      />
      
      {/* Loss Feedback Modal */}
      <LossFeedbackModal 
        isOpen={showLossModal}
        leadId={selectedLeadId || 0}
        onClose={() => setShowLossModal(false)}
        onSubmit={handleLossSubmit}
      />
    </div>
  );
}
