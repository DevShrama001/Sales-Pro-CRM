import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import StatsOverview from "@/components/dashboard/stats-overview";
import RecentActivities from "@/components/dashboard/recent-activities";
import PerformanceChart from "@/components/dashboard/performance-chart";
import UpcomingTasks from "@/components/dashboard/upcoming-tasks";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

export default function Dashboard() {
  const { user } = useAuth();
  
  // Fetch pipeline data for performance chart
  const { data: pipelines } = useQuery({
    queryKey: ["/api/pipelines"],
  });

  // Fetch activities for the current user
  const { data: activities } = useQuery({
    queryKey: [`/api/activities`],
  });

  const stats = [
    { name: "Total Leads", value: 94, change: 12, unit: "%" },
    { name: "Lead Conversion", value: 28, change: 5, unit: "%" },
    { name: "Deal Value", value: 248000, change: -3, unit: "%" },
    { name: "Avg. Response Time", value: 4.5, change: -12, unit: "hours" },
  ];

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Header title="Dashboard" />
        
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="grid gap-6">
            {/* Welcome Card */}
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h2 className="text-2xl font-bold">Welcome back, {user?.fullName?.split(' ')[0] || 'User'}</h2>
                    <p className="text-muted-foreground mt-1">
                      Here's what's happening with your sales pipeline today.
                    </p>
                  </div>
                  <div className="text-sm bg-primary/10 text-primary rounded-md px-3 py-1.5">
                    {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Stats Overview */}
            <StatsOverview stats={stats} />
            
            {/* Charts and Activity Section */}
            <div className="grid md:grid-cols-3 gap-6">
              <PerformanceChart className="md:col-span-2" />
              <UpcomingTasks className="md:col-span-1" />
            </div>
            
            {/* Recent Activities */}
            <RecentActivities />
          </div>
        </main>
      </div>
    </div>
  );
}
