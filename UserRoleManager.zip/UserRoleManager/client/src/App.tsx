import { Route, Switch } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider, useAuth } from "@/context/auth-context";

// Pages
import Dashboard from "@/pages/dashboard";
import Leads from "@/pages/leads";
import Meetings from "@/pages/meetings";
import Reports from "@/pages/reports";
import TeamManagement from "@/pages/team-management";
import Settings from "@/pages/settings";
import Customization from "@/pages/customization";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";

// Auth guard component to protect routes
function ProtectedRoute({ component: Component, ...rest }: { component: React.ComponentType<any>, [x: string]: any }) {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary rounded-full border-t-transparent"></div>
      </div>
    );
  }
  
  return isAuthenticated ? <Component {...rest} /> : <AuthPage />;
}

// Router component with auth protection
function Router() {
  const { isAuthenticated } = useAuth();
  
  return (
    <Switch>
      <Route path="/auth">
        {isAuthenticated ? <Dashboard /> : <AuthPage />}
      </Route>
      <Route path="/">
        <ProtectedRoute component={Dashboard} />
      </Route>
      <Route path="/dashboard">
        <ProtectedRoute component={Dashboard} />
      </Route>
      <Route path="/leads">
        <ProtectedRoute component={Leads} />
      </Route>
      <Route path="/meetings">
        <ProtectedRoute component={Meetings} />
      </Route>
      <Route path="/reports">
        <ProtectedRoute component={Reports} />
      </Route>
      <Route path="/team">
        <ProtectedRoute component={TeamManagement} />
      </Route>
      <Route path="/settings">
        <ProtectedRoute component={Settings} />
      </Route>
      <Route path="/customization">
        <ProtectedRoute component={Customization} />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

// The main App component which wraps everything with necessary providers
function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
