import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDateTime(date: Date | string): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleString();
}

export function formatDate(date: Date | string): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString();
}

export function formatTime(date: Date | string): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function getInitials(name: string): string {
  if (!name) return '';
  return name
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase()
    .substring(0, 2);
}

export function truncateText(text: string, maxLength: number): string {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

export function generateUniqueId(prefix: string = ''): string {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).substr(2, 5)}`;
}

export function calculateTimeAgo(date: Date | string): string {
  if (!date) return '';
  const now = new Date();
  const then = typeof date === 'string' ? new Date(date) : date;
  const seconds = Math.floor((now.getTime() - then.getTime()) / 1000);
  
  const intervals = {
    year: 31536000,
    month: 2592000,
    week: 604800,
    day: 86400,
    hour: 3600,
    minute: 60,
    second: 1
  } as const;

  for (const [unit, secondsInUnit] of Object.entries(intervals)) {
    const interval = Math.floor(seconds / secondsInUnit);
    if (interval >= 1) {
      return interval === 1 ? `1 ${unit} ago` : `${interval} ${unit}s ago`;
    }
  }
  
  return 'just now';
}

// Function to get stage background color based on its name or type
export function getStageColor(stageName: string): string {
  stageName = stageName.toLowerCase();
  if (stageName.includes('new') || stageName.includes('lead')) {
    return 'bg-blue-500';
  } 
  if (stageName.includes('in progress')) {
    return 'bg-purple-500';
  }
  if (stageName.includes('negotiation')) {
    return 'bg-yellow-500';
  }
  if (stageName.includes('won') || stageName.includes('closed won')) {
    return 'bg-green-500';
  }
  if (stageName.includes('lost') || stageName.includes('closed lost')) {
    return 'bg-red-500';
  }
  return 'bg-gray-500';
}

// Function to get status badge color based on status
export function getStatusColor(status: string): string {
  status = status.toLowerCase();
  if (status === 'new') {
    return 'bg-blue-100 text-blue-800';
  }
  if (status === 'active') {
    return 'bg-blue-200 text-blue-800';
  }
  if (status === 'hot') {
    return 'bg-yellow-500 text-white';
  }
  if (status === 'won') {
    return 'bg-green-100 text-green-800';
  }
  if (status === 'lost') {
    return 'bg-red-100 text-red-800';
  }
  return 'bg-gray-100 text-gray-800';
}
