// Import necessary types from TanStack React Query
import { QueryClient, QueryFunction } from "@tanstack/react-query";

/**
 * Helper function to check if response is successful and throw formatted error if not
 * This provides consistent error handling across all API requests
 * 
 * @param res - The fetch response object to check
 * @throws Error with formatted message containing status code and error details
 */
async function throwIfResNotOk(res: Response) {
  // Only proceed with error handling if response is not OK (status outside 200-299)
  if (!res.ok) {
    try {
      // Try to parse response as JSON first for structured error handling
      const contentType = res.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        // Parse JSON response
        const json = await res.json();
        // Extract error message from common error properties, or stringify the whole object
        const message = json.message || json.error || JSON.stringify(json);
        throw new Error(`${res.status}: ${message}`);
      } else {
        // If not JSON, fall back to reading response as text
        const text = (await res.text()) || res.statusText;
        throw new Error(`${res.status}: ${text}`);
      }
    } catch (e) {
      // If the error is already an Error instance (from above), re-throw it
      if (e instanceof Error) {
        throw e;
      }
      // If we can't parse the response at all, throw a generic error with status
      throw new Error(`${res.status}: ${res.statusText}`);
    }
  }
}

/**
 * Unified API request function for making fetch calls with consistent error handling
 * Used primarily for mutations (POST, PUT, PATCH, DELETE) in the application
 * 
 * @param method - HTTP method (GET, POST, PUT, DELETE, etc.)
 * @param url - API endpoint URL
 * @param data - Optional request body data (will be JSON stringified)
 * @returns Response object from fetch API
 * @throws Error with formatted message on request failure
 */
export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  // Log outgoing request for debugging
  console.log(`API Request: ${method} ${url}`, data);
  
  try {
    // Make the fetch request with appropriate options
    const res = await fetch(url, {
      method, // HTTP method
      // Only add Content-Type header if sending data
      headers: data ? { "Content-Type": "application/json" } : {},
      // Only add body if sending data
      body: data ? JSON.stringify(data) : undefined,
      // Include credentials (cookies) for authenticated requests
      credentials: "include",
    });

    // Log response status for debugging
    console.log(`API Response: ${res.status} ${res.statusText} for ${method} ${url}`);
    
    // Check if response is OK, throw formatted error if not
    await throwIfResNotOk(res);
    // Return the response for further processing
    return res;
  } catch (error) {
    // Log errors for debugging
    console.error(`API Error for ${method} ${url}:`, error);
    // Re-throw to let calling code handle it
    throw error;
  }
}

/**
 * Type definition for how to handle 401 Unauthorized responses
 * - "returnNull": Silently return null (useful for auth-optional endpoints)
 * - "throw": Throw error (default behavior for required authentication)
 */
type UnauthorizedBehavior = "returnNull" | "throw";

/**
 * Factory function that creates a query function for React Query
 * This is used as the default queryFn for all queries in the application
 * 
 * @param options - Configuration options
 * @param options.on401 - How to handle 401 Unauthorized responses
 * @returns Query function that can be used with useQuery
 */
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    // Extract URL from the first element of the query key
    const url = queryKey[0] as string;
    // Log outgoing request for debugging
    console.log(`Query request: GET ${url}`);
    
    try {
      // Make GET request to the API
      const res = await fetch(url, {
        // Include credentials (cookies) for authenticated requests
        credentials: "include",
      });
      
      // Log response status for debugging
      console.log(`Query response: ${res.status} ${res.statusText} for GET ${url}`);

      // Special handling for 401 Unauthorized based on configuration
      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        console.log(`Returning null for 401 on ${url} as configured`);
        return null;
      }

      // Check if response is OK, throw error if not
      await throwIfResNotOk(res);
      
      // Process successful response
      const contentType = res.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        // Parse JSON response
        return await res.json();
      } else {
        // If not JSON, log warning and return empty object
        console.warn(`Response from ${url} is not JSON, returning empty object`);
        return {};
      }
    } catch (error) {
      // Log errors for debugging
      console.error(`Query error for GET ${url}:`, error);
      // Re-throw to let React Query handle it
      throw error;
    }
  };

/**
 * Configured QueryClient instance for the application
 * This is the central point for managing all queries and mutations
 */
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Set default query function with behavior to throw on 401
      queryFn: getQueryFn({ on401: "throw" }),
      // Disable automatic refetching
      refetchInterval: false,
      refetchOnWindowFocus: false,
      // Keep data fresh indefinitely (manual invalidation is used instead)
      staleTime: Infinity,
      // Disable automatic retries on error
      retry: false,
    },
    mutations: {
      // Disable automatic retries for mutations
      retry: false,
    },
  },
});
