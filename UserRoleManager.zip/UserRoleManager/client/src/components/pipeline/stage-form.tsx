import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Plus, Save, Trash2 } from "lucide-react";
import { Pipeline } from "@shared/schema";
import { DragDropContext, Droppable, Draggable, DropResult } from "react-beautiful-dnd";
import { usePipelineStages } from "@/hooks/use-pipeline";

interface StageFormProps {
  pipelines: Pipeline[];
}

export default function StageForm({ pipelines }: StageFormProps) {
  const [selectedPipelineId, setSelectedPipelineId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch stages for selected pipeline
  const { data: stages, isLoading: stagesLoading } = usePipelineStages(selectedPipelineId);
  
  // Form validation schema
  const formSchema = z.object({
    name: z.string().min(1, "Stage name is required"),
    description: z.string().optional(),
    pipelineId: z.number().min(1, "Pipeline is required"),
    color: z.string().min(1, "Color is required"),
    requiredFields: z.array(z.string()).default([]),
  });
  
  type FormValues = z.infer<typeof formSchema>;
  
  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      pipelineId: selectedPipelineId || 0,
      color: "#3b82f6",
      requiredFields: ["company", "contact"],
    },
  });
  
  // Update form when pipeline selection changes
  const handlePipelineChange = (pipelineId: string) => {
    const id = parseInt(pipelineId);
    setSelectedPipelineId(id);
    form.setValue("pipelineId", id);
  };
  
  // Create stage mutation
  const createStage = useMutation({
    mutationFn: async (data: FormValues) => {
      // Calculate order based on existing stages
      const order = stages ? stages.length + 1 : 1;
      
      const res = await apiRequest("POST", "/api/stages", {
        ...data,
        order,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pipelines/${selectedPipelineId}/stages`] });
      toast({
        title: "Stage Created",
        description: "The pipeline stage has been created successfully.",
      });
      setShowForm(false);
      form.reset({
        name: "",
        description: "",
        pipelineId: selectedPipelineId || 0,
        color: "#3b82f6",
        requiredFields: ["company", "contact"],
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Stage",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Reorder stages mutation
  const reorderStages = useMutation({
    mutationFn: async ({ pipelineId, stageOrder }: { pipelineId: number, stageOrder: { id: number, order: number }[] }) => {
      // Update each stage with its new order
      const promises = stageOrder.map(stage => 
        apiRequest("PATCH", `/api/stages/${stage.id}`, { order: stage.order })
      );
      
      await Promise.all(promises);
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pipelines/${selectedPipelineId}/stages`] });
      toast({
        title: "Stages Reordered",
        description: "The pipeline stages have been reordered successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Reorder Stages",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: FormValues) => {
    createStage.mutate(data);
  };
  
  // Handle stage reordering
  const handleDragEnd = (result: DropResult) => {
    if (!result.destination || !stages || !selectedPipelineId) return;
    
    const items = Array.from(stages);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    // Update order property and generate stageOrder array
    const stageOrder = items.map((item, index) => ({
      id: item.id,
      order: index + 1,
    }));
    
    reorderStages.mutate({ pipelineId: selectedPipelineId, stageOrder });
  };
  
  // Available field options
  const fieldOptions = [
    { id: "company", label: "Company" },
    { id: "contact", label: "Contact Name" },
    { id: "email", label: "Email" },
    { id: "phone", label: "Phone" },
    { id: "value", label: "Potential Value" },
    { id: "probability", label: "Probability" },
    { id: "source", label: "Lead Source" },
    { id: "timeline", label: "Timeline" },
    { id: "decisionMaker", label: "Decision Maker" },
    { id: "nextSteps", label: "Next Steps" },
  ];
  
  // Color options
  const colorOptions = [
    { name: "Blue", value: "#3b82f6" },
    { name: "Green", value: "#10b981" },
    { name: "Purple", value: "#8b5cf6" },
    { name: "Amber", value: "#f59e0b" },
    { name: "Red", value: "#ef4444" },
    { name: "Slate", value: "#64748b" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Pipeline Stages</h3>
        
        <div className="flex items-center gap-2">
          <Select 
            value={selectedPipelineId?.toString() || ""} 
            onValueChange={handlePipelineChange}
          >
            <SelectTrigger className="w-[240px]">
              <SelectValue placeholder="Select a pipeline" />
            </SelectTrigger>
            <SelectContent>
              {pipelines.map((pipeline) => (
                <SelectItem key={pipeline.id} value={pipeline.id.toString()}>
                  {pipeline.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {selectedPipelineId && !showForm && (
            <Button onClick={() => setShowForm(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Stage
            </Button>
          )}
        </div>
      </div>
      
      {/* Stage order management */}
      {selectedPipelineId && stages && stages.length > 0 && (
        <div className="border rounded-md p-4">
          <h4 className="font-medium mb-4">Current Pipeline Stages</h4>
          <p className="text-sm text-muted-foreground mb-4">
            Drag and drop to reorder stages. The order here determines how leads progress through the pipeline.
          </p>
          
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="stages">
              {(provided) => (
                <div
                  className="space-y-2"
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                >
                  {stages.map((stage, index) => (
                    <Draggable key={stage.id} draggableId={stage.id.toString()} index={index}>
                      {(provided) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          className="flex items-center p-3 bg-white rounded-md border border-border"
                        >
                          <div 
                            className="w-4 h-4 rounded-full mr-3" 
                            style={{ backgroundColor: stage.color }}
                          ></div>
                          <div className="flex-1">
                            <div className="font-medium">{stage.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {stage.requiredFields.length} required fields
                            </div>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Order: {stage.order}
                          </div>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </div>
      )}
      
      {/* Display message if no pipeline selected */}
      {!selectedPipelineId && (
        <div className="border rounded-md p-6 text-center">
          <p className="text-muted-foreground">
            Please select a pipeline to manage its stages
          </p>
        </div>
      )}
      
      {/* Display message if pipeline has no stages */}
      {selectedPipelineId && stages && stages.length === 0 && !showForm && (
        <div className="border rounded-md p-6 text-center">
          <p className="text-muted-foreground mb-4">
            This pipeline doesn't have any stages yet
          </p>
          <Button onClick={() => setShowForm(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add First Stage
          </Button>
        </div>
      )}
      
      {/* Stage creation form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Add Pipeline Stage</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Stage Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. New Leads" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe this stage..." 
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="color"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Stage Color</FormLabel>
                      <div className="grid grid-cols-6 gap-2">
                        {colorOptions.map(color => (
                          <div 
                            key={color.value}
                            className={`
                              h-10 rounded-md flex items-center justify-center cursor-pointer
                              ${field.value === color.value ? 'ring-2 ring-primary ring-offset-2' : ''}
                            `}
                            style={{ backgroundColor: color.value }}
                            onClick={() => form.setValue("color", color.value)}
                          >
                            <span className="text-white text-xs font-medium">{color.name}</span>
                          </div>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="requiredFields"
                  render={() => (
                    <FormItem>
                      <div className="mb-2">
                        <FormLabel className="text-base">Required Fields</FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Select fields that must be completed when a lead reaches this stage
                        </p>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {fieldOptions.map((field) => (
                          <FormField
                            key={field.id}
                            control={form.control}
                            name="requiredFields"
                            render={({ field: formField }) => {
                              return (
                                <FormItem
                                  key={field.id}
                                  className="flex flex-row items-start space-x-3 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={formField.value?.includes(field.id)}
                                      onCheckedChange={(checked) => {
                                        return checked
                                          ? formField.onChange([...formField.value, field.id])
                                          : formField.onChange(
                                              formField.value?.filter(
                                                (value) => value !== field.id
                                              )
                                            )
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal">
                                    {field.label}
                                  </FormLabel>
                                </FormItem>
                              )
                            }}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowForm(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={createStage.isPending}
                  >
                    {createStage.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    <Save className="mr-2 h-4 w-4" />
                    Add Stage
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
