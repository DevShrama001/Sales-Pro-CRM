import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Setting } from "@shared/schema";
import { ThemeConfig } from "@/types";
import { Loader2, Save } from "lucide-react";

interface ThemeSettingsProps {
  settings?: Setting;
}

export default function ThemeSettings({ settings }: ThemeSettingsProps) {
  const [theme, setTheme] = useState<ThemeConfig>({
    primary: "hsl(222.2 47.4% 11.2%)",
    variant: "professional",
    appearance: "light",
    radius: 0.5
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Update local state when settings are loaded
  useEffect(() => {
    if (settings?.theme) {
      setTheme(settings.theme);
    }
  }, [settings]);
  
  // Update settings mutation
  const updateSettings = useMutation({
    mutationFn: async (data: Partial<Setting>) => {
      const res = await apiRequest("PATCH", "/api/settings", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Theme Updated",
        description: "Your theme settings have been saved.",
      });
      // Force refresh to apply new theme
      window.location.reload();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Theme",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle save button click
  const handleSave = () => {
    updateSettings.mutate({
      theme
    });
  };
  
  // Color selection options
  const colorOptions = [
    { label: "Blue", value: "hsl(221.2 83.2% 53.3%)" },
    { label: "Green", value: "hsl(142.1 76.2% 36.3%)" },
    { label: "Red", value: "hsl(0 72.2% 50.6%)" },
    { label: "Purple", value: "hsl(262.1 83.3% 57.8%)" },
    { label: "Orange", value: "hsl(24.6 95% 53.1%)" },
    { label: "Slate", value: "hsl(222.2 47.4% 11.2%)" },
  ];
  
  // Preview element based on selected theme
  const renderPreview = () => {
    return (
      <div 
        className="border rounded-md p-4 mb-6"
        style={{
          "--radius": `${theme.radius}rem`,
          "--primary": theme.primary,
        } as React.CSSProperties}
      >
        <h3 className="text-base font-semibold mb-2">Theme Preview</h3>
        <div className="space-y-2">
          <div 
            className="h-10 rounded-md flex items-center justify-center text-white"
            style={{ backgroundColor: theme.primary }}
          >
            Primary Button
          </div>
          <div className="flex gap-2">
            <div 
              className="h-8 flex-1 border rounded-md flex items-center justify-center"
              style={{ borderRadius: `calc(${theme.radius}rem - 2px)` }}
            >
              Secondary
            </div>
            <div 
              className="h-8 flex-1 bg-muted rounded-md flex items-center justify-center"
              style={{ borderRadius: `calc(${theme.radius}rem - 2px)` }}
            >
              Muted
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-2">Theme Customization</h3>
        <p className="text-sm text-muted-foreground">
          Customize the appearance of your CRM system to match your brand
        </p>
      </div>
      
      {renderPreview()}
      
      <div className="space-y-4">
        <div>
          <Label className="text-base">Primary Color</Label>
          <div className="grid grid-cols-3 gap-3 mt-2">
            {colorOptions.map((color) => (
              <div 
                key={color.value} 
                className={`
                  relative rounded-md border overflow-hidden cursor-pointer
                  ${theme.primary === color.value ? 'ring-2 ring-primary ring-offset-2' : ''}
                `}
                onClick={() => setTheme({ ...theme, primary: color.value })}
              >
                <div 
                  className="h-12 w-full" 
                  style={{ backgroundColor: color.value }}
                ></div>
                <div className="p-2 text-xs font-medium">{color.label}</div>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <Label className="text-base">Theme Variant</Label>
          <RadioGroup
            value={theme.variant}
            onValueChange={(value) => setTheme({ ...theme, variant: value as 'professional' | 'tint' | 'vibrant' })}
            className="grid grid-cols-3 gap-3 mt-2"
          >
            <div className="relative flex items-center space-x-2 rounded-md border p-2">
              <RadioGroupItem value="professional" id="professional" />
              <Label htmlFor="professional" className="cursor-pointer">Professional</Label>
            </div>
            <div className="relative flex items-center space-x-2 rounded-md border p-2">
              <RadioGroupItem value="tint" id="tint" />
              <Label htmlFor="tint" className="cursor-pointer">Tint</Label>
            </div>
            <div className="relative flex items-center space-x-2 rounded-md border p-2">
              <RadioGroupItem value="vibrant" id="vibrant" />
              <Label htmlFor="vibrant" className="cursor-pointer">Vibrant</Label>
            </div>
          </RadioGroup>
        </div>
        
        <div>
          <Label className="text-base">Appearance</Label>
          <RadioGroup
            value={theme.appearance}
            onValueChange={(value) => setTheme({ ...theme, appearance: value as 'light' | 'dark' | 'system' })}
            className="grid grid-cols-3 gap-3 mt-2"
          >
            <div className="relative flex items-center space-x-2 rounded-md border p-2">
              <RadioGroupItem value="light" id="light" />
              <Label htmlFor="light" className="cursor-pointer">Light</Label>
            </div>
            <div className="relative flex items-center space-x-2 rounded-md border p-2">
              <RadioGroupItem value="dark" id="dark" />
              <Label htmlFor="dark" className="cursor-pointer">Dark</Label>
            </div>
            <div className="relative flex items-center space-x-2 rounded-md border p-2">
              <RadioGroupItem value="system" id="system" />
              <Label htmlFor="system" className="cursor-pointer">System</Label>
            </div>
          </RadioGroup>
        </div>
        
        <div>
          <div className="flex justify-between items-center">
            <Label className="text-base">Border Radius</Label>
            <span className="text-sm">{theme.radius}rem</span>
          </div>
          <Slider
            value={[theme.radius]}
            onValueChange={(values) => setTheme({ ...theme, radius: values[0] })}
            min={0}
            max={1.5}
            step={0.1}
            className="mt-2"
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>Square</span>
            <span>Rounded</span>
          </div>
        </div>
        
        <Button 
          onClick={handleSave} 
          className="w-full"
          disabled={updateSettings.isPending}
        >
          {updateSettings.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          <Save className="mr-2 h-4 w-4" />
          Save Theme Settings
        </Button>
      </div>
    </div>
  );
}
