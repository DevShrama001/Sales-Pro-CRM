import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Setting } from "@shared/schema";
import { NotificationSettings as NotificationSettingsType } from "@/types";
import { Loader2, Save, BellRing, Mail, MessageSquare, Clock } from "lucide-react";

interface NotificationSettingsProps {
  settings?: Setting;
}

export default function NotificationSettings({ settings }: NotificationSettingsProps) {
  const [notifications, setNotifications] = useState<NotificationSettingsType>({
    email: true,
    app: true,
    leadUpdates: true,
    meetingReminders: true,
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Update local state when settings are loaded
  useEffect(() => {
    if (settings?.notifications) {
      setNotifications(settings.notifications);
    }
  }, [settings]);
  
  // Update settings mutation
  const updateSettings = useMutation({
    mutationFn: async (data: Partial<Setting>) => {
      const res = await apiRequest("PATCH", "/api/settings", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Notification Settings Updated",
        description: "Your notification preferences have been saved.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle save button click
  const handleSave = () => {
    updateSettings.mutate({
      notifications
    });
  };
  
  // Handle switch toggle
  const handleToggle = (key: keyof NotificationSettingsType, value: boolean) => {
    setNotifications(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-2">Notification Preferences</h3>
        <p className="text-sm text-muted-foreground">
          Customize how and when you receive notifications from the system
        </p>
      </div>
      
      <div className="space-y-4">
        <div className="border rounded-md p-4">
          <h4 className="font-medium mb-4">Notification Channels</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="bg-primary/10 text-primary p-2 rounded-full">
                  <Mail className="h-5 w-5" />
                </div>
                <div>
                  <Label htmlFor="email-notifications" className="font-medium">Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive notifications via email
                  </p>
                </div>
              </div>
              <Switch
                id="email-notifications"
                checked={notifications.email}
                onCheckedChange={(checked) => handleToggle('email', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="bg-primary/10 text-primary p-2 rounded-full">
                  <BellRing className="h-5 w-5" />
                </div>
                <div>
                  <Label htmlFor="app-notifications" className="font-medium">In-App Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive notifications within the app
                  </p>
                </div>
              </div>
              <Switch
                id="app-notifications"
                checked={notifications.app}
                onCheckedChange={(checked) => handleToggle('app', checked)}
              />
            </div>
          </div>
        </div>
        
        <div className="border rounded-md p-4">
          <h4 className="font-medium mb-4">Notification Types</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="bg-primary/10 text-primary p-2 rounded-full">
                  <MessageSquare className="h-5 w-5" />
                </div>
                <div>
                  <Label htmlFor="lead-updates" className="font-medium">Lead Updates</Label>
                  <p className="text-sm text-muted-foreground">
                    Notifications about lead status changes and updates
                  </p>
                </div>
              </div>
              <Switch
                id="lead-updates"
                checked={notifications.leadUpdates}
                onCheckedChange={(checked) => handleToggle('leadUpdates', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="bg-primary/10 text-primary p-2 rounded-full">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <Label htmlFor="meeting-reminders" className="font-medium">Meeting Reminders</Label>
                  <p className="text-sm text-muted-foreground">
                    Reminders about upcoming meetings and follow-ups
                  </p>
                </div>
              </div>
              <Switch
                id="meeting-reminders"
                checked={notifications.meetingReminders}
                onCheckedChange={(checked) => handleToggle('meetingReminders', checked)}
              />
            </div>
          </div>
        </div>
        
        <Button 
          onClick={handleSave} 
          className="w-full"
          disabled={updateSettings.isPending}
        >
          {updateSettings.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          <Save className="mr-2 h-4 w-4" />
          Save Notification Settings
        </Button>
      </div>
    </div>
  );
}
