import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, Save, X, Pencil, AlertTriangle } from "lucide-react";
import { Role, insertRoleSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

export default function RoleManagement() {
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch roles
  const { data: roles, isLoading } = useQuery({
    queryKey: ["/api/roles"],
  });
  
  // Setup form validation
  const formSchema = z.object({
    name: z.string().min(1, "Role name is required"),
    description: z.string().optional(),
    permissions: z.array(z.string()).min(1, "At least one permission is required"),
  });
  
  type FormValues = z.infer<typeof formSchema>;
  
  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      permissions: [],
    },
  });
  
  // Update form when editing role
  useEffect(() => {
    if (editingRole) {
      form.reset({
        name: editingRole.name,
        description: editingRole.description || "",
        permissions: editingRole.permissions,
      });
    } else if (!isCreating) {
      form.reset({
        name: "",
        description: "",
        permissions: [],
      });
    }
  }, [editingRole, isCreating, form]);
  
  // Create role mutation
  const createRole = useMutation({
    mutationFn: async (data: FormValues) => {
      const res = await apiRequest("POST", "/api/roles", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      toast({
        title: "Role Created",
        description: "The role has been created successfully.",
      });
      setIsCreating(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Role",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update role mutation
  const updateRole = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: FormValues }) => {
      const res = await apiRequest("PATCH", `/api/roles/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      toast({
        title: "Role Updated",
        description: "The role has been updated successfully.",
      });
      setEditingRole(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Role",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: FormValues) => {
    if (editingRole) {
      updateRole.mutate({ id: editingRole.id, data });
    } else {
      createRole.mutate(data);
    }
  };
  
  // Available permissions
  const availablePermissions = [
    { id: "all", label: "All Permissions (Admin)" },
    { id: "view_leads", label: "View Leads" },
    { id: "create_leads", label: "Create Leads" },
    { id: "edit_leads", label: "Edit Leads" },
    { id: "delete_leads", label: "Delete Leads" },
    { id: "view_reports", label: "View Reports" },
    { id: "view_team", label: "View Team Members" },
    { id: "edit_team", label: "Edit Team Members" },
    { id: "view_settings", label: "View Settings" },
    { id: "edit_settings", label: "Edit Settings" },
    { id: "view_customization", label: "View Customization" },
    { id: "edit_customization", label: "Edit Customization" },
    { id: "view_assigned_leads", label: "View Assigned Leads" },
    { id: "edit_assigned_leads", label: "Edit Assigned Leads" },
  ];
  
  // Cancel form edit/create
  const handleCancel = () => {
    setEditingRole(null);
    setIsCreating(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Role Management</h3>
        
        {!isCreating && !editingRole && (
          <Button onClick={() => setIsCreating(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add New Role
          </Button>
        )}
      </div>
      
      {(isCreating || editingRole) ? (
        <Card>
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Sales Manager" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe this role's responsibilities..." 
                          {...field} 
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="permissions"
                  render={() => (
                    <FormItem>
                      <div className="mb-4">
                        <FormLabel className="text-base">Permissions</FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Select the permissions this role should have
                        </p>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {availablePermissions.map((permission) => (
                          <FormField
                            key={permission.id}
                            control={form.control}
                            name="permissions"
                            render={({ field }) => {
                              return (
                                <FormItem
                                  key={permission.id}
                                  className="flex flex-row items-start space-x-3 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(permission.id)}
                                      onCheckedChange={(checked) => {
                                        return checked
                                          ? field.onChange([...field.value, permission.id])
                                          : field.onChange(
                                              field.value?.filter(
                                                (value) => value !== permission.id
                                              )
                                            )
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal">
                                    {permission.label}
                                  </FormLabel>
                                </FormItem>
                              )
                            }}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={handleCancel}
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={createRole.isPending || updateRole.isPending}
                  >
                    {(createRole.isPending || updateRole.isPending) && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    <Save className="h-4 w-4 mr-2" />
                    {editingRole ? "Update Role" : "Create Role"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : roles && roles.length > 0 ? (
            roles.map((role: Role) => (
              <Card key={role.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="font-medium">{role.name}</div>
                      <p className="text-sm text-muted-foreground">
                        {role.description || "No description"}
                      </p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {role.permissions.includes("all") ? (
                          <span className="bg-primary text-primary-foreground px-2 py-1 rounded text-xs">
                            All Permissions
                          </span>
                        ) : (
                          role.permissions.map(permission => (
                            <span 
                              key={permission} 
                              className="bg-primary/10 text-primary px-2 py-1 rounded text-xs"
                            >
                              {permission.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                            </span>
                          ))
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setEditingRole(role)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-8">
              <AlertTriangle className="h-8 w-8 mx-auto text-muted-foreground opacity-50" />
              <p className="mt-2 text-muted-foreground">No roles found</p>
              <Button 
                className="mt-4" 
                onClick={() => setIsCreating(true)}
              >
                Create Your First Role
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
