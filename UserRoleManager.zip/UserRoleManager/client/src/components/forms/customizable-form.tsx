import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { DragDropContext, Droppable, Draggable, DropResult } from "react-beautiful-dnd";
import FormField from "@/components/forms/form-field";
import { GripVertical, Plus, Save, Trash2, Pencil } from "lucide-react";
import { LeadFormField } from "@shared/schema";
import { generateUniqueId } from "@/lib/utils";

export default function CustomizableForm() {
  const [formName, setFormName] = useState("New Lead Form");
  const [activeTab, setActiveTab] = useState("basic");
  const [editingFieldId, setEditingFieldId] = useState<string | null>(null);
  const [tabs, setTabs] = useState<string[]>(["Basic Info", "Additional Details"]);
  const [fields, setFields] = useState<LeadFormField[]>([
    {
      id: "company",
      name: "company",
      label: "Company",
      type: "text",
      required: true,
      tab: "Basic Info",
      order: 1
    },
    {
      id: "contact",
      name: "contact",
      label: "Contact Name",
      type: "text",
      required: true,
      tab: "Basic Info",
      order: 2
    },
    {
      id: "email",
      name: "email",
      label: "Email",
      type: "email",
      required: false,
      tab: "Basic Info",
      order: 3
    },
    {
      id: "phone",
      name: "phone",
      label: "Phone",
      type: "tel",
      required: false,
      tab: "Basic Info",
      order: 4
    },
    {
      id: "source",
      name: "source",
      label: "Lead Source",
      type: "select",
      options: ["Website", "Referral", "Cold Call", "Event", "Other"],
      required: false,
      tab: "Additional Details",
      order: 5
    },
    {
      id: "value",
      name: "value",
      label: "Potential Value",
      type: "number",
      required: false,
      tab: "Additional Details",
      order: 6
    }
  ]);
  
  // Add a new field
  const addField = () => {
    const newField: LeadFormField = {
      id: generateUniqueId("field_"),
      name: "new_field",
      label: "New Field",
      type: "text",
      required: false,
      tab: activeTab === "basic" ? "Basic Info" : "Additional Details",
      order: fields.length + 1
    };
    
    setFields([...fields, newField]);
    setEditingFieldId(newField.id);
  };
  
  // Update a field
  const updateField = (updatedField: LeadFormField) => {
    setFields(fields.map(field => 
      field.id === updatedField.id ? updatedField : field
    ));
    setEditingFieldId(null);
  };
  
  // Delete a field
  const deleteField = (fieldId: string) => {
    setFields(fields.filter(field => field.id !== fieldId));
    if (editingFieldId === fieldId) {
      setEditingFieldId(null);
    }
  };
  
  // Handle field reordering
  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    
    const items = Array.from(fields);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    // Update order property
    const updatedItems = items.map((item, index) => ({
      ...item,
      order: index + 1
    }));
    
    setFields(updatedItems);
  };
  
  // Add a new tab
  const addTab = () => {
    const tabName = `Tab ${tabs.length + 1}`;
    setTabs([...tabs, tabName]);
    setActiveTab(tabName.toLowerCase().replace(/\s+/g, '_'));
  };
  
  // Save form
  const saveForm = () => {
    console.log("Form saved", { name: formName, fields });
    // In a real app, this would call an API to save the form
  };
  
  // Filter fields by active tab
  const getTabFields = () => {
    const tabName = activeTab === "basic" ? "Basic Info" : "Additional Details";
    return fields
      .filter(field => field.tab === tabName)
      .sort((a, b) => a.order - b.order);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg">Customize Lead Form</CardTitle>
        <Button onClick={saveForm}>
          <Save className="h-4 w-4 mr-2" />
          Save Form
        </Button>
      </CardHeader>
      
      <CardContent>
        <div className="mb-6">
          <Label>Form Name</Label>
          <Input 
            value={formName} 
            onChange={(e) => setFormName(e.target.value)} 
            className="mt-1"
          />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 border rounded-md p-4">
            <h3 className="font-medium mb-4">Form Structure</h3>
            
            <div className="mb-4">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full">
                  <TabsTrigger value="basic" className="flex-1">Basic Info</TabsTrigger>
                  <TabsTrigger value="additional" className="flex-1">Additional Details</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            
            <div className="mb-4">
              <Button variant="outline" className="w-full" onClick={addField}>
                <Plus className="h-4 w-4 mr-2" />
                Add Field
              </Button>
            </div>
            
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="form-fields">
                {(provided) => (
                  <div
                    className="space-y-2"
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                  >
                    {getTabFields().map((field, index) => (
                      <Draggable key={field.id} draggableId={field.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            className={`flex items-center p-2 rounded border ${
                              editingFieldId === field.id ? 'border-primary bg-primary/5' : 'border-muted'
                            }`}
                          >
                            <div 
                              {...provided.dragHandleProps}
                              className="mr-2 text-muted-foreground"
                            >
                              <GripVertical className="h-4 w-4" />
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium">{field.label}</p>
                              <p className="text-xs text-muted-foreground">{field.type}</p>
                            </div>
                            <div className="flex space-x-1">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8"
                                onClick={() => setEditingFieldId(field.id)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-destructive"
                                onClick={() => deleteField(field.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </div>
          
          <div className="lg:col-span-2 border rounded-md p-4">
            {editingFieldId ? (
              <div>
                <h3 className="font-medium mb-4">Edit Field</h3>
                <FormField 
                  field={fields.find(f => f.id === editingFieldId)!}
                  onUpdate={updateField}
                  onCancel={() => setEditingFieldId(null)}
                />
              </div>
            ) : (
              <div>
                <h3 className="font-medium mb-4">Form Preview</h3>
                <div className="border rounded-md p-4 bg-muted/20">
                  <Tabs defaultValue="basic">
                    <TabsList>
                      <TabsTrigger value="basic">Basic Info</TabsTrigger>
                      <TabsTrigger value="additional">Additional Details</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="basic" className="space-y-4 mt-4">
                      {fields
                        .filter(field => field.tab === "Basic Info")
                        .sort((a, b) => a.order - b.order)
                        .map(field => (
                          <div key={field.id} className="space-y-2">
                            <Label htmlFor={field.id}>
                              {field.label}
                              {field.required && <span className="text-destructive ml-1">*</span>}
                            </Label>
                            {field.type === "select" ? (
                              <Select>
                                <SelectTrigger id={field.id}>
                                  <SelectValue placeholder={`Select ${field.label}`} />
                                </SelectTrigger>
                                <SelectContent>
                                  {field.options?.map(option => (
                                    <SelectItem key={option} value={option}>{option}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            ) : (
                              <Input 
                                id={field.id} 
                                type={field.type} 
                                placeholder={`Enter ${field.label.toLowerCase()}`} 
                              />
                            )}
                          </div>
                        ))
                      }
                    </TabsContent>
                    
                    <TabsContent value="additional" className="space-y-4 mt-4">
                      {fields
                        .filter(field => field.tab === "Additional Details")
                        .sort((a, b) => a.order - b.order)
                        .map(field => (
                          <div key={field.id} className="space-y-2">
                            <Label htmlFor={field.id}>
                              {field.label}
                              {field.required && <span className="text-destructive ml-1">*</span>}
                            </Label>
                            {field.type === "select" ? (
                              <Select>
                                <SelectTrigger id={field.id}>
                                  <SelectValue placeholder={`Select ${field.label}`} />
                                </SelectTrigger>
                                <SelectContent>
                                  {field.options?.map(option => (
                                    <SelectItem key={option} value={option}>{option}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            ) : (
                              <Input 
                                id={field.id} 
                                type={field.type} 
                                placeholder={`Enter ${field.label.toLowerCase()}`} 
                              />
                            )}
                          </div>
                        ))
                      }
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
