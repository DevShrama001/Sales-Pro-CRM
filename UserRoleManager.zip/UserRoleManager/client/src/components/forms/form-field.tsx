import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { LeadFormField } from "@shared/schema";
import { X, Plus } from "lucide-react";

interface FormFieldProps {
  field: LeadFormField;
  onUpdate: (field: LeadFormField) => void;
  onCancel: () => void;
}

export default function FormField({ field, onUpdate, onCancel }: FormFieldProps) {
  const [updatedField, setUpdatedField] = useState<LeadFormField>({...field});
  const [options, setOptions] = useState<string[]>(field.options || []);
  const [newOption, setNewOption] = useState("");
  
  // Handle field update
  const handleUpdate = () => {
    onUpdate({
      ...updatedField,
      options: updatedField.type === "select" ? options : undefined
    });
  };
  
  // Add option to select field
  const addOption = () => {
    if (newOption.trim() !== "") {
      setOptions([...options, newOption.trim()]);
      setNewOption("");
    }
  };
  
  // Remove option from select field
  const removeOption = (index: number) => {
    const newOptions = [...options];
    newOptions.splice(index, 1);
    setOptions(newOptions);
  };
  
  // Handle field change
  const handleChange = (name: string, value: any) => {
    setUpdatedField({
      ...updatedField,
      [name]: value
    });
    
    // Reset options if field type changed from select
    if (name === "type" && value !== "select" && updatedField.type === "select") {
      setOptions([]);
    }
  };
  
  // Handle field name change and keep it lowercase with no spaces
  const handleNameChange = (value: string) => {
    const formattedName = value.toLowerCase().replace(/\s+/g, '_');
    handleChange("name", formattedName);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="label">Field Label</Label>
          <Input 
            id="label" 
            value={updatedField.label} 
            onChange={(e) => {
              handleChange("label", e.target.value);
              handleNameChange(e.target.value);
            }}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="name">Field Name (System)</Label>
          <Input 
            id="name" 
            value={updatedField.name} 
            onChange={(e) => handleChange("name", e.target.value)}
            className="mt-1"
            disabled
          />
          <p className="text-xs text-muted-foreground mt-1">
            Auto-generated from label
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="type">Field Type</Label>
          <Select 
            value={updatedField.type} 
            onValueChange={(value) => handleChange("type", value)}
          >
            <SelectTrigger id="type" className="mt-1">
              <SelectValue placeholder="Select field type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="text">Text</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="tel">Phone</SelectItem>
              <SelectItem value="number">Number</SelectItem>
              <SelectItem value="date">Date</SelectItem>
              <SelectItem value="select">Dropdown</SelectItem>
              <SelectItem value="textarea">Multi-line Text</SelectItem>
              <SelectItem value="checkbox">Checkbox</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="tab">Tab</Label>
          <Select 
            value={updatedField.tab} 
            onValueChange={(value) => handleChange("tab", value)}
          >
            <SelectTrigger id="tab" className="mt-1">
              <SelectValue placeholder="Select tab" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Basic Info">Basic Info</SelectItem>
              <SelectItem value="Additional Details">Additional Details</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        <Checkbox 
          id="required" 
          checked={updatedField.required}
          onCheckedChange={(checked) => handleChange("required", !!checked)}
        />
        <Label htmlFor="required">Required field</Label>
      </div>
      
      {updatedField.type === "select" && (
        <div className="mt-4">
          <Label>Options</Label>
          <div className="mt-2 space-y-2">
            {options.map((option, index) => (
              <div key={index} className="flex items-center">
                <Input 
                  value={option} 
                  onChange={(e) => {
                    const newOptions = [...options];
                    newOptions[index] = e.target.value;
                    setOptions(newOptions);
                  }}
                  className="mr-2"
                />
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => removeOption(index)}
                  className="text-destructive"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
            <div className="flex items-center mt-2">
              <Input 
                placeholder="Add option" 
                value={newOption} 
                onChange={(e) => setNewOption(e.target.value)}
                className="mr-2"
              />
              <Button 
                variant="outline" 
                size="icon" 
                onClick={addOption}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
      
      <div className="flex justify-end space-x-2 pt-4">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleUpdate}>
          Update Field
        </Button>
      </div>
    </div>
  );
}
