import { Card, CardContent } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Phone, 
  Mail, 
  FileText, 
  Calendar, 
  UserPlus,
  Star,
  AlertTriangle,
  Check
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

// Sample data - replace with actual API data
const activities = [
  {
    id: 1,
    type: "call",
    description: "Call with John from Acme Corp",
    user: "Maria Davis",
    lead: "Acme Corp",
    date: "2023-07-10T14:30:00",
    status: "completed"
  },
  {
    id: 2,
    type: "email",
    description: "Sent follow-up email with proposal",
    user: "Robert Johnson",
    lead: "Tech Solutions Inc",
    date: "2023-07-09T11:15:00",
    status: "completed"
  },
  {
    id: 3,
    type: "meeting",
    description: "Product demo meeting",
    user: "John Smith",
    lead: "Global Industries",
    date: "2023-07-08T16:00:00",
    status: "completed"
  },
  {
    id: 4,
    type: "note",
    description: "Client requested additional features",
    user: "Maria Davis",
    lead: "Digital Services",
    date: "2023-07-07T09:45:00",
    status: "completed"
  },
  {
    id: 5,
    type: "lead_created",
    description: "New lead created from website form",
    user: "System",
    lead: "Innovative Systems",
    date: "2023-07-06T13:20:00",
    status: "completed"
  },
  {
    id: 6,
    type: "status_change",
    description: "Lead moved to Qualified stage",
    user: "John Smith",
    lead: "Smart Solutions",
    date: "2023-07-05T10:30:00",
    status: "completed"
  },
  {
    id: 7,
    type: "call",
    description: "Scheduled follow-up call",
    user: "Robert Johnson",
    lead: "Modern Tech",
    date: "2023-07-15T15:00:00",
    status: "scheduled"
  },
  {
    id: 8,
    type: "meeting",
    description: "Contract negotiation meeting",
    user: "Maria Davis",
    lead: "Global Industries",
    date: "2023-07-12T11:00:00",
    status: "scheduled"
  }
];

const getActivityIcon = (type: string) => {
  switch (type) {
    case "call":
      return <Phone className="h-4 w-4" />;
    case "email":
      return <Mail className="h-4 w-4" />;
    case "meeting":
      return <Calendar className="h-4 w-4" />;
    case "note":
      return <FileText className="h-4 w-4" />;
    case "lead_created":
      return <UserPlus className="h-4 w-4" />;
    case "status_change":
      return <Star className="h-4 w-4" />;
    default:
      return <FileText className="h-4 w-4" />;
  }
};

const getStatusBadge = (status: string) => {
  switch (status) {
    case "completed":
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><Check className="h-3 w-3 mr-1" /> Completed</Badge>;
    case "scheduled":
      return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200"><Calendar className="h-3 w-3 mr-1" /> Scheduled</Badge>;
    case "overdue":
      return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200"><AlertTriangle className="h-3 w-3 mr-1" /> Overdue</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: true
  }).format(date);
};

interface ActivityLogProps {
  timeRange: number;
}

export default function ActivityLog({ timeRange }: ActivityLogProps) {
  // In a real application, filter activities based on timeRange
  
  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Activity</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Lead</TableHead>
              <TableHead>Date & Time</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activities.map(activity => (
              <TableRow key={activity.id}>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <div className="bg-muted rounded-full p-1.5">
                      {getActivityIcon(activity.type)}
                    </div>
                    <span className="font-medium">{activity.description}</span>
                  </div>
                </TableCell>
                <TableCell>{activity.user}</TableCell>
                <TableCell>{activity.lead}</TableCell>
                <TableCell>{formatDate(activity.date)}</TableCell>
                <TableCell>{getStatusBadge(activity.status)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}