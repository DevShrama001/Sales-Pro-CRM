import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Sample data - replace with actual API data
const salesData = [
  { name: 'Jan', won: 4000, total: 6400 },
  { name: 'Feb', won: 3000, total: 5398 },
  { name: 'Mar', won: 2000, total: 4800 },
  { name: 'Apr', won: 2780, total: 5908 },
  { name: 'May', won: 1890, total: 4800 },
  { name: 'Jun', won: 2390, total: 3800 },
  { name: 'Jul', won: 3490, total: 7300 },
];

interface SalesReportProps {
  timeRange: number;
}

export default function SalesReport({ timeRange }: SalesReportProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Sales Performance</CardTitle>
          <CardDescription>
            Revenue overview for the last {timeRange} days
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={salesData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="total" stroke="#8884d8" activeDot={{ r: 8 }} name="Total Value" />
                <Line type="monotone" dataKey="won" stroke="#82ca9d" name="Won Deals" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$24,568</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">+18%</span> from previous period
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Deals Won
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">28</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">+12%</span> from previous period
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Win Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32.5%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-red-500">-4%</span> from previous period
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Avg. Deal Size
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$877</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">+6%</span> from previous period
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Top Performers</CardTitle>
          <CardDescription>
            Sales representatives with highest performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground">JS</div>
                <div>
                  <p className="text-sm font-medium">John Smith</p>
                  <p className="text-xs text-muted-foreground">Sales Executive</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">$8,942</p>
                <p className="text-xs text-green-500">12 deals</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-white">MD</div>
                <div>
                  <p className="text-sm font-medium">Maria Davis</p>
                  <p className="text-xs text-muted-foreground">Account Manager</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">$7,634</p>
                <p className="text-xs text-green-500">9 deals</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="h-10 w-10 rounded-full bg-green-500 flex items-center justify-center text-white">RJ</div>
                <div>
                  <p className="text-sm font-medium">Robert Johnson</p>
                  <p className="text-xs text-muted-foreground">Sales Executive</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">$5,213</p>
                <p className="text-xs text-green-500">8 deals</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}