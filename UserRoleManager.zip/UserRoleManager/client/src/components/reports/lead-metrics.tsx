import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

// Sample data - replace with actual API data
const leadsBySource = [
  { name: "Website", value: 35 },
  { name: "Referral", value: 25 },
  { name: "Social Media", value: 18 },
  { name: "Cold Call", value: 12 },
  { name: "Event", value: 10 }
];

const conversionData = [
  { name: "New", total: 45 },
  { name: "Qualified", total: 36 },
  { name: "Proposal", total: 28 },
  { name: "Negotiation", total: 19 },
  { name: "Won", total: 12 }
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

interface LeadMetricsProps {
  timeRange: number;
}

export default function LeadMetrics({ timeRange }: LeadMetricsProps) {
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Lead Source Distribution</CardTitle>
            <CardDescription>
              Where your leads are coming from in the last {timeRange} days
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={leadsBySource}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {leadsBySource.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Conversion Pipeline</CardTitle>
            <CardDescription>
              Lead progression through sales stages in the last {timeRange} days
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={conversionData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="total" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lead Metrics Summary</CardTitle>
          <CardDescription>
            Overall lead performance metrics for the last {timeRange} days
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-4">
            <div className="flex flex-col">
              <span className="text-sm font-medium text-muted-foreground">New Leads</span>
              <span className="text-3xl font-bold">45</span>
              <span className="text-xs text-green-500">+12% from previous period</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-muted-foreground">Qualified Leads</span>
              <span className="text-3xl font-bold">36</span>
              <span className="text-xs text-green-500">+8% from previous period</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-muted-foreground">Conversion Rate</span>
              <span className="text-3xl font-bold">26.7%</span>
              <span className="text-xs text-red-500">-2% from previous period</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-muted-foreground">Avg. Time to Convert</span>
              <span className="text-3xl font-bold">18d</span>
              <span className="text-xs text-green-500">-3 days from previous period</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}