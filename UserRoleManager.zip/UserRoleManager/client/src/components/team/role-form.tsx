import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Save } from "lucide-react";
import { Role } from "@shared/schema";

// Define available permissions
const PERMISSIONS = [
  { id: "dashboard_view", label: "View Dashboard", group: "Dashboard" },
  { id: "reports_view", label: "View Reports", group: "Reports" },
  { id: "reports_create", label: "Create Reports", group: "Reports" },
  { id: "leads_view", label: "View Leads", group: "Leads" },
  { id: "leads_create", label: "Create Leads", group: "Leads" },
  { id: "leads_edit", label: "Edit Leads", group: "Leads" },
  { id: "leads_delete", label: "Delete Leads", group: "Leads" },
  { id: "pipeline_view", label: "View Pipelines", group: "Pipelines" },
  { id: "pipeline_create", label: "Create Pipelines", group: "Pipelines" },
  { id: "pipeline_edit", label: "Edit Pipelines", group: "Pipelines" },
  { id: "meetings_view", label: "View Meetings", group: "Meetings" },
  { id: "meetings_create", label: "Create Meetings", group: "Meetings" },
  { id: "meetings_edit", label: "Edit Meetings", group: "Meetings" },
  { id: "team_view", label: "View Team Members", group: "Team Management" },
  { id: "team_create", label: "Create Team Members", group: "Team Management" },
  { id: "team_edit", label: "Edit Team Members", group: "Team Management" },
  { id: "roles_view", label: "View Roles", group: "Role Management" },
  { id: "roles_create", label: "Create Roles", group: "Role Management" },
  { id: "roles_edit", label: "Edit Roles", group: "Role Management" },
  { id: "settings_view", label: "View Settings", group: "Settings" },
  { id: "settings_edit", label: "Edit Settings", group: "Settings" },
  { id: "customization_access", label: "Access Customization", group: "Customization" }
];

// Group permissions by their category
const groupedPermissions = PERMISSIONS.reduce((acc, permission) => {
  if (!acc[permission.group]) {
    acc[permission.group] = [];
  }
  acc[permission.group].push(permission);
  return acc;
}, {} as Record<string, typeof PERMISSIONS>);

interface RoleFormProps {
  roleId: number | null;
  onComplete: () => void;
}

export default function RoleForm({ roleId, onComplete }: RoleFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch role data if editing
  const { data: roleData, isLoading: isRoleLoading } = useQuery<Role>({
    queryKey: [`/api/roles/${roleId}`],
    enabled: !!roleId,
  });
  
  // Form validation schema
  const formSchema = z.object({
    name: z.string().min(2, "Role name must be at least 2 characters"),
    description: z.string().optional(),
    permissions: z.array(z.string()).min(1, "At least one permission must be selected"),
  });
  
  type FormValues = z.infer<typeof formSchema>;
  
  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      permissions: [],
    },
  });
  
  // Update form with role data when available
  useEffect(() => {
    if (roleData) {
      form.reset({
        name: roleData.name,
        description: roleData.description || "",
        permissions: roleData.permissions,
      });
    }
  }, [roleData, form]);
  
  // Create role mutation
  const createRole = useMutation({
    mutationFn: async (data: FormValues) => {
      const res = await apiRequest("POST", "/api/roles", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      toast({
        title: "Role Created",
        description: "The role has been created successfully.",
      });
      onComplete();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Role",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update role mutation
  const updateRole = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: FormValues }) => {
      const res = await apiRequest("PATCH", `/api/roles/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      toast({
        title: "Role Updated",
        description: "The role has been updated successfully.",
      });
      onComplete();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Role",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: FormValues) => {
    if (roleId) {
      updateRole.mutate({ id: roleId, data });
    } else {
      createRole.mutate(data);
    }
  };
  
  const isPending = createRole.isPending || updateRole.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 gap-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Role Name</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., Sales Manager" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Describe the role's responsibilities" 
                    className="min-h-[100px]"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <div>
          <h3 className="text-lg font-medium mb-4">Permissions</h3>
          <FormField
            control={form.control}
            name="permissions"
            render={() => (
              <FormItem>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {Object.entries(groupedPermissions).map(([group, permissions]) => (
                    <Card key={group}>
                      <CardContent className="pt-6">
                        <h4 className="font-medium text-sm mb-3">{group}</h4>
                        <div className="space-y-3">
                          {permissions.map((permission) => (
                            <FormField
                              key={permission.id}
                              control={form.control}
                              name="permissions"
                              render={({ field }) => (
                                <FormItem 
                                  key={permission.id} 
                                  className="flex flex-row items-start space-x-3 space-y-0 leading-none"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(permission.id)}
                                      onCheckedChange={(checked) => {
                                        if (checked) {
                                          field.onChange([...field.value, permission.id]);
                                        } else {
                                          field.onChange(
                                            field.value?.filter(
                                              (value) => value !== permission.id
                                            )
                                          );
                                        }
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal text-sm cursor-pointer">
                                    {permission.label}
                                  </FormLabel>
                                </FormItem>
                              )}
                            />
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <div className="flex justify-end">
          <Button 
            type="submit" 
            disabled={isPending}
          >
            {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            <Save className="mr-2 h-4 w-4" />
            {roleId ? "Update Role" : "Create Role"}
          </Button>
        </div>
      </form>
    </Form>
  );
}