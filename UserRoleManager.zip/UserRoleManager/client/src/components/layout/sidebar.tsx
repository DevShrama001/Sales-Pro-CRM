import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";

import {
  LayoutDashboard,
  Users,
  Clock,
  FileBarChart2,
  UserRound,
  Settings,
  Wrench,
  LogOut,
  Menu,
  X,
  Zap
} from "lucide-react";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logout } = useAuth();
  
  // Close mobile sidebar on navigation change
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.getElementById('sidebar');
      if (isOpen && sidebar && !sidebar.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const adminMenuItems = [
    { href: '/team', icon: <UserRound size={18} />, label: 'Team Management' },
    { href: '/settings', icon: <Settings size={18} />, label: 'Settings' },
    { href: '/customization', icon: <Wrench size={18} />, label: 'Customization' },
  ];

  const isAdmin = user?.roleId === 1;

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  // Mobile menu button
  const mobileMenuButton = (
    <div className="md:hidden fixed top-0 left-0 z-50 p-4">
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleSidebar}
        className="text-primary-foreground"
      >
        <Menu className="h-6 w-6" />
      </Button>
    </div>
  );

  return (
    <>
      {mobileMenuButton}
      
      <aside 
        id="sidebar"
        className={cn(
          "bg-sidebar text-sidebar-foreground w-64 flex-shrink-0 z-40",
          "fixed inset-y-0 left-0 md:static md:block",
          isOpen ? "block" : "hidden",
          className
        )}
      >
        <div className="flex flex-col h-full">
          {/* Mobile close button */}
          <div className="md:hidden absolute right-2 top-2">
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          {/* Logo and branding */}
          <div className="p-4 flex items-center border-b border-sidebar-border">
            <div className="bg-sidebar-primary text-sidebar-primary-foreground p-2 rounded-lg mr-2">
              <Zap size={20} />
            </div>
            <h1 className="text-xl font-semibold">SalesPro CRM</h1>
          </div>
          
          {/* User profile */}
          <div className="p-4 border-b border-sidebar-border">
            <div className="flex items-center">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarFallback className="bg-sidebar-primary text-sidebar-primary-foreground">
                  {user ? getInitials(user.fullName) : "U"}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium text-sm">{user?.fullName || "User"}</h3>
                <p className="text-xs text-sidebar-foreground/70">{user?.email || ""}</p>
              </div>
            </div>
          </div>
          
          {/* Navigation */}
          <nav className="py-4 flex-1 overflow-y-auto">
            <div className="px-4 mb-2 text-xs font-semibold text-sidebar-foreground/70 uppercase">
              Main
            </div>
            
            <NavLink href="/dashboard" icon={<LayoutDashboard size={18} />} label="Dashboard" />
            <NavLink href="/leads" icon={<Users size={18} />} label="Leads" />
            <NavLink href="/meetings" icon={<Clock size={18} />} label="Meetings" />
            <NavLink href="/reports" icon={<FileBarChart2 size={18} />} label="Reports" />
            
            {isAdmin && (
              <>
                <div className="px-4 mt-6 mb-2 text-xs font-semibold text-sidebar-foreground/70 uppercase">
                  Admin
                </div>
                
                {adminMenuItems.map((item) => (
                  <NavLink 
                    key={item.href} 
                    href={item.href} 
                    icon={item.icon} 
                    label={item.label} 
                  />
                ))}
              </>
            )}
          </nav>
          
          {/* Logout button */}
          <div className="p-4 border-t border-sidebar-border">
            <Button
              variant="ghost"
              className="w-full flex items-center justify-start text-sidebar-foreground/80 hover:text-sidebar-foreground"
              onClick={() => logout()}
            >
              <LogOut size={18} className="mr-3" />
              Logout
            </Button>
          </div>
        </div>
      </aside>
    </>
  );
}

interface NavLinkProps {
  href: string;
  icon: React.ReactNode;
  label: string;
}

function NavLink({ href, icon, label }: NavLinkProps) {
  const [location] = useLocation();
  const isActive = location === href;
  
  return (
    <Link href={href}>
      <a
        className={cn(
          "flex items-center px-4 py-2 text-sm",
          isActive 
            ? "text-sidebar-foreground bg-sidebar-accent" 
            : "text-sidebar-foreground/70 hover:bg-sidebar-accent/70"
        )}
      >
        <span className="mr-3">{icon}</span>
        {label}
      </a>
    </Link>
  );
}

export default Sidebar;
