import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Search,
  Bell,
  Settings,
  HelpCircle,
  LayoutList,
  KanbanSquare,
} from "lucide-react";

interface HeaderProps {
  title: string;
  subtitle?: string;
  viewMode?: "kanban" | "table";
  onViewModeChange?: (mode: "kanban" | "table") => void;
  showViewToggle?: boolean;
  className?: string;
}

export function Header({
  title,
  subtitle,
  viewMode = "kanban",
  onViewModeChange,
  showViewToggle = false,
  className,
}: HeaderProps) {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality
    console.log("Searching for:", searchQuery);
  };

  return (
    <header className={cn("bg-white shadow-sm border-b border-border sticky top-0 z-10", className)}>
      <div className="flex justify-between items-center px-4 py-2">
        <div className="flex items-center space-x-4 md:space-x-8">
          <div className="md:hidden">
            <h1 className="text-xl font-semibold">{title}</h1>
          </div>
          
          {/* Search Form */}
          <form onSubmit={handleSearch} className="hidden md:block relative">
            <Search className="absolute inset-y-0 left-3 flex items-center h-full w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search leads, meetings..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-[250px] lg:w-[300px]"
            />
          </form>
        </div>
        
        {/* Header Actions */}
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon">
            <Bell className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <HelpCircle className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Settings className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Sub-Header with View Options */}
      <div className="flex items-center justify-between px-4 py-2 bg-muted/30 border-t border-border">
        <div className="flex items-center space-x-2">
          <h2 className="text-lg font-semibold">{title}</h2>
          {subtitle && (
            <div className="text-xs px-2 py-1 bg-primary-100 text-primary-800 rounded-full">
              {subtitle}
            </div>
          )}
        </div>
        
        {/* View Toggles */}
        {showViewToggle && onViewModeChange && (
          <div className="flex items-center">
            <Button
              variant={viewMode === "kanban" ? "default" : "outline"}
              size="sm"
              className={cn(
                "flex items-center rounded-r-none",
                viewMode === "kanban" ? "bg-primary text-primary-foreground" : ""
              )}
              onClick={() => onViewModeChange("kanban")}
            >
              <KanbanSquare className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Kanban</span>
            </Button>
            <Button
              variant={viewMode === "table" ? "default" : "outline"}
              size="sm"
              className={cn(
                "flex items-center rounded-l-none",
                viewMode === "table" ? "bg-primary text-primary-foreground" : ""
              )}
              onClick={() => onViewModeChange("table")}
            >
              <LayoutList className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Table</span>
            </Button>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;
