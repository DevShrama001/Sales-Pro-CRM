import { useEffect, useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Activity } from "@shared/schema";
import { calculateTimeAgo } from "@/lib/utils";
import { 
  MessageSquare, 
  Phone, 
  Calendar, 
  Clock, 
  ArrowRight,
  RefreshCw,
  UserCircle,
  MailCheck
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Skeleton } from "@/components/ui/skeleton";

export default function RecentActivities() {
  const { user } = useAuth();
  const [activities, setActivities] = useState<Activity[]>([]);
  
  // Get activity icon based on type
  const getActivityIcon = (type: string) => {
    switch(type) {
      case 'note':
        return <MessageSquare className="h-4 w-4" />;
      case 'call':
        return <Phone className="h-4 w-4" />;
      case 'meeting':
        return <Calendar className="h-4 w-4" />;
      case 'follow_up':
        return <Clock className="h-4 w-4" />;
      case 'stage_change':
        return <ArrowRight className="h-4 w-4" />;
      case 'lead_creation':
        return <UserCircle className="h-4 w-4" />;
      case 'email':
        return <MailCheck className="h-4 w-4" />;
      default:
        return <MessageSquare className="h-4 w-4" />;
    }
  };
  
  // Get background color based on activity type
  const getActivityColor = (type: string) => {
    switch(type) {
      case 'note':
        return 'bg-blue-100 text-blue-700';
      case 'call':
        return 'bg-green-100 text-green-700';
      case 'meeting':
        return 'bg-purple-100 text-purple-700';
      case 'follow_up':
        return 'bg-amber-100 text-amber-700';
      case 'stage_change':
        return 'bg-indigo-100 text-indigo-700';
      case 'lead_creation':
        return 'bg-emerald-100 text-emerald-700';
      case 'email':
        return 'bg-sky-100 text-sky-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };
  
  // Fetch activities 
  const { data, isLoading, refetch } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    initialData: [],
  });
  
  // Process activities when data is available
  useEffect(() => {
    try {
      let activityData = data || [];
      
      // Check if activities is an array
      if (!Array.isArray(activityData)) {
        console.warn("Activities data is not an array", activityData);
        activityData = [];
      }
      
      // Sort activities by creation date (newest first)
      const activityArray = Array.isArray(activityData) ? activityData : [];
      const sortedActivities = activityArray.slice().sort((a, b) => {
        if (!a || !b || !a.createdAt || !b.createdAt) return 0;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
      
      // Get only recent activities (last 10)
      setActivities(sortedActivities.slice(0, 10));
    } catch (error) {
      console.error("Error processing activity data:", error);
      setActivities([]);
    }
  }, [data]);
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Activities</CardTitle>
          <CardDescription>Latest actions across the platform</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-start space-x-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center">
        <div className="flex-1">
          <CardTitle>Recent Activities</CardTitle>
          <CardDescription>Latest actions across the platform</CardDescription>
        </div>
        <Button variant="outline" size="icon" onClick={() => refetch()}>
          <RefreshCw className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        {activities.length === 0 ? (
          <div className="text-center py-8">
            <MessageSquare className="h-8 w-8 mx-auto text-muted-foreground opacity-50" />
            <p className="mt-2 text-muted-foreground">No recent activities</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-4">
                <div className={`p-2 rounded-full ${getActivityColor(activity.type)}`}>
                  {getActivityIcon(activity.type)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm">{activity.title}</p>
                    <span className="text-xs text-muted-foreground">
                      {calculateTimeAgo(activity.createdAt)}
                    </span>
                  </div>
                  {activity.description && (
                    <p className="text-sm text-muted-foreground mt-0.5">
                      {activity.description}
                    </p>
                  )}
                  <div className="text-xs text-muted-foreground mt-1">
                    By: {activity.userId === user?.id ? 'You' : `User ${activity.userId}`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
