import { Card, CardContent } from "@/components/ui/card";
import { PerformanceMetric } from "@/types";
import { formatCurrency } from "@/lib/utils";
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  IndianRupee, 
  BarChart2,
  Clock
} from "lucide-react";

interface StatsOverviewProps {
  stats: PerformanceMetric[];
}

export default function StatsOverview({ stats }: StatsOverviewProps) {
  // Get appropriate icon for stat
  const getStatIcon = (name: string) => {
    const lowerName = name.toLowerCase();
    if (lowerName.includes('lead')) return <Users className="h-5 w-5" />;
    if (lowerName.includes('value') || lowerName.includes('revenue')) return <IndianRupee className="h-5 w-5" />;
    if (lowerName.includes('conversion') || lowerName.includes('rate')) return <BarChart2 className="h-5 w-5" />;
    if (lowerName.includes('time')) return <Clock className="h-5 w-5" />;
    return <BarChart2 className="h-5 w-5" />;
  };
  
  // Format value based on type
  const formatValue = (value: number, name: string, unit?: string) => {
    if (name.toLowerCase().includes('value') || name.toLowerCase().includes('revenue')) {
      return formatCurrency(value);
    }
    
    if (unit) {
      return `${value}${unit}`;
    }
    
    return value.toString();
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">
                  {stat.name}
                </p>
                <div className="text-2xl font-bold">
                  {formatValue(stat.value, stat.name, stat.unit)}
                </div>
              </div>
              <div className={`p-2 rounded-full ${
                stat.name.toLowerCase().includes('value') 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-primary/10 text-primary'
              }`}>
                {getStatIcon(stat.name)}
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              {stat.change > 0 ? (
                <div className="flex items-center text-green-600">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  <span>+{stat.change}%</span>
                </div>
              ) : (
                <div className="flex items-center text-red-600">
                  <TrendingDown className="h-4 w-4 mr-1" />
                  <span>{stat.change}%</span>
                </div>
              )}
              <span className="ml-1 text-muted-foreground">
                from last period
              </span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
