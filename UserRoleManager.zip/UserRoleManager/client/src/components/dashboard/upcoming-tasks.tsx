import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Activity } from "@shared/schema";
import { formatDate, formatTime } from "@/lib/utils";
import { CalendarDays, CheckCircle2, ChevronRight, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { useUpdateActivity } from "@/hooks/use-activity";

interface UpcomingTasksProps {
  className?: string;
}

export default function UpcomingTasks({ className }: UpcomingTasksProps) {
  const { user } = useAuth();
  const [upcomingActivities, setUpcomingActivities] = useState<Activity[]>([]);
  const updateActivity = useUpdateActivity();
  
  // Fetch activities
  const { data: activities, isLoading, refetch } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    initialData: [],
  });
  
  // Filter for upcoming meetings and follow-ups
  useEffect(() => {
    if (user) {
      let activityData = activities || [];
      
      // Check if activities is an array
      if (!Array.isArray(activityData)) {
        console.warn("Activities is not an array", activityData);
        activityData = [];
      }
      
      try {
        // Convert to an array if it's not already
        const activityArray = Array.isArray(activityData) ? activityData : [];
        
        // Get activities assigned to the current user
        const userActivities = activityArray.filter(
          (activity: Activity) => 
            activity && 
            activity.userId === user.id && 
            activity.scheduledAt && 
            !activity.completedAt &&
            ["meeting", "follow_up", "call"].includes(activity.type)
        );
        
        // Sort by scheduledAt date
        const sorted = userActivities.sort((a: Activity, b: Activity) => {
          if (!a.scheduledAt || !b.scheduledAt) return 0;
          return new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime();
        });
        
        // Take only the next 5 activities
        setUpcomingActivities(sorted.slice(0, 5));
      } catch (error) {
        console.error("Error processing activities:", error);
        setUpcomingActivities([]);
      }
    }
  }, [activities, user]);
  
  // Handle marking as complete
  const handleMarkComplete = (id: number) => {
    updateActivity.mutate({
      id,
      data: {
        completedAt: new Date().toISOString() as any // Type casting to fix type issue
      }
    }, {
      onSuccess: () => {
        refetch();
      }
    });
  };
  
  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle>Upcoming Tasks</CardTitle>
        </CardHeader>
        <CardContent>
          {[1, 2, 3].map((i) => (
            <div key={i} className="mb-4 last:mb-0">
              <Skeleton className="h-5 w-3/4 mb-1" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Upcoming Tasks</span>
          <Link href="/meetings">
            <Button variant="ghost" size="sm" className="h-8 gap-1">
              <span className="text-xs">View All</span>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {upcomingActivities.length === 0 ? (
          <div className="text-center py-8 px-4">
            <CalendarDays className="h-8 w-8 mx-auto text-muted-foreground opacity-50" />
            <p className="mt-2 text-muted-foreground">No upcoming tasks scheduled</p>
            <Link href="/meetings">
              <Button variant="outline" size="sm" className="mt-4">
                Schedule a Meeting
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {upcomingActivities.map((activity) => (
              <div key={activity.id} className="flex items-start justify-between group">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-full ${
                    activity.type === 'meeting' 
                      ? 'bg-primary/10 text-primary' 
                      : activity.type === 'call' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-amber-100 text-amber-700'
                  }`}>
                    {activity.type === 'meeting' ? (
                      <CalendarDays className="h-4 w-4" />
                    ) : (
                      <Clock className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{activity.title}</p>
                    <div className="flex items-center text-xs text-muted-foreground mt-1">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>
                        {activity.scheduledAt ? (
                          <>
                            {formatDate(activity.scheduledAt)} at {formatTime(activity.scheduledAt)}
                          </>
                        ) : "No date set"}
                      </span>
                    </div>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => handleMarkComplete(activity.id)}
                  title="Mark as complete"
                >
                  <CheckCircle2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
