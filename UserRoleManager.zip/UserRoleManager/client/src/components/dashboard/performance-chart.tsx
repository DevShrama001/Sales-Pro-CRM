import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { useLeads } from "@/hooks/use-leads";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { formatCurrency } from "@/lib/utils";

interface PerformanceChartProps {
  className?: string;
}

export default function PerformanceChart({ className }: PerformanceChartProps) {
  const [period, setPeriod] = useState<"week" | "month" | "quarter">("month");
  const [chartType, setChartType] = useState<"bar" | "line" | "pie">("bar");
  
  // Fetch leads data
  const { data: leads, isLoading } = useLeads();
  
  // Fetch stages data
  const { data: pipelines } = useQuery({
    queryKey: ["/api/pipelines"],
  });
  
  // Find default pipeline
  const defaultPipeline = pipelines?.find(p => p.isDefault) || pipelines?.[0];
  
  // Fetch stages for the default pipeline
  const { data: stages } = useQuery({
    queryKey: [`/api/pipelines/${defaultPipeline?.id}/stages`],
    enabled: !!defaultPipeline,
  });
  
  // Process data for charts
  const getChartData = () => {
    if (!leads || !stages) return [];
    
    // Group leads by stage
    const stageLeads = stages.map(stage => {
      const stageLeads = leads.filter(lead => lead.stageId === stage.id);
      const totalValue = stageLeads.reduce((sum, lead) => sum + (lead.value || 0), 0);
      
      return {
        name: stage.name,
        count: stageLeads.length,
        value: totalValue,
        color: stage.color || "#3b82f6"
      };
    });
    
    return stageLeads;
  };
  
  const chartData = getChartData();
  
  // Get time period labels
  const getTimeLabels = () => {
    const now = new Date();
    const labels = [];
    
    if (period === "week") {
      for (let i = 6; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
      }
    } else if (period === "month") {
      for (let i = 0; i < 4; i++) {
        const weekStart = new Date(now);
        weekStart.setDate(weekStart.getDate() - (weekStart.getDay() + 7 * i));
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);
        labels.push(`Week ${4-i}`);
      }
    } else { // quarter
      for (let i = 2; i >= 0; i--) {
        const date = new Date(now);
        date.setMonth(date.getMonth() - i);
        labels.push(date.toLocaleDateString('en-US', { month: 'short' }));
      }
    }
    
    return labels;
  };
  
  // Get time series data
  const getTimeSeriesData = () => {
    const labels = getTimeLabels();
    
    // Create mock data based on labels
    return labels.map((name, index) => {
      // Generate values that look like a realistic pattern
      // This would be replaced with actual data in a real implementation
      const baseValue = 20000 + (index * 5000);
      const value = baseValue + (Math.random() * 10000 - 5000);
      const count = 5 + index + Math.floor(Math.random() * 5);
      
      return {
        name,
        value: Math.round(value),
        count
      };
    });
  };
  
  const timeSeriesData = getTimeSeriesData();
  
  // Colors for pie chart
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];
  
  // Custom tooltip formatter
  const formatTooltip = (value: number, name: string) => {
    if (name.toLowerCase().includes('value')) {
      return formatCurrency(value);
    }
    return value;
  };

  return (
    <Card className={className}>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Pipeline Performance</CardTitle>
        <div className="flex space-x-2">
          <Tabs value={chartType} onValueChange={(v) => setChartType(v as any)}>
            <TabsList className="grid grid-cols-3 h-8">
              <TabsTrigger value="bar" className="text-xs">Bar</TabsTrigger>
              <TabsTrigger value="line" className="text-xs">Line</TabsTrigger>
              <TabsTrigger value="pie" className="text-xs">Pie</TabsTrigger>
            </TabsList>
          </Tabs>
          <Select value={period} onValueChange={(v) => setPeriod(v as any)}>
            <SelectTrigger className="w-[120px] h-8">
              <SelectValue placeholder="Period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="p-2">
        {isLoading ? (
          <div className="w-full h-[300px] flex items-center justify-center">
            <div className="animate-spin h-8 w-8 border-2 border-primary rounded-full border-t-transparent"></div>
          </div>
        ) : (
          <>
            {chartType === "bar" && (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={chartData}
                  margin={{ top: 20, right: 30, left: 30, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                  <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                  <Tooltip formatter={formatTooltip} />
                  <Legend />
                  <Bar yAxisId="left" dataKey="count" name="Lead Count" fill="#8884d8" />
                  <Bar yAxisId="right" dataKey="value" name="Total Value" fill="#82ca9d" />
                </BarChart>
              </ResponsiveContainer>
            )}
            
            {chartType === "line" && (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart
                  data={timeSeriesData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                  <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                  <Tooltip formatter={formatTooltip} />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="count" name="Lead Count" stroke="#8884d8" activeDot={{ r: 8 }} />
                  <Line yAxisId="right" type="monotone" dataKey="value" name="Total Value" stroke="#82ca9d" />
                </LineChart>
              </ResponsiveContainer>
            )}
            
            {chartType === "pie" && (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={formatTooltip} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
