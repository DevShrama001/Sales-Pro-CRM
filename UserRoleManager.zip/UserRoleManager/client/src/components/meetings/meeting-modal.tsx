// Import necessary libraries and components
import { useState } from "react"; // For state management
import { useForm } from "react-hook-form"; // Form handling library
import { zodResolver } from "@hookform/resolvers/zod"; // Form validation resolver
import { z } from "zod"; // Schema validation library
import { useToast } from "@/hooks/use-toast"; // Toast notifications
import { useCreateActivity } from "@/hooks/use-activity"; // Custom hook for creating activities
import { useMutation, useQueryClient } from "@tanstack/react-query"; // Data fetching and cache management
import { apiRequest } from "@/lib/queryClient"; // API request utility
import { useAuth } from "@/hooks/use-auth"; // Authentication hook

// Import UI components from shadcn library
import {
  Dialog, // Modal dialog component
  DialogContent, // Content container for dialog
  DialogHeader, // Header section of dialog
  DialogTitle, // Title for dialog
  DialogDescription, // Description text for dialog
  DialogFooter, // Footer section of dialog
} from "@/components/ui/dialog";
import {
  Form, // Form component
  FormControl, // Form control wrapper
  FormField, // Field component for form
  FormItem, // Item component for form fields
  FormLabel, // Label for form items
  FormMessage, // Error message display for form fields
} from "@/components/ui/form";
import { Input } from "@/components/ui/input"; // Input component
import { Button } from "@/components/ui/button"; // Button component
import { Textarea } from "@/components/ui/textarea"; // Textarea component
import { 
  Select, // Select dropdown component
  SelectContent, // Content for select dropdown
  SelectItem, // Individual item in select dropdown
  SelectTrigger, // Trigger element for select
  SelectValue // Value display for select
} from "@/components/ui/select";
import { Loader2, Calendar } from "lucide-react"; // Icons

// Define props interface for the component
interface MeetingModalProps {
  leadId?: number;  // Optional ID of the lead (if meeting is related to a lead)
  isOpen: boolean;  // Controls whether modal is open or closed
  onClose: () => void; // Function to call when modal closes
}

// Define validation schema for meeting form using zod
const meetingSchema = z.object({
  type: z.string().min(1, { message: "Meeting type is required" }), // Meeting type field
  title: z.string().min(2, { message: "Title is required" }), // Title field with min length validation
  scheduledFor: z.string().min(2, { message: "Date and time is required" }), // Date/time field
  description: z.string().optional(), // Optional description field
  participants: z.string().optional(), // Optional participants field
  location: z.string().optional(), // Optional location field
});

// Create type from schema for TypeScript type safety
type FormData = z.infer<typeof meetingSchema>;

// Main component for scheduling meetings
export default function MeetingModal({ leadId, isOpen, onClose }: MeetingModalProps) {
  // Get toast notification function
  const { toast } = useToast();
  // Get query client for cache management
  const queryClient = useQueryClient();
  // Get current authenticated user
  const { user } = useAuth();
  
  // Initialize form with react-hook-form and zod validation
  const form = useForm<FormData>({
    resolver: zodResolver(meetingSchema), // Apply zod validation schema
    defaultValues: {
      // Default values for the form fields
      type: "meeting",
      title: "",
      scheduledFor: "",
      description: "",
      participants: "",
      location: "",
    },
  });
  
  // Use custom hook to create activity (meeting)
  const createActivity = useCreateActivity();
  
  // Handle form submission
  const onSubmit = (data: FormData) => {
    // Check if user is authenticated
    if (!user) return;
    
    // Call mutation to create activity with form data
    createActivity.mutate({
      leadId: leadId || user.id, // Use leadId if provided, otherwise default to user's ID
      userId: user.id, // Current user ID
      type: "meeting", // Activity type
      title: data.title, // Meeting title from form
      description: data.description || 
        `Participants: ${data.participants || 'N/A'}\nLocation: ${data.location || 'N/A'}`, // Include participants and location in description
      scheduledAt: new Date(data.scheduledFor), // Convert string date to Date object
    }, {
      // On successful creation
      onSuccess: () => {
        // Show success toast notification
        toast({
          title: "Meeting Scheduled",
          description: "The meeting has been successfully added to your calendar.",
        });
        
        // Invalidate cached queries to refresh data
        if (leadId) {
          // If meeting is for a specific lead, refresh lead activities
          queryClient.invalidateQueries({ queryKey: [`/api/leads/${leadId}/activities`] });
        }
        // Refresh all activities
        queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
        // Refresh current user's activities
        queryClient.invalidateQueries({ queryKey: [`/api/users/${user.id}/activities`] });
        
        // Reset form fields
        form.reset();
        // Close the modal
        onClose();
      }
    });
  };
  
  // Render component
  return (
    // Dialog modal component that shows when isOpen is true
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        {/* Header section with title and description */}
        <DialogHeader>
          <DialogTitle>Schedule Meeting</DialogTitle>
          <DialogDescription>
            Add a new meeting to your calendar
          </DialogDescription>
        </DialogHeader>
        
        {/* Form component from shadcn UI */}
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-2">
            {/* Meeting title field */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Meeting Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Discovery Call" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Date and time field */}
            <FormField
              control={form.control}
              name="scheduledFor"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Date & Time</FormLabel>
                  <FormControl>
                    <Input type="datetime-local" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Two-column layout for participants and location */}
            <div className="grid grid-cols-2 gap-4">
              {/* Participants field */}
              <FormField
                control={form.control}
                name="participants"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Participants</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter participant names" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Location field */}
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="Office, Zoom, etc." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Meeting notes/description field */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Meeting agenda, topics to cover..." 
                      className="min-h-[100px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Footer with action buttons */}
            <DialogFooter className="pt-4">
              {/* Cancel button */}
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              {/* Submit button with loading state */}
              <Button 
                type="submit"
                disabled={createActivity.isPending}
              >
                {createActivity.isPending ? (
                  <>
                    {/* Show spinner during submission */}
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Scheduling...
                  </>
                ) : (
                  <>
                    {/* Show calendar icon when not submitting */}
                    <Calendar className="mr-2 h-4 w-4" />
                    Schedule Meeting
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}