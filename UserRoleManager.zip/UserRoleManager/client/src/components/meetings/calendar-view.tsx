// Import required libraries and components
import { useState, useMemo } from "react"; // For state management and memoized calculations
import { 
  format, // For formatting dates
  startOfWeek, // Get the start of a week from a date
  endOfWeek, // Get the end of a week from a date
  eachDayOfInterval, // Generate array of days between two dates
  isSameDay, // Check if two dates are the same day
  startOfDay, // Get the start of a day (midnight)
  endOfDay // Get the end of a day (23:59:59)
} from "date-fns"; // Date manipulation library
import { 
  Calendar as CalendarIcon, // Calendar icon
  ChevronLeft, // Left arrow icon
  ChevronRight, // Right arrow icon
  Clock, // Clock icon
  MapPin, // Location pin icon
  User, // User icon
  Loader2 // Loading spinner icon
} from "lucide-react"; // Icon library
import { Button } from "@/components/ui/button"; // Button component
import { Card, CardContent } from "@/components/ui/card"; // Card components
import { useActivities } from "@/hooks/use-activity"; // Custom hook to fetch activities
import MeetingModal from "./meeting-modal"; // Meeting scheduling modal
import { formatDateTime } from "@/lib/utils"; // Date formatting utility

// Calendar view component for displaying meetings by week
export default function CalendarView() {
  // State for tracking the currently viewed date
  const [currentDate, setCurrentDate] = useState(new Date());
  // State for tracking a selected date (when user clicks on a day)
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  // State for controlling meeting modal visibility
  const [showMeetingModal, setShowMeetingModal] = useState(false);
  
  // Calculate week boundaries based on current date
  // Start from Monday (weekStartsOn: 1) instead of Sunday (0)
  const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentDate, { weekStartsOn: 1 });
  // Create array of all days in the current week
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });
  
  // Fetch all activities data using custom hook
  // data: activities - The list of activities from the API
  // isLoading - Loading state indicator
  const { data: activities, isLoading } = useActivities();
  
  // Filter activities to only include scheduled meetings and follow-ups
  // Use useMemo to avoid filtering on every render
  const scheduledActivities = useMemo(() => {
    // If no activities are loaded yet, return empty array
    if (!activities) return [];
    
    // Filter activities that have a scheduledAt date and are meeting or follow_up type
    return activities.filter((activity: any) => 
      activity.scheduledAt && (activity.type === "meeting" || activity.type === "follow_up")
    );
  }, [activities]); // Only recalculate when activities change
  
  // Handler to navigate to previous week
  const goToPreviousWeek = () => {
    // Create a new date object based on current date
    const previousWeek = new Date(currentDate);
    // Subtract 7 days to go back one week
    previousWeek.setDate(previousWeek.getDate() - 7);
    // Update the current date state
    setCurrentDate(previousWeek);
  };
  
  // Handler to navigate to next week
  const goToNextWeek = () => {
    // Create a new date object based on current date
    const nextWeek = new Date(currentDate);
    // Add 7 days to go forward one week
    nextWeek.setDate(nextWeek.getDate() + 7);
    // Update the current date state
    setCurrentDate(nextWeek);
  };
  
  // Handler to navigate to current date (today)
  const goToToday = () => {
    setCurrentDate(new Date());
  };
  
  // Helper function to filter activities for a specific day
  const getActivitiesForDay = (day: Date) => {
    // If no scheduled activities exist, return empty array
    if (!scheduledActivities) return [];
    
    // Filter activities that occur on the specified day
    return scheduledActivities.filter((activity: any) => {
      // Convert activity date string to Date object
      const activityDate = new Date(activity.scheduledAt);
      // Check if activity date is the same day as the specified day
      return isSameDay(activityDate, day);
    });
  };
  
  // Render component
  return (
    <div className="space-y-4">
      {/* Calendar header with title, date range, and navigation controls */}
      <div className="flex items-center justify-between">
        {/* Left side - Title and date range */}
        <div className="flex items-center space-x-2">
          <h2 className="text-2xl font-bold">Calendar</h2>
          {/* Display current week date range */}
          <span className="text-sm text-muted-foreground">
            {format(weekStart, "d MMM")} - {format(weekEnd, "d MMM yyyy")}
          </span>
        </div>
        
        {/* Right side - Navigation buttons */}
        <div className="flex items-center space-x-2">
          {/* Today button to jump to current date */}
          <Button variant="outline" size="sm" onClick={goToToday}>
            Today
          </Button>
          {/* Previous week button */}
          <Button variant="ghost" size="icon" onClick={goToPreviousWeek}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          {/* Next week button */}
          <Button variant="ghost" size="icon" onClick={goToNextWeek}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          {/* Schedule meeting button */}
          <Button 
            className="ml-4" 
            size="sm"
            onClick={() => setShowMeetingModal(true)}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            Schedule Meeting
          </Button>
        </div>
      </div>
      
      {/* Loading state or calendar grid */}
      {isLoading ? (
        // Show loading spinner when data is being fetched
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        // Calendar grid with 7 columns (one for each day of the week)
        <div className="grid grid-cols-7 gap-2">
          {/* Day headers - Show day names and dates */}
          {weekDays.map((day) => (
            <div key={day.toISOString()} className="p-2 text-center">
              {/* Day name (Mon, Tue, etc.) */}
              <div className="font-medium">{format(day, "EEE")}</div>
              {/* Day number with special styling for today */}
              <div className={`text-2xl rounded-full w-10 h-10 flex items-center justify-center mx-auto 
                ${isSameDay(day, new Date()) ? "bg-primary text-primary-foreground" : ""}`}>
                {format(day, "d")}
              </div>
            </div>
          ))}
          
          {/* Day cells - Show activities for each day */}
          {weekDays.map((day) => {
            // Get activities for this specific day
            const dayActivities = getActivitiesForDay(day);
            
            return (
              <div 
                key={`cell-${day.toISOString()}`} 
                className="h-[280px] border rounded-md p-2 overflow-y-auto"
                onClick={() => setSelectedDate(day)}
              >
                {/* Show empty state if no activities exist for this day */}
                {dayActivities.length === 0 ? (
                  <div className="text-center text-sm text-muted-foreground h-full flex items-center justify-center">
                    <p>No meetings</p>
                  </div>
                ) : (
                  // Show list of activities for this day
                  <div className="space-y-2">
                    {dayActivities.map((activity: any) => {
                      // Convert activity scheduled time to Date object
                      const activityTime = new Date(activity.scheduledAt);
                      
                      return (
                        // Activity card with colored left border based on type
                        <Card 
                          key={activity.id} 
                          className={`${activity.type === 'meeting' ? 'border-l-4 border-l-primary' : 'border-l-4 border-l-orange-400'}`}
                        >
                          <CardContent className="p-3">
                            {/* Activity title */}
                            <div className="font-medium text-sm">{activity.title}</div>
                            
                            {/* Activity details */}
                            <div className="mt-1 text-xs text-muted-foreground">
                              {/* Time */}
                              <div className="flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                <span>{format(activityTime, "HH:mm")}</span>
                              </div>
                              
                              {/* Location (if exists) */}
                              {activity.customFields?.location && (
                                <div className="flex items-center mt-1">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  <span>{activity.customFields.location}</span>
                                </div>
                              )}
                              
                              {/* Participants (if exists) */}
                              {activity.customFields?.participants && (
                                <div className="flex items-center mt-1">
                                  <User className="h-3 w-3 mr-1" />
                                  <span>{activity.customFields.participants}</span>
                                </div>
                              )}
                              
                              {/* Lead reference (if exists) */}
                              {activity.leadId && (
                                <div className="mt-1 text-primary">
                                  Lead: {activity.leadId}
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
      
      {/* Meeting Modal for scheduling new meetings */}
      <MeetingModal
        isOpen={showMeetingModal}
        onClose={() => setShowMeetingModal(false)}
      />
    </div>
  );
}