import { useEffect, useState, useCallback } from "react";
import LeadCard from "@/components/leads/lead-card";
import { useLeadsByStage } from "@/hooks/use-leads";
import { Stage, Lead } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { getStageColor } from "@/lib/utils";
import { DragDropContext, Droppable, Draggable, DropResult } from "react-beautiful-dnd";

interface KanbanViewProps {
  pipelineId: number | null;
  stages: Stage[];
  onSelectLead: (leadId: number) => void;
  onMoveLead: (leadId: number, currentStageId: number, targetStageId: number) => void;
  isLoading: boolean;
}

export default function KanbanView({ 
  pipelineId, 
  stages, 
  onSelectLead,
  onMoveLead,
  isLoading 
}: KanbanViewProps) {
  const [stageData, setStageData] = useState<{[key: number]: Lead[]}>({});
  
  // Define refreshData function to allow components to trigger a refresh
  const refreshData = useCallback(async () => {
    if (stages.length > 0) {
      const newStageData: {[key: number]: Lead[]} = {};
      
      for (const stage of stages) {
        try {
          const response = await fetch(`/api/stages/${stage.id}/leads`);
          if (response.ok) {
            const data = await response.json();
            newStageData[stage.id] = data;
          } else {
            newStageData[stage.id] = [];
          }
        } catch (error) {
          console.error(`Error fetching leads for stage ${stage.id}:`, error);
          newStageData[stage.id] = [];
        }
      }
      
      setStageData(newStageData);
    }
  }, [stages]);
  
  // Load leads for each stage
  useEffect(() => {
    if (stages.length > 0) {
      const initialStageData: {[key: number]: Lead[]} = {};
      stages.forEach(stage => {
        initialStageData[stage.id] = [];
      });
      setStageData(initialStageData);
    }
  }, [stages]);
  
  // Use a custom hook to handle the data loading for all stages at once
  useEffect(() => {
    const fetchLeadsForStages = async () => {
      if (stages.length > 0) {
        const newStageData: {[key: number]: Lead[]} = {};
        
        for (const stage of stages) {
          try {
            const response = await fetch(`/api/stages/${stage.id}/leads`);
            if (response.ok) {
              const data = await response.json();
              newStageData[stage.id] = data;
            } else {
              newStageData[stage.id] = [];
            }
          } catch (error) {
            console.error(`Error fetching leads for stage ${stage.id}:`, error);
            newStageData[stage.id] = [];
          }
        }
        
        setStageData(newStageData);
      }
    };
    
    fetchLeadsForStages();
    
    // Set up a refresh interval
    const intervalId = setInterval(fetchLeadsForStages, 30000); // Refresh every 30 seconds
    
    // Clean up the interval on unmount
    return () => clearInterval(intervalId);
  }, [stages]); // Remove stageData dependency to prevent infinite loop
  
  // Handle drag end event
  const handleDragEnd = (result: DropResult) => {
    const { source, destination } = result;
    
    // Exit if dropped outside a droppable area or in the same position
    if (!destination || 
        (source.droppableId === destination.droppableId && 
         source.index === destination.index)) {
      return;
    }
    
    // Get source and destination stage IDs
    const sourceStageId = parseInt(source.droppableId);
    const destinationStageId = parseInt(destination.droppableId);
    
    // Get the dragged lead
    const draggedLead = stageData[sourceStageId][source.index];
    
    // Update local state for immediate UI update
    const newStageData = { ...stageData };
    
    // Remove from source
    const sourceLeads = [...newStageData[sourceStageId]];
    sourceLeads.splice(source.index, 1);
    newStageData[sourceStageId] = sourceLeads;
    
    // Add to destination
    const destLeads = [...newStageData[destinationStageId]];
    destLeads.splice(destination.index, 0, draggedLead);
    newStageData[destinationStageId] = destLeads;
    
    setStageData(newStageData);
    
    // Call the API to update the lead's stage
    onMoveLead(draggedLead.id, sourceStageId, destinationStageId);
  };
  
  // If loading or no pipeline selected
  if (isLoading || !pipelineId) {
    return (
      <div className="flex space-x-4 pb-6 overflow-x-auto">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="flex-shrink-0 w-80 bg-muted/30 rounded-lg shadow">
            <div className="p-3 border-b border-border bg-white rounded-t-lg">
              <Skeleton className="h-6 w-24" />
            </div>
            <div className="p-2">
              {[1, 2, 3].map(j => (
                <Skeleton key={j} className="h-32 mb-2 w-full rounded" />
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  // If no stages found
  if (stages.length === 0) {
    return (
      <div className="text-center p-8">
        <h3 className="text-lg font-semibold mb-2">No Pipeline Stages Found</h3>
        <p className="text-muted-foreground">
          There are no stages defined for this pipeline. Please add stages in the customization settings.
        </p>
      </div>
    );
  }

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="flex space-x-4 pb-6 overflow-x-auto">
        {stages.map(stage => (
          <Droppable key={stage.id} droppableId={stage.id.toString()}>
            {(provided) => (
              <div 
                className="flex-shrink-0 w-80 bg-muted/30 rounded-lg shadow"
                ref={provided.innerRef}
                {...provided.droppableProps}
              >
                <div className={`p-3 border-b border-border rounded-t-lg text-white ${getStageColor(stage.name)}`}>
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">{stage.name}</h3>
                    <div className="flex items-center">
                      <span className="text-xs font-medium bg-white/20 px-2 py-1 rounded-full">
                        {stageData[stage.id]?.length || 0}
                      </span>
                    </div>
                  </div>
                </div>
                
                <ScrollArea className="h-[calc(100vh-250px)]">
                  <div className="p-2 min-h-[300px]">
                    {stageData[stage.id]?.map((lead, index) => (
                      <Draggable 
                        key={lead.id} 
                        draggableId={lead.id.toString()} 
                        index={index}
                      >
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <LeadCard 
                              lead={lead} 
                              onClick={() => onSelectLead(lead.id)}
                              onLeadUpdated={refreshData} 
                            />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                </ScrollArea>
              </div>
            )}
          </Droppable>
        ))}
      </div>
    </DragDropContext>
  );
}
