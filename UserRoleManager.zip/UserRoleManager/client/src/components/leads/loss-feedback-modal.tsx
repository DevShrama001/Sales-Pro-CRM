import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { ThumbsDown } from "lucide-react";
import { LostReasonFormData } from "@/types";

interface LossFeedbackModalProps {
  isOpen: boolean;
  leadId: number;
  onClose: () => void;
  onSubmit: (data: LostReasonFormData) => void;
}

const lossFeedbackSchema = z.object({
  reason: z.string().min(1, "Reason is required"),
  competitor: z.string().optional(),
  comments: z.string().optional(),
});

type FormData = z.infer<typeof lossFeedbackSchema>;

export default function LossFeedbackModal({
  isOpen,
  leadId,
  onClose,
  onSubmit
}: LossFeedbackModalProps) {
  const form = useForm<FormData>({
    resolver: zodResolver(lossFeedbackSchema),
    defaultValues: {
      reason: "",
      competitor: "",
      comments: "",
    },
  });
  
  const handleFormSubmit = (data: FormData) => {
    onSubmit({
      leadId,
      reason: data.reason,
      competitor: data.competitor || undefined,
      comments: data.comments || undefined,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
            <ThumbsDown className="h-8 w-8 text-red-500" />
          </div>
          <DialogTitle className="text-xl font-semibold">Deal Lost</DialogTitle>
          <DialogDescription>
            Please provide feedback to help us improve
          </DialogDescription>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reason for Loss <span className="text-red-500">*</span></FormLabel>
                  <FormControl>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select reason" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Chose competitor">Chose competitor</SelectItem>
                        <SelectItem value="Budget constraints">Budget constraints</SelectItem>
                        <SelectItem value="Timing not right">Timing not right</SelectItem>
                        <SelectItem value="Not a good fit">Not a good fit</SelectItem>
                        <SelectItem value="Lost to status quo">Lost to status quo</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="competitor"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Competitor (if applicable)</FormLabel>
                  <FormControl>
                    <Input placeholder="Competitor name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="comments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Comments</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="What could we have done better?" 
                      className="min-h-[100px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" className="bg-red-600 hover:bg-red-700">
                Submit & Close
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
