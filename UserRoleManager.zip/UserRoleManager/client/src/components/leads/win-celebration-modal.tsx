import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import confetti from "canvas-confetti";
import { formatCurrency } from "@/lib/utils";
import { Lead } from "@shared/schema";
import { PartyPopper } from "lucide-react";

interface WinCelebrationModalProps {
  isOpen: boolean;
  lead: Lead | undefined;
  onClose: () => void;
  onComplete: () => void;
}

export default function WinCelebrationModal({
  isOpen,
  lead,
  onClose,
  onComplete
}: WinCelebrationModalProps) {
  const [confettiDone, setConfettiDone] = useState(false);
  
  // Trigger confetti animation when modal opens
  useEffect(() => {
    if (isOpen) {
      triggerConfetti();
    }
  }, [isOpen]);
  
  // Run confetti animation
  const triggerConfetti = () => {
    setConfettiDone(false);
    
    const duration = 3 * 1000;
    const animationEnd = Date.now() + duration;
    
    const randomInRange = (min: number, max: number) => {
      return Math.random() * (max - min) + min;
    };
    
    const makeConfetti = () => {
      const timeLeft = animationEnd - Date.now();
      
      if (timeLeft <= 0) {
        setConfettiDone(true);
        return;
      }
      
      const particleCount = 50 * (timeLeft / duration);
      
      // Create confetti from the middle of the screen
      confetti({
        particleCount,
        origin: { x: randomInRange(0.2, 0.8), y: randomInRange(0.2, 0.5) },
        startVelocity: randomInRange(30, 60),
        spread: randomInRange(50, 100),
        ticks: 200,
        gravity: 1,
        colors: ["#3b82f6", "#16a34a", "#f97316", "#eab308", "#8b5cf6"],
        scalar: randomInRange(0.8, 1.2),
      });
      
      // Schedule next confetti burst
      requestAnimationFrame(makeConfetti);
    };
    
    makeConfetti();
  };
  
  // Close modal handler
  const handleClose = () => {
    onClose();
  };
  
  // Complete button handler
  const handleComplete = () => {
    onComplete();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md text-center p-8">
        <div className="absolute inset-0 overflow-hidden rounded-lg">
          {/* Animated backdrop */}
          <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-r from-primary via-amber-500 to-emerald-500 opacity-25"></div>
        </div>
        
        <div className="relative">
          <div className="text-5xl mb-4 flex justify-center">
            <PartyPopper className="h-16 w-16 text-amber-500" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Deal Won!</h2>
          <p className="text-muted-foreground mb-6">
            Congratulations on closing the deal with {lead?.company || "the client"}!
          </p>
          
          <div className="bg-emerald-50 p-4 rounded-lg mb-6">
            <div className="text-emerald-700 font-semibold text-xl">
              {lead?.value ? formatCurrency(lead.value) : "$0"}
            </div>
            <div className="text-emerald-600 text-sm">Total Deal Value</div>
          </div>
          
          <Button onClick={handleComplete} className="w-full bg-emerald-600 hover:bg-emerald-700">
            Complete Deal
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
