import { useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLead } from "@/hooks/use-leads";
import { useStage } from "@/hooks/use-stages";
import { Loader2 } from "lucide-react";

interface StageFormModalProps {
  leadId: number;
  stageId: number;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (formData: Record<string, any>) => void;
}

export default function StageFormModal({
  leadId,
  stageId,
  isOpen,
  onClose,
  onSubmit
}: StageFormModalProps) {
  // Fetch lead and stage data
  const { data: lead, isLoading: isLeadLoading } = useLead(leadId);
  const { data: stage, isLoading: isStageLoading } = useStage(stageId);
  
  // Create a dynamic form schema based on required fields
  const createFormSchema = (requiredFields: string[] = []) => {
    const schemaObj: Record<string, any> = {};
    
    requiredFields.forEach(field => {
      switch (field) {
        case 'value':
          schemaObj[field] = z.number().min(0).optional().nullable();
          break;
        case 'probability':
          schemaObj[field] = z.number().min(0).max(100).optional().nullable();
          break;
        case 'decisionMaker':
          schemaObj[field] = z.boolean().optional();
          break;
        case 'timeline':
          schemaObj[field] = z.string().optional();
          break;
        case 'nextSteps':
          schemaObj[field] = z.string().optional();
          break;
        default:
          schemaObj[field] = z.string().optional();
      }
    });
    
    return z.object(schemaObj);
  };
  
  // Initialize form with dynamic schema
  const formSchema = createFormSchema(stage?.requiredFields || []);
  type FormData = z.infer<typeof formSchema>;
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      value: lead?.value || undefined,
      probability: lead?.probability || undefined,
      decisionMaker: false,
      timeline: "",
      nextSteps: "",
    },
  });
  
  // Update form values when lead data is loaded
  useEffect(() => {
    if (lead) {
      form.reset({
        value: lead?.value || undefined,
        probability: lead?.probability || undefined,
        // Set other fields from lead.customFields if available
        ...(lead?.customFields || {}),
      });
    }
  }, [lead, form]);
  
  // Handle form submission
  const handleFormSubmit = (data: FormData) => {
    // Combine form data with customFields
    const formData = {
      ...data,
      customFields: {
        ...(lead?.customFields || {}),
        ...Object.fromEntries(
          Object.entries(data).filter(([key]) => 
            !['value', 'probability', 'stageId'].includes(key)
          )
        ),
      },
    };
    
    onSubmit(formData);
  };
  
  // Skip rendering if data is not loaded yet
  if (isLeadLoading || isStageLoading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent>
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </DialogContent>
      </Dialog>
    );
  }
  
  if (!stage) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Error</DialogTitle>
            <DialogDescription>Stage information could not be loaded.</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p>The requested stage was not found. Please try again.</p>
          </div>
          <DialogFooter>
            <Button onClick={onClose}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Move to {stage?.name}</DialogTitle>
          <DialogDescription>
            Please complete the required information for this stage
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4 py-4">
            {stage?.requiredFields?.includes('value') && (
              <FormField
                control={form.control}
                name="value"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Qualified Budget</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <span className="text-muted-foreground">₹</span>
                        </div>
                        <Input 
                          type="number" 
                          placeholder="0.00" 
                          className="pl-8" 
                          {...field}
                          onChange={e => field.onChange(e.target.value === '' ? undefined : Number(e.target.value))}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {stage?.requiredFields?.includes('probability') && (
              <FormField
                control={form.control}
                name="probability"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Probability (%)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        max="100" 
                        placeholder="50" 
                        {...field}
                        onChange={e => field.onChange(e.target.value === '' ? undefined : Number(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {stage?.requiredFields?.includes('timeline') && (
              <FormField
                control={form.control}
                name="timeline"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Decision Timeline</FormLabel>
                    <FormControl>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select timeline" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1-3 months">1-3 months</SelectItem>
                          <SelectItem value="3-6 months">3-6 months</SelectItem>
                          <SelectItem value="6-12 months">6-12 months</SelectItem>
                          <SelectItem value="12+ months">12+ months</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {stage?.requiredFields?.includes('decisionMaker') && (
              <FormField
                control={form.control}
                name="decisionMaker"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Decision Maker Identified</FormLabel>
                    <FormControl>
                      <RadioGroup
                        value={field.value ? "yes" : "no"}
                        onValueChange={(value) => field.onChange(value === "yes")}
                        className="flex space-x-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="yes" id="yes" />
                          <Label htmlFor="yes">Yes</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="no" id="no" />
                          <Label htmlFor="no">No</Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {stage?.requiredFields?.includes('nextSteps') && (
              <FormField
                control={form.control}
                name="nextSteps"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Next Steps</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Outline the next steps..." 
                        className="min-h-[100px]"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit">
                Move to Stage
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
