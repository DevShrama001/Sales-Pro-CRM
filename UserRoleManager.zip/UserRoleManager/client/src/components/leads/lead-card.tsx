import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Lead } from "@shared/schema";
import { formatCurrency, calculateTimeAgo, truncateText, getStatusColor } from "@/lib/utils";
import { Clock, MoreHorizontal, Pencil, Trash } from "lucide-react";
import LeadEditForm from "./lead-edit-form";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface LeadCardProps {
  lead: Lead;
  onClick: () => void;
  onLeadUpdated: () => void;
}

export default function LeadCard({ lead, onClick, onLeadUpdated }: LeadCardProps) {
  const [showEditForm, setShowEditForm] = useState(false);
  
  // Get lead status based on customFields
  const getLeadStatus = () => {
    if (lead.customFields && lead.customFields.status) {
      return lead.customFields.status;
    }
    return "New";
  };

  const status = getLeadStatus();
  
  // Handle card click while preventing propagation from action buttons
  const handleCardClick = (e: React.MouseEvent) => {
    onClick();
  };
  
  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowEditForm(true);
  };
  
  return (
    <>
      <Card className="mb-2 p-3 bg-white rounded shadow hover:shadow-md cursor-pointer transition-shadow group">
        <div className="flex justify-between items-start mb-2">
          <div onClick={handleCardClick} className="flex-grow">
            <h4 className="font-medium text-sm">{lead.company}</h4>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-xs ${getStatusColor(status.toLowerCase())} px-2 py-0.5 rounded-full`}>
              {status}
            </span>
            <DropdownMenu>
              <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleEditClick}>
                  <Pencil className="mr-2 h-4 w-4" />
                  Edit
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        <div onClick={handleCardClick}>
          <p className="text-xs text-muted-foreground mb-2">{lead.contact || "No contact"}</p>
          
          <p className="text-xs text-muted-foreground mb-3">
            {lead.customFields && lead.customFields.notes 
              ? truncateText(lead.customFields.notes as string, 60) 
              : "No details provided."}
          </p>
          
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center text-muted-foreground">
              <Clock className="h-3 w-3 mr-1" />
              <span>{calculateTimeAgo(lead.updatedAt)}</span>
            </div>
            <div>
              {lead.value ? (
                <span className="text-emerald-600 font-medium">{formatCurrency(lead.value)}</span>
              ) : (
                <span className="text-muted-foreground italic">No value</span>
              )}
            </div>
          </div>
        </div>
      </Card>
      
      {showEditForm && (
        <LeadEditForm
          leadId={lead.id}
          isOpen={showEditForm}
          onClose={() => setShowEditForm(false)}
          onSuccess={onLeadUpdated}
        />
      )}
    </>
  );
}
