import { useState } from "react";
import { useLeads } from "@/hooks/use-leads";
import { usePipelineStages } from "@/hooks/use-pipeline";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Pencil, Filter, ArrowUpDown } from "lucide-react";
import { formatCurrency, calculateTimeAgo, getStatusColor } from "@/lib/utils";

interface TableViewProps {
  pipelineId: number | null;
  onSelectLead: (leadId: number) => void;
}

export default function TableView({ pipelineId, onSelectLead }: TableViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [stageFilter, setStageFilter] = useState("all");
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  
  // Fetch all leads
  const { data: leads, isLoading } = useLeads();
  
  // Fetch pipeline stages for filtering
  const { data: stages } = usePipelineStages(pipelineId);
  
  // Filter and sort leads
  const filteredLeads = leads ? leads
    .filter(lead => {
      // Filter by pipeline if pipelineId is provided
      if (pipelineId && stages) {
        const stageIds = stages.map(stage => stage.id);
        if (!stageIds.includes(lead.stageId)) return false;
      }
      
      // Filter by stage if stage filter is set
      if (stageFilter !== "all" && lead.stageId !== parseInt(stageFilter)) return false;
      
      // Filter by search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          lead.company.toLowerCase().includes(query) ||
          (lead.contact && lead.contact.toLowerCase().includes(query)) ||
          (lead.email && lead.email.toLowerCase().includes(query))
        );
      }
      
      return true;
    })
    .sort((a, b) => {
      if (!sortField) return 0;
      
      let comparison = 0;
      
      switch (sortField) {
        case "company":
          comparison = a.company.localeCompare(b.company);
          break;
        case "value":
          comparison = (a.value || 0) - (b.value || 0);
          break;
        case "updatedAt":
          comparison = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
          break;
        case "probability":
          comparison = (a.probability || 0) - (b.probability || 0);
          break;
        default:
          comparison = 0;
      }
      
      return sortDirection === "asc" ? comparison : -comparison;
    })
    : [];
  
  // Handle sort click
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  return (
    <Card className="overflow-hidden">
      <div className="p-4 bg-muted/20 border-b">
        <div className="flex flex-col md:flex-row gap-3 justify-between">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative w-full sm:w-64">
              <Input
                placeholder="Search leads..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            
            {stages && (
              <Select value={stageFilter} onValueChange={setStageFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Filter by stage" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Stages</SelectItem>
                  {stages.map(stage => (
                    <SelectItem key={stage.id} value={stage.id.toString()}>
                      {stage.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          
          <div className="text-sm text-muted-foreground">
            Showing {filteredLeads.length} leads
          </div>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[300px]">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleSort("company")}
                  className="font-semibold flex items-center"
                >
                  Company
                  {sortField === "company" && (
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  )}
                </Button>
              </TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Source</TableHead>
              <TableHead className="text-right">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleSort("value")}
                  className="font-semibold flex items-center justify-end ml-auto"
                >
                  Value
                  {sortField === "value" && (
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  )}
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleSort("probability")}
                  className="font-semibold flex items-center justify-end ml-auto"
                >
                  Probability
                  {sortField === "probability" && (
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  )}
                </Button>
              </TableHead>
              <TableHead>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleSort("updatedAt")}
                  className="font-semibold flex items-center"
                >
                  Last Updated
                  {sortField === "updatedAt" && (
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  )}
                </Button>
              </TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8">
                  <div className="flex justify-center">
                    <div className="animate-spin h-6 w-6 border-2 border-primary rounded-full border-t-transparent"></div>
                  </div>
                </TableCell>
              </TableRow>
            ) : filteredLeads.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8">
                  <p className="text-muted-foreground">No leads found</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Try adjusting your search or filter criteria
                  </p>
                </TableCell>
              </TableRow>
            ) : (
              filteredLeads.map(lead => {
                // Find the stage for this lead
                const stage = stages?.find(s => s.id === lead.stageId);
                
                return (
                  <TableRow 
                    key={lead.id}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => onSelectLead(lead.id)}
                  >
                    <TableCell className="font-medium">
                      <div className="flex items-center">
                        {lead.company}
                        {stage && (
                          <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${getStatusColor(stage.name.toLowerCase())}`}>
                            {stage.name}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{lead.contact || "—"}</TableCell>
                    <TableCell>{lead.source || "—"}</TableCell>
                    <TableCell className="text-right">
                      {lead.value ? formatCurrency(lead.value) : "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      {lead.probability ? `${lead.probability}%` : "—"}
                    </TableCell>
                    <TableCell>
                      <span className="text-muted-foreground text-sm">
                        {calculateTimeAgo(lead.updatedAt)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectLead(lead.id);
                        }}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}
