// Import necessary libraries and components
import { useState } from "react"; // For state management (if needed)
import { useForm } from "react-hook-form"; // Form handling library
import { zodResolver } from "@hookform/resolvers/zod"; // Zod integration for form validation
import { z } from "zod"; // Schema validation library
import { useMutation, useQueryClient } from "@tanstack/react-query"; // Data fetching and mutation
import { apiRequest } from "@/lib/queryClient"; // API request utility
import { useToast } from "@/hooks/use-toast"; // Toast notification system

// Import UI components from shadcn library
import {
  Dialog, // Modal dialog component
  DialogContent, // Content container for dialog
  DialogHeader, // Header section of dialog
  DialogTitle, // Title for dialog
  DialogDescription, // Description text for dialog
  DialogFooter, // Footer section of dialog
} from "@/components/ui/dialog";
import {
  Form, // Form component
  FormControl, // Form control wrapper
  FormField, // Field component for form
  FormItem, // Item component for form fields
  FormLabel, // Label for form items
  FormMessage, // Error message display for form fields
} from "@/components/ui/form";
import { Input } from "@/components/ui/input"; // Input component
import { Button } from "@/components/ui/button"; // Button component
import { Checkbox } from "@/components/ui/checkbox"; // Checkbox component
import { Loader2, User } from "lucide-react"; // Icons for UI

// Define props interface for the ContactModal component
interface ContactModalProps {
  leadId: number; // ID of the lead to associate contact with
  isOpen: boolean; // Controls whether modal is visible
  onClose: () => void; // Function to call when modal closes
}

// Define validation schema for contact form using zod
// This ensures data entered in the form matches expected format
const contactSchema = z.object({
  name: z.string().min(2, { message: "Name is required" }), // Name field with minimum length validation
  email: z.string().email({ message: "Valid email is required" }).optional().nullable(), // Optional email with format validation
  phone: z.string().optional().nullable(), // Optional phone number
  position: z.string().optional().nullable(), // Optional job position
  isPrimary: z.boolean().default(false), // Boolean field for primary contact status with default value
});

// Create TypeScript type from schema for type safety
type FormData = z.infer<typeof contactSchema>;

// Main component for adding contacts to a lead
export default function ContactModal({ leadId, isOpen, onClose }: ContactModalProps) {
  // Get toast notification function
  const { toast } = useToast();
  // Get query client for cache management
  const queryClient = useQueryClient();
  
  // Initialize form with react-hook-form and zod validation
  const form = useForm<FormData>({
    resolver: zodResolver(contactSchema), // Apply zod validation schema
    defaultValues: {
      // Default values for the form fields
      name: "",
      email: "",
      phone: "",
      position: "",
      isPrimary: false,
    },
  });
  
  // Create mutation for adding a new contact
  // This handles the API request and success/error states
  const createContact = useMutation({
    // Function to execute when mutation is triggered
    mutationFn: async (data: FormData) => {
      // Make POST request to add contact to the lead
      const res = await apiRequest("POST", `/api/leads/${leadId}/contacts`, {
        ...data, // Spread form data
        leadId, // Add lead ID reference
      });
      return await res.json(); // Parse response as JSON
    },
    // Handle successful API response
    onSuccess: () => {
      // Show success toast notification
      toast({
        title: "Contact Added",
        description: "The contact has been added to the lead.",
      });
      
      // Invalidate cached queries to refresh data
      // This ensures UI is updated with the new contact
      queryClient.invalidateQueries({ queryKey: [`/api/leads/${leadId}/contacts`] }); // Update contacts list
      queryClient.invalidateQueries({ queryKey: [`/api/leads/${leadId}`] }); // Update lead details
      
      // Reset form fields to default values
      form.reset();
      // Close the modal
      onClose();
    },
    // Handle API request errors
    onError: (error: Error) => {
      // Show error toast notification
      toast({
        title: "Error Adding Contact",
        description: error.message,
        variant: "destructive", // Red styling for error
      });
    },
  });
  
  // Form submission handler
  const onSubmit = (data: FormData) => {
    // Trigger the mutation with form data
    createContact.mutate(data);
  };
  
  // Render the component
  return (
    // Dialog modal component that shows when isOpen is true
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        {/* Header section with title and description */}
        <DialogHeader>
          <DialogTitle>Add Contact</DialogTitle>
          <DialogDescription>
            Add a new contact for this lead
          </DialogDescription>
        </DialogHeader>
        
        {/* Form component from shadcn UI */}
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-2">
            {/* Full name field - required */}
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Smith" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Two-column layout for email and phone */}
            <div className="grid grid-cols-2 gap-4">
              {/* Email field - optional but validated */}
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      {/* Handle null value to prevent controlled/uncontrolled input warning */}
                      <Input placeholder="john@example.com" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Phone field - optional */}
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl>
                      {/* Handle null value to prevent controlled/uncontrolled input warning */}
                      <Input placeholder="+1 (555) 123-4567" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Position field - optional */}
            <FormField
              control={form.control}
              name="position"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Position</FormLabel>
                  <FormControl>
                    {/* Handle null value to prevent controlled/uncontrolled input warning */}
                    <Input placeholder="CEO, Marketing Director, etc." {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Primary contact checkbox */}
            <FormField
              control={form.control}
              name="isPrimary"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Primary Contact</FormLabel>
                    <p className="text-xs text-muted-foreground">
                      Make this the primary contact for the lead
                    </p>
                  </div>
                </FormItem>
              )}
            />
            
            {/* Footer with action buttons */}
            <DialogFooter className="pt-4">
              {/* Cancel button */}
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              {/* Submit button with loading state */}
              <Button 
                type="submit"
                disabled={createContact.isPending} // Disable during submission
              >
                {createContact.isPending ? (
                  <>
                    {/* Show spinner during submission */}
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    {/* Show user icon when not submitting */}
                    <User className="mr-2 h-4 w-4" />
                    Add Contact
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}