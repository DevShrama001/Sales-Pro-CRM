import { useState, useEffect } from "react";
import { useLead, useLeadActivities, useLeadContacts } from "@/hooks/use-leads";
import { useCreateActivity } from "@/hooks/use-activity";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatDateTime, calculateTimeAgo } from "@/lib/utils";
import { XCircle, Calendar, Phone, Mail, MessageCircle, Plus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Loader2 } from "lucide-react";
import ContactModal from "./contact-modal";

interface LeadDetailsProps {
  leadId: number;
  onClose: () => void;
}

const noteSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
});

type NoteFormData = z.infer<typeof noteSchema>;

export default function LeadDetails({ leadId, onClose }: LeadDetailsProps) {
  const [showAddNote, setShowAddNote] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [meetingType, setMeetingType] = useState("Discovery Call");
  const [meetingDate, setMeetingDate] = useState("");
  const [meetingNotes, setMeetingNotes] = useState("");
  const { user } = useAuth();
  
  // Fetch lead details
  const { data: lead, isLoading } = useLead(leadId);
  
  // Fetch lead activities
  const { data: activities, isLoading: activitiesLoading } = useLeadActivities(leadId);
  
  // Fetch lead contacts
  const { data: contacts, isLoading: contactsLoading } = useLeadContacts(leadId);
  
  // Activity creation mutation
  const createActivity = useCreateActivity();
  
  // Note form
  const form = useForm<NoteFormData>({
    resolver: zodResolver(noteSchema),
    defaultValues: {
      title: "",
      description: "",
    },
  });
  
  // Close panel when Escape key is pressed
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose]);
  
  // Handle note submission
  const onSubmitNote = (data: NoteFormData) => {
    if (!user) return;
    
    createActivity.mutate({
      leadId,
      userId: user.id,
      type: "note",
      title: data.title,
      description: data.description,
    }, {
      onSuccess: () => {
        setShowAddNote(false);
        form.reset();
      }
    });
  };
  
  // Handle meeting scheduling
  const handleScheduleMeeting = () => {
    if (!user || !meetingDate) return;
    
    createActivity.mutate({
      leadId,
      userId: user.id,
      type: "meeting",
      title: meetingType,
      description: meetingNotes,
      scheduledAt: new Date(meetingDate),
    }, {
      onSuccess: () => {
        setMeetingType("Discovery Call");
        setMeetingDate("");
        setMeetingNotes("");
      }
    });
  };
  
  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex justify-center items-center">
        <div className="bg-white p-8 rounded-lg shadow-lg flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
          <p>Loading lead details...</p>
        </div>
      </div>
    );
  }
  
  if (!lead) {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex justify-center items-center">
        <div className="bg-white p-8 rounded-lg shadow-lg">
          <p>Lead not found</p>
          <Button onClick={onClose} className="mt-4">Close</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50">
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
          {/* Header */}
          <div className="flex justify-between items-center p-4 border-b border-border">
            <div>
              <h2 className="text-xl font-semibold">{lead.company}</h2>
              <p className="text-sm text-muted-foreground">
                Stage: {lead.stageId}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                Move to Next Stage
              </Button>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <XCircle className="h-5 w-5" />
              </Button>
            </div>
          </div>
          
          {/* Content */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Left Column */}
              <div className="flex-1">
                {/* Lead Info */}
                <div className="mb-6">
                  <h3 className="text-sm font-semibold mb-2 text-muted-foreground uppercase">Lead Information</h3>
                  <Card>
                    <CardContent className="p-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Company</label>
                          <p className="font-medium">{lead.company}</p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Industry</label>
                          <p>{lead.customFields.industry as string || "Not specified"}</p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Primary Contact</label>
                          <p>{lead.contact || "Not specified"}</p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Position</label>
                          <p>{lead.customFields.position as string || "Not specified"}</p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Email</label>
                          <p>{lead.email || "Not specified"}</p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Phone</label>
                          <p>{lead.phone || "Not specified"}</p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Source</label>
                          <p>{lead.source || "Not specified"}</p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Assigned To</label>
                          <p>{lead.assignedTo || "Unassigned"}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Lead Details */}
                <div className="mb-6">
                  <h3 className="text-sm font-semibold mb-2 text-muted-foreground uppercase">Lead Details</h3>
                  <Card>
                    <CardContent className="p-4">
                      <div className="mb-4">
                        <label className="block text-xs text-muted-foreground mb-1">Opportunity Summary</label>
                        <p className="text-sm">
                          {lead.customFields.notes as string || "No notes provided."}
                        </p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Potential Value</label>
                          <p className="font-medium text-emerald-600">
                            {lead.value ? formatCurrency(lead.value) : "Not specified"}
                          </p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Timeline</label>
                          <p>{lead.customFields.timeline as string || "Not specified"}</p>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Probability</label>
                          <div className="flex items-center">
                            <div className="w-full bg-muted rounded-full h-2 mr-2">
                              <div 
                                className="bg-primary h-2 rounded-full" 
                                style={{width: `${lead.probability || 0}%`}}
                              ></div>
                            </div>
                            <span>{lead.probability || 0}%</span>
                          </div>
                        </div>
                        <div>
                          <label className="block text-xs text-muted-foreground mb-1">Next Steps</label>
                          <p>{lead.customFields.nextSteps as string || "Not specified"}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Activity & Notes */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase">Activity & Notes</h3>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-primary flex items-center"
                      onClick={() => setShowAddNote(!showAddNote)}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Note
                    </Button>
                  </div>
                  
                  {showAddNote && (
                    <Card className="mb-4">
                      <CardContent className="p-4">
                        <Form {...form}>
                          <form onSubmit={form.handleSubmit(onSubmitNote)} className="space-y-4">
                            <FormField
                              control={form.control}
                              name="title"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Title</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Note title" {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="description"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Description</FormLabel>
                                  <FormControl>
                                    <Textarea 
                                      placeholder="Enter note details..." 
                                      className="min-h-[100px]"
                                      {...field} 
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            
                            <div className="flex justify-end space-x-2">
                              <Button 
                                type="button" 
                                variant="outline"
                                onClick={() => setShowAddNote(false)}
                              >
                                Cancel
                              </Button>
                              <Button 
                                type="submit"
                                disabled={createActivity.isPending}
                              >
                                {createActivity.isPending && (
                                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                )}
                                Save Note
                              </Button>
                            </div>
                          </form>
                        </Form>
                      </CardContent>
                    </Card>
                  )}
                  
                  <Card>
                    <CardContent className="p-4">
                      {activitiesLoading ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-6 w-6 animate-spin text-primary" />
                        </div>
                      ) : !activities || activities.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground">
                          <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-40" />
                          <p>No activities yet</p>
                          <p className="text-sm mt-1">Add a note or log an activity to get started</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {activities.map((activity: any) => (
                            <div key={activity.id} className="border-l-2 border-primary pl-3">
                              <div className="flex justify-between mb-1">
                                <h4 className="font-medium text-sm">{activity.title}</h4>
                                <span className="text-xs text-muted-foreground">
                                  {calculateTimeAgo(activity.createdAt)}
                                </span>
                              </div>
                              <p className="text-sm text-muted-foreground">
                                {activity.description || "No description provided."}
                              </p>
                              <div className="text-xs text-muted-foreground mt-1">
                                By: User {activity.userId}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
              
              {/* Right Column */}
              <div className="w-full md:w-80">
                {/* Schedule Meeting */}
                <div className="mb-6">
                  <h3 className="text-sm font-semibold mb-2 text-muted-foreground uppercase">Schedule Meeting</h3>
                  <Card>
                    <CardContent className="p-4">
                      <div className="mb-3">
                        <label className="block text-xs text-muted-foreground mb-1">Meeting Type</label>
                        <select
                          className="w-full border border-border rounded px-3 py-2 focus:border-primary focus:outline-none text-sm"
                          value={meetingType}
                          onChange={(e) => setMeetingType(e.target.value)}
                        >
                          <option>Discovery Call</option>
                          <option>Product Demo</option>
                          <option>Proposal Review</option>
                          <option>Negotiation</option>
                        </select>
                      </div>
                      <div className="mb-3">
                        <label className="block text-xs text-muted-foreground mb-1">Date & Time</label>
                        <Input 
                          type="datetime-local" 
                          className="w-full" 
                          value={meetingDate}
                          onChange={(e) => setMeetingDate(e.target.value)}
                        />
                      </div>
                      <div className="mb-4">
                        <label className="block text-xs text-muted-foreground mb-1">Notes</label>
                        <Textarea 
                          className="w-full min-h-[80px]" 
                          placeholder="Meeting agenda, topics to cover..."
                          value={meetingNotes}
                          onChange={(e) => setMeetingNotes(e.target.value)}
                        />
                      </div>
                      <Button 
                        className="w-full"
                        onClick={handleScheduleMeeting}
                        disabled={!meetingDate}
                      >
                        <Calendar className="h-4 w-4 mr-2" />
                        Schedule Meeting
                      </Button>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Upcoming Activities */}
                <div className="mb-6">
                  <h3 className="text-sm font-semibold mb-2 text-muted-foreground uppercase">Upcoming Activities</h3>
                  <Card>
                    <CardContent className="p-4">
                      {activitiesLoading ? (
                        <div className="flex justify-center py-4">
                          <Loader2 className="h-5 w-5 animate-spin text-primary" />
                        </div>
                      ) : !activities || activities.filter((a: any) => a.scheduledAt && new Date(a.scheduledAt) > new Date()).length === 0 ? (
                        <div className="text-center py-4 text-muted-foreground">
                          <p className="text-sm">No upcoming activities</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {activities
                            .filter((a: any) => a.scheduledAt && new Date(a.scheduledAt) > new Date())
                            .map((activity: any) => (
                              <div key={activity.id} className="flex items-start">
                                <div className="bg-primary/10 p-2 rounded-full mr-3">
                                  <Calendar className="text-primary h-4 w-4" />
                                </div>
                                <div className="flex-1">
                                  <p className="text-sm font-medium">{activity.title}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {formatDateTime(activity.scheduledAt)}
                                  </p>
                                </div>
                              </div>
                            ))
                          }
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
                
                {/* Additional Contacts */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase">Additional Contacts</h3>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-primary flex items-center"
                      onClick={() => setShowContactModal(true)}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>
                  <Card>
                    <CardContent className="p-4">
                      {contactsLoading ? (
                        <div className="flex justify-center py-4">
                          <Loader2 className="h-5 w-5 animate-spin text-primary" />
                        </div>
                      ) : !contacts || contacts.length === 0 ? (
                        <div className="text-center py-4 text-muted-foreground">
                          <p className="text-sm">No additional contacts</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {contacts.map((contact: any) => (
                            <div key={contact.id} className="pb-2 border-b border-border last:border-0">
                              <p className="text-sm font-medium">{contact.name}</p>
                              <p className="text-xs text-muted-foreground">{contact.position}</p>
                              <div className="flex items-center mt-1 text-xs text-muted-foreground">
                                {contact.email && (
                                  <div className="flex items-center mr-3">
                                    <Mail className="h-3 w-3 mr-1" />
                                    <span>{contact.email}</span>
                                  </div>
                                )}
                                {contact.phone && (
                                  <div className="flex items-center">
                                    <Phone className="h-3 w-3 mr-1" />
                                    <span>{contact.phone}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Contact Modal */}
      <ContactModal 
        leadId={leadId} 
        isOpen={showContactModal} 
        onClose={() => setShowContactModal(false)} 
      />
    </div>
  );
}
